import json
import time
import logging
from httpx import (
    Response,
    RequestError,
    RemoteProtocolError,
    ReadTimeout,
    HTTPError,
    HTTPStatusError,
)

from ragdapi.load.endpoint import Endpoint
from ragdapi.load.passport import SSOPassport
from ragdapi.schemas.config import Config
from git import Repo
import base64

logger = logging.getLogger(__name__)


class SLMClient:
    def __init__(self, config: Config):
        self.config = config
        self.service_url = config.extract.query_dsslm.service_url
        # self.ds_tenant = config.load.ds_tenant
        self.username = config.extract.query_dsslm.username
        self.query_path = config.extract.localxplore.slm_query_path
        self.ds_tenant = ''

        encoded_password = config.extract.query_dsslm.password
        decoded_password_bytes = base64.b64decode(encoded_password)
        self.password = decoded_password_bytes.decode("utf-8")

        self.client = SSOPassport().run(
            service_url=f"{self.service_url}",
            ds_tenant = self.ds_tenant,
            username=self.username,
            password=self.password,
            asynchronous=False,
        )

        logger.info(f"Loader initialized with config: {self.config.name}")

    @classmethod
    def from_config(cls, config: Config) -> "SLMClient":
        return cls(config)

    def get_current_branch(self, repo_path="."):
        repo = Repo(repo_path, search_parent_directories=True)
        config_reader = repo.config_reader()
        try:
            name = config_reader.get_value("user", "name")
        except Exception:
            name = None
        try:
            email = config_reader.get_value("user", "email")
        except Exception:
            email = None

        if repo.head.is_detached:
            return f"DETACHED_HEAD at {repo.head.commit.hexsha}", name, email

        return repo.active_branch.name, name, email

    # TODO: here i have a loop hole where if we go into the try logic and we successfully get the respond i am not logging it prperly
    def run_query(self):
        """
        Querying the SLM endpoint
        
        variables: This is a dictionary of variable that i declare inside of a query.

        So the variables defined inside of the query will be replaced by these values.
        This helps in having variable functionalities without hardcoding the queries.
        """
        try:    
            """Run a GraphQL query against the SLM endpoint"""
            with open(self.query_path, 'r') as f:
                query = f.read()

            current_branch, name, email = self.get_current_branch()
            variables = {
                        "branchName": current_branch, 
                         "owner": name }
            payload = {"operationName": 'BranchIteration',
                       "query": query, 
                       "variables": variables
                        }

            if name is None:
                raise Exception("No owner name is found.")

            # if variables:
            #     for key, value in variables.items():
            #         payload[key] = value

            response = Endpoint(
                service_url=f'{self.service_url}', 
                client=self.client
            ).make_post_request(
                url=self.service_url,
                body = payload
            )

            logging.info(f"The SLM was queries successfully and get the required output")


            try:
                response = json.loads(response.text)
                # checking any application level errors like: invalid field etc
                if "errors" in response.text:
                    return {
                        "status": "failed",
                        "reason": "GraphQL query error",
                        "details": json_data["errors"]
                    }

            
                #logging and saving the response after querying the SML
                logging.info(f"Logging and saving the response after querying the SLM")
                self._log_response(response)
                # If no errors → success
                return {
                    "status": "success",
                    "data": json_data.get("data")
                }

            except:
                logger.error(f"The response returned in not in form of valid JSON")
                logger.error(f"The returned response from HTTP request is: \n{response}")

        # if an exception occured while requesting the endpoint rety with exponential backoff
        except Exception as e:
            return self._retry_slm_request(payload)


    def _retry_slm_request(
        self, payload
    ):
        """Helper method to handle retries with exponential backoff."""
        retries = 5  # Maximum retries
        backoff_time = 60  # Initial backoff time in seconds

        while retries > 0:
            try:
                response = Endpoint(
                    service_url=f'{self.service_url}',
                    client=self.client
                ).make_post_request(
                    url=self.service_url,
                    body = payload
                )

                # Check if the final URL indicates a redirection to the login page
                if "login" in response.url.path:
                    raise HTTPStatusError(
                        "Redirected to login page. Reauthentication required.",
                        request=response.request,
                        response=response,
                    )

                if response.status_code == 400 and "invalid_grant" in response.text:
                    raise HTTPStatusError(
                        "Redirected to login page. Reauthentication required.",
                        request=response.request,
                        response=response,
                    )

                # self._log_response(response)
                try:
                    response = json.loads(response.text)
                    # checking any application level errors like: invalid field etc
                    if "errors" in response.text:
                        return {
                            "status": "failed",
                            "reason": "GraphQL query error",
                            "details": json_data["errors"]
                        }

                
                    #logging and saving the response after querying the SML
                    logging.info(f"Logging and saving the response after querying the SLM")
                    self._log_response(response)
                    # If no errors → success
                    return {
                        "status": "success",
                        "data": json_data.get("data")
                    }

                except:
                    logger.error(f"The response returned in not in form of valid JSON")
                    logger.error(f"The returned response from HTTP request is: \n{response}")

            except (
                RemoteProtocolError,
                ReadTimeout,
                HTTPError,
                HTTPStatusError,
            ) as exc:
                if isinstance(exc, HTTPStatusError):
                    logger.info("Redirect to login page detected. Reauthenticating...")
                    self.client = SSOPassport().run(
                        service_url=f"{self.service_url}",
                        username=self.username,
                        ds_tenant = self.ds_tenant,
                        password=self.password,
                        asynchronous=False,
                    )
                retries -= 1
                logger.warning(
                    f"{type(exc).__name__} occurred while querying SLM: {str(exc)}. "
                    f"Retries left: {retries}. Retrying in {backoff_time} seconds. Backoff time: {backoff_time * 2} seconds."
                )
                if retries == 0:
                    logger.error(
                        f"Max retries reached for querying SLM. Last error: {str(exc)}."
                    )
                    raise
                time.sleep(backoff_time)
                backoff_time *= 2  # Exponential backoff

            except RequestError as exc:
                logger.error(
                    f"RequestError occurred while requesting {exc.request.url!r} while querying: {str(exc)}"
                )
                raise


    def save_response(self, response, filename="slm_output.json"):
        """Save JSON response locally"""
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(response, f, indent=2)
        print(f"Saved output to {filename}")


    # TODO: Add a try catch in case the response is not a valid JSON
    def _log_response(self, response: Response):
        """Log the response from the API."""
        if response.status_code == 200:
            try:
                logger.info(
                    f"Call with status_code={response.status_code} and body response:\n{json.dumps(json.loads(response.text), indent=4)}"
                )
                response = response.text
                self.save_response(response)
            except json.decoder.JSONDecodeError:
                logger.error(f"Response is not a valid JSON: {response.text}")
        else:
            logger.error(
                f"Call with status_code={response.status_code} and body response:\n{response.text}"
            )
