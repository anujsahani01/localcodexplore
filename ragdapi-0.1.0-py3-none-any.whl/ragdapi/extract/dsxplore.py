#!/usr/bin/python
from __future__ import print_function
import codecs
import getopt
import getpass 
import io
import netrc
import os
import platform
import re
import requests
import socket
import sys
import time
try:
    import six.moves.urllib as urllib
except ImportError:
    import urllib


"""
    The dsxploreCli allows the user to search in DSXplore engine
    using command line.You can use it on Linux or Windows
    operating systems.
"""


SERVICE_URL = 'mashup-ui/xref_ap'
DEFAULT_PWD = 'PUT-YOUR-APPLICATION-PASSWORD-HERE'
if os.getenv('HOME') is None:
    if os.getenv('USERPROFILE') is None:
        print('Please set HOME environment variable before launching this script',file=sys.stderr)
        sys.exit(2)
    os.environ['HOME'] = os.getenv('USERPROFILE')

# from Python 3.1
if hasattr(sys.stdout, 'detach'):
  sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding = 'utf-8')
  sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding = 'utf-8')
else:
  sys.stdout = codecs.getwriter('utf8')(sys.stdout)
  sys.stderr = codecs.getwriter('utf8')(sys.stderr)

params = {'server': 'https://dsxplore.dsone.3ds.com/' + SERVICE_URL}

def main():
    try:
        postContent, debug = argsProcess(sys.argv[1:])
        url = re.search(r'https?://([\w\.\-]+)/.*', params['server'])
        host = url.group(1)
        home = os.environ['HOME']
        
        # On Windows, prefer _netrc - if it exists - over .netrc
        if sys.platform == 'win32' and (os.path.exists(home + os.path.sep + "_netrc") or not os.path.exists(home + os.path.sep + ".netrc")):
            netrcFileName = '_netrc'
        else:
            netrcFileName = '.netrc'
        netrcFilePath = home + os.path.sep + netrcFileName
        if not os.path.exists(netrcFilePath):
            print('Error: file ' + netrcFilePath + ' is missing!')
            print('... Creating ' + netrcFilePath)
            user = os.getenv('USERNAME') 
            if user is None:
              user = os.getenv('USER')
            with open(netrcFilePath, 'w') as netrcFile:
               netrcFile.write('machine dsxplore.dsone.3ds.com login ' + user.lower() + ' password ' + DEFAULT_PWD)
            print('Please replace ' + DEFAULT_PWD + ' with a valid application password in ' + netrcFilePath)
            appPwdUsage()
        netRC = netrc.netrc(netrcFilePath)
        authTokens = netRC.authenticators(host)
        if authTokens is None:
            print('No credentials provided for ' + host + ' in ' + netrcFilePath, file=sys.stderr)
            sys.exit(2)
        if (DEFAULT_PWD == authTokens[2]):
            print('Please replace ' + DEFAULT_PWD + ' with a valid application password in ' + netrcFilePath)
            appPwdUsage()
        if debug:
            print('Debug>> SERVER : %s' % params['server'])
            print('Debug>> COMMAND : %s ' % postContent)
    except getopt.error as msg:
        print(msg, file=sys.stderr)
        print('for help use --help', file=sys.stderr)
        sys.exit(2)
    if not postContent:
        print('Error in argument parsing: empty command.', file=sys.stderr)
        print('Use --help for command usage.', file=sys.stderr)
        sys.exit(2)
    page = 0
    headers = {}
    headers['content-type'] = 'application/x-www-form-urlencoded'
    headers['page'] = str(page)
    headers['clientVersion'] = '2.3|PY'
    headers['clientos'] = platform.system()
    headers['user'] = getpass.getuser() + '@' + platform.node()
    moreResults = True
    try:
        while moreResults:
            for ii in range(params['retries']+1):
                try:
                    headers['page'] = str(page)
                    resp = requests.post(params['server'], data=postContent, headers=headers, auth=(authTokens[0].lower(),authTokens[2]))
                    if debug:
                        print('Debug>> ############ Request ################')
                        print('Debug>> Request headers      : %s' % headers)
                        print('Debug>> Request url          : %s' % params['server'])
                    if debug:
                        print('Debug>> ############ Response ################')
                        print('Debug>> Response status code : %s' % resp.status_code)
                        print('Debug>> Response headers     : %s' % resp.headers)
                    if resp.status_code != 200:
                        print('We failed with HTTP status: ' + str(resp.status_code), file=sys.stderr)
                        if 401 == resp.status_code:
                            print('Please check your credentials in ' + netrcFilePath, file=sys.stderr)
                            appPwdUsage()
                            sys.exit(2)
                        time.sleep(params['waitTimeBetweenTrials']/1000)
                        continue
                    moreResults = True if 'moreResults' in resp.headers and 'true' == resp.headers['moreResults'] else False;
                    cmdStatus = -1 if ('cmdStatus' in resp.headers and '0' != resp.headers['cmdStatus']) or 'errorOutput' in resp.headers else 0               
                    out = resp.text
                    if (params['jsonOutput'] and page > 0):
                        out = out[1:]
                    if (params['jsonOutput'] and 0 == cmdStatus and moreResults):                        
                        out = out[:-1] + ','
                    if debug:
                        print('Debug>> ############ Response DATA ################')                    
                    print(out, end='')
                    sys.stdout.flush()
                    if 'errorOutput' in resp.headers:
                        print(urllib.parse.unquote_plus(resp.headers['errorOutput']), file=sys.stderr)
                    if debug:
                        print('Debug>> ############ Next page ################')               
                    resp.close()
                    canRetry = True if 'canRetry' in resp.headers and 'true' == resp.headers['canRetry'] else False;
                    if 0 == cmdStatus or not canRetry:
                        page += 1
                        break
                except Exception as e:
                    sys.stdout.flush()                
                    if (ii == params['retries']):
                        raise
                    print(e, file=sys.stderr)
                    time.sleep(params['waitTimeBetweenTrials']/1000)               
    except Exception as e:
        try:
            resp = requests.post(params['server'], headers=headers, data='cmd=-ping')
        except Exception as e_ping:
            print('No response from server %s\n%s' % (params['server'], e_ping), file=sys.stderr)
            sys.exit(2)
        print('We failed with exception %s.' % e, file=sys.stderr)
        sys.exit(2)

def appPwdUsage():
    print('Read https://dsxplore.dsone.3ds.com/mashup-ui/page/xrefcmdline for more details.', file=sys.stderr)
    sys.exit(2)

def argsProcess(args):
    debug = False
    serverUrl = None
    postContent = ''
    params['retries'] = 0
    params['waitTimeBetweenTrials'] = 30000
    params['jsonOutput'] = False
    ii = 0
    while ii < len(args):
        if args[ii] in ('-server', '--server'):
            if (ii+1 >= len(args)):
                print('You should provide a correct server url like: http://vddspexadsy.dsone.3ds.ds:10000/. Otherwise remove -server parameter.', file=sys.stderr)
                sys.exit(2)
            serverUrl = args[ii+1]
            rgxSimpleMachineName = re.compile(r'^\w+$')
            mSimpleMachineName = rgxSimpleMachineName.search(serverUrl)
            if mSimpleMachineName:
                params['server'] = 'http://' + socket.getfqdn(serverUrl) + '/' + SERVICE_URL
            else:
                regex = re.compile(
                    r'^https?://'    # http:// or https://
                    r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain...
                    r'localhost|'    # localhost...
                    r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
                    r'(?::\d+)?'     # optional port
                    r'(?:/?|[/?]\S+)$', re.IGNORECASE)
                if regex.search(serverUrl) and SERVICE_URL not in serverUrl:
                    params['server'] = serverUrl + ('' if serverUrl[-1] == '/' else '/') + SERVICE_URL
                else:
                    print('Unknown server ' + serverUrl, file=sys.stderr)
                    sys.exit(2)
            ii += 2
        elif args[ii] in ('-retries', '--retries'):
            if (ii+1 >= len(args)) or not args[ii+1].isdigit() or not int(args[ii+1])>0:
                print('You should specify a number of retries for the --retries option.')
                sys.exit(2)
            params['retries'] = int(args[ii+1])
            ii += 2
        elif args[ii] in ('-wait', '--wait'):
            if (ii+1 >= len(args)) or not args[ii+1].isdigit() or not int(args[ii+1])>0:
                print('You should specify a duration in milliseconds for the --wait option.')
                sys.exit(2)
            params['waitTimeBetweenTrials'] = int(args[ii+1])
            ii += 2       
        else:
            if args[ii] in ('-jsondbg', '--jsondbg', '-j', '-json', '--json'):
                params['jsonOutput'] = True          
            if args[ii] in ('-d', '-debug', '--debug'):
                debug = True
            else:
                postContent += ('' if ii == 0 else '&') + 'cmd=' + urllib.parse.quote_plus(args[ii])
            ii += 1
    return postContent, debug


if __name__ == '__main__':
    main()
