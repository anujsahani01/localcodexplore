#!/usr/bin/python
from __future__ import print_function
import codecs
import getopt
import getpass
import io
import netrc
import os
import platform
import re
import requests
import socket
import sys
import time
import json
import os
import shlex

try:
    import six.moves.urllib as urllib
except ImportError:
    import urllib
from pathlib import Path


"""
    The dsxploreCli allows the user to search in DSXplore engine
    using command line.You can use it on Linux or Windows
    operating systems.
"""


import os
import json

# To deactivate transformers warnings
os.environ["TRANSFORMERS_VERBOSITY"] = "error"
import platform

import sys
import logging

# from ragdapi.transform.transformer import Transformer
from ragdapi.utils.logger import setup_logging
from ragdapi.utils.udf import parse_args
from ragdapi.utils.config_utils import (
    list_config_files,
    load_config,
    get_config_selection,
    validate_config_selection,
)

logger = logging.getLogger(__name__)

def generate_command(folders, extension, patterns, config, modified_paths, cli_filepaths, cli_extensions):
    import os
    import platform
    import shlex
    from pathlib import Path

    if platform.system().lower() == "windows":
        start_path = Path(config.paths.root)
        if start_path == Path("."):
            start_path = Path(os.getcwd())

        # Normalize inputs
        extension = [ext if ext.startswith(".") else f".{ext}" for ext in extension]
        folders = [os.path.normpath(f) for f in folders]
        patterns = [os.path.normpath(p) for p in patterns]

        query_parts = []

        query_parts.append(f'Set-Location "{start_path}"')
        query_parts.append("$files = Get-ChildItem -Recurse -File")

        # ---- Include specific filepaths ----
        def _add_includes(paths):
            arr = "@(" + ",".join(f'"{start_path / Path(p)}"' for p in paths) + ")"
            query_parts.append(f"$includeFiles = {arr}")
            query_parts.append(
                "$files = $files | Where-Object { $includeFiles -contains $_.FullName }"
            )

        # if config.extract.localxplore.filepaths:
        #     _add_includes(config.extract.localxplore.filepaths)

        if cli_filepaths:
            _add_includes(cli_filepaths)
        elif config.extract.localxplore.filepaths:
            _add_includes(config.extract.localxplore.filepaths)


        if modified_paths:
            _add_includes(modified_paths)

        # ---- Include extensions ----
        # if config.extract.localxplore.extensions:
        #     ext_include = " -or ".join(
        #         f'$_.Extension -eq ".{ext}"'
        #         for ext in config.extract.localxplore.extensions
        #     )
        #     query_parts.append(f"$files = $files | Where-Object {{ {ext_include} }}")


        effective_extensions = None

        if cli_extensions:
            effective_extensions = cli_extensions
        elif config.extract.localxplore.extensions:
            effective_extensions = config.extract.localxplore.extensions

        if effective_extensions:
            ext_include = " -or ".join(
                f'$_.Extension -eq ".{ext}"'
                for ext in effective_extensions
            )
            query_parts.append(f"$files = $files | Where-Object {{ {ext_include} }}")


        # ---- Folder exclusions (SAFE) ----
        if folders:
            folders_array = "@(" + ",".join(f'"{f}"' for f in folders) + ")"
            query_parts.append(f"$excludeFolders = {folders_array}")
            query_parts.append(
                "$files = $files | Where-Object { "
                "$rel = Resolve-Path $_.FullName -Relative; "
                "foreach ($f in $excludeFolders) { "
                "$esc = [regex]::Escape($f); "
                "if ($rel -match \"(^|\\\\)$esc(\\\\|$)\") { return $false } "
                "} return $true }"
            )

        # ---- Extension exclusions ----
        if extension:
            ext_exclude = " -and ".join(
                f'$_.Extension -ne "{ext}"' for ext in extension
            )
            query_parts.append(f"$files = $files | Where-Object {{ {ext_exclude} }}")

        # ---- Pattern exclusions (glob-style) ----
        if patterns:
            patterns_array = "@(" + ",".join(
                f'"*{p.lstrip("*")}"' for p in patterns
            ) + ")"

            query_parts.append(f"$ignorePatterns = {patterns_array}")

            query_parts.append(
                "$files = $files | Where-Object { "
                "$rel = (Resolve-Path $_.FullName -Relative) "
                "-replace '^[.\\\\/]+',''; "
                "$rel = $rel -replace '\\\\','/'; "
                "-not ($ignorePatterns | Where-Object { $rel -like $_ }) "
                "}"
            )

        # ---- Output ----
        query_parts.append(
            "$files | ForEach-Object { "
            "[PSCustomObject]@{ "
            "windowsfullpath = $_.FullName; "
            "RelativePath   = Resolve-Path $_.FullName -Relative; "
            "LastModified   = $_.LastWriteTime; "
            'Extension      = $_.Extension.TrimStart("."); '
            "} } | ForEach-Object { $_ | ConvertTo-Json -Compress }"
        )

        full_script = "; ".join(query_parts)
        return ["powershell", "-Command", full_script]

    # ===================== LINUX =====================

    else:
        start_path = Path(config.paths.root)
        if start_path == Path("."):
            start_path = Path(os.getcwd())

        find_parts = ["find", shlex.quote(str(start_path)), "-type", "f"]

        # ---- Include filepaths ----
        # if config.extract.localxplore.filepaths:
            # find_parts.append("(")
            # for i, p in enumerate(config.extract.localxplore.filepaths):
            #     if i > 0:
            #         find_parts.append("-o")
            #     find_parts += ["-path", shlex.quote(str(start_path / Path(p)))]
            # find_parts.append(")")

        effective_filepaths = cli_filepaths or config.extract.localxplore.filepaths

        if effective_filepaths:
            find_parts.append("(")
            for i, p in enumerate(effective_filepaths):
                if i > 0:
                    find_parts.append("-o")
                find_parts += ["-path", shlex.quote(str(start_path / Path(p)))]
            find_parts.append(")")


        # ---- Include extensions ----
        # if config.extract.localxplore.extensions:
        #     find_parts.append("(")
        #     for i, ext in enumerate(config.extract.localxplore.extensions):
        #         if i > 0:
        #             find_parts.append("-o")
        #         ext = ext if ext.startswith("*") else f"*.{ext.lstrip('.')}"
        #         find_parts += ["-name", shlex.quote(ext)]
        #     find_parts.append(")")

        effective_extensions = cli_extensions or config.extract.localxplore.extensions

        if effective_extensions:
            find_parts.append("(")
            for i, ext in enumerate(effective_extensions):
                if i > 0:
                    find_parts.append("-o")
                ext = ext if ext.startswith("*") else f"*.{ext.lstrip('.')}"
                find_parts += ["-name", shlex.quote(ext)]
            find_parts.append(")")


        # ---- Folder exclusions ----
        for folder in folders:
            folder = folder.rstrip("/\\")
            find_parts += [
                "-not",
                "-path",
                shlex.quote(str(start_path / folder / "*")),
            ]

        # ---- Extension exclusions ----
        for ext in extension:
            ext = ext if ext.startswith("*") else f"*.{ext.lstrip('.')}"
            find_parts += ["-not", "-name", shlex.quote(ext)]

        # ---- Pattern exclusions ----
        for pattern in patterns:
            norm = os.path.normpath(pattern).replace("\\", "/")
            find_parts += [
                "-not",
                "-path",
                shlex.quote(f"{start_path}/{norm}"),
            ]

        find_cmd = " ".join(find_parts)

        shell_block = rf"""
{find_cmd} | while read -r filepath; do
  rel_path=$(realpath --relative-to="{start_path}" "$filepath")
  last_modified=$(stat -c %y "$filepath")
  ext="${{filepath##*.}}"
  jq -n --arg unixfullpath "$filepath" \
        --arg rp "$rel_path" \
        --arg lm "$last_modified" \
        --arg ext "$ext" \
        '{{unixfullpath:$unixfullpath, RelativePath:$rp, LastModified:$lm, Extension:$ext}}'
done
"""
        return ["bash", "-c", shell_block]
