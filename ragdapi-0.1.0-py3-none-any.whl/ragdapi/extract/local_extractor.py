import sys
import os
import json
import logging
import requests
import platform
import transformers
import pandas as pd
from tqdm import tqdm
from io import StringIO
from pathlib import Path
from itertools import chain
from bs4 import BeautifulSoup
from subprocess import PIPE, Popen
from multiprocessing import Pool
from typing import List, Set, Optional, Callable
from concurrent.futures import ProcessPoolExecutor
from ragdapi.schemas.config import Config
from ragdapi.transform.chunkers.utils.processor_swagger import generate_markdown
import subprocess
from ragdapi.extract.cwdxplore import generate_command
from git import Repo
import sqlite3
import hashlib
import time
import csv
from ragdapi.utils.udf import parse_args
import ast


logger = logging.getLogger(__name__)


class LocalXploreArguments:
    def __init__(
        self,
        all_files: bool,
        index_ignore_rules: Optional[str],
        max_files: Optional[int],
    ) -> None:
        """Constructor for LocalXploreArguments

        :param all_files: This will help in in exracting all th files from the local
        :param index_ignore_rules: Points to the file which contains all the folders entension and path patterns to be ignored while extraction
        :param max_files: Optional for mentioning the number of files to be extrcated
        """
        self.windowsxplore_script = (
            Path(__file__).parent / "cwdxplore.py"
        )
        if not self.windowsxplore_script.exists():
            raise FileNotFoundError(
                f"cwdxplore.py was not found in {Path(__file__).parent}. You may contact AI84"
            )

        self.all_files = all_files
        self.index_ignore_rules = index_ignore_rules if index_ignore_rules else None
        self.max_files = max_files if max_files else None



class LocalExtractor:
    def __init__(self, config: Config):
        """Constructor for Extractor

        :param config:
        """
        self.config = config
        self.extract_output = config.paths.extract_output
        self.args = LocalXploreArguments(
            config.extract.localxplore.all_files,
            config.extract.localxplore.index_ignore_rules,
            config.extract.localxplore.max_files,
        )
        self.dataframe = None

        logger.info(f"Extractor initialized with config: {self.config.name}")

    @classmethod
    def from_config(cls, config: Config) -> "LocalExtractor":
        return cls(config)
    
    def feature_engineering(self, df):
        """
        title | file_path | unixfullpath | windowsfullpath | file_name | file_extension | displayurl | 
        levelpath | tool_level | release_type | brand_name | owner | fw_owner | framework | 
        scopepath | scm_file_id | classimpl | lastmodifieddate
        """

        """
        'windowsfullpath' | 'unixfullpath' | 'RelativePath' | 'LastModified' | 'Extension'
        """
        df = df.rename(columns={'RelativePath': 'file_path', 'LastModified': 'lastmodifieddate', 'Extension': 'file_extension'})
        return df
    

    def _write_checkpoint(self, batch, checkpoint_file):
        with open(checkpoint_file, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            for item in batch:
                writer.writerow([
                    item.get("windowsfullpath") or item.get("unixfullpath"),
                    item.get("RelativePath"),
                    item.get("LastModified"),
                    item.get("Extension"),
                ])

    def extract_metadata_from_local(
        self, folders, extension, patterns, modified_paths, workspace_path, cli_filepaths, cli_extensions, args, checkpoint_path: Optional[Path] = None
    ) -> "LocalExtractor":

        logger.info("Started extraction from CWDXplore")

        # command = generate_command(
        #     folders, extension, patterns, self.config, modified_paths
        # )


        command = generate_command(
            folders,
            extension,
            patterns,
            self.config,
            modified_paths,
            cli_filepaths=cli_filepaths,
            cli_extensions=cli_extensions,
        )
        logger.debug(f"The query used for local extraction is : {command}")

        process = Popen(
            command,
            stdout=PIPE,
            stderr=PIPE,
            text=True,
            bufsize=1,
        )

        if checkpoint_path is None:
            # e.g.  <workspace_path>/Local_metadata.ckpt
            checkpoint_path = os.path.join(workspace_path, "Local_metadata.ckpt")


        with Popen(command, stdout=PIPE, stderr=PIPE, text=True, bufsize=1) as proc, open(checkpoint_path, "a", newline="", encoding="utf-8") as ckpt_file:
            csv_writer = None  # will be created after we see the first record

            for line in proc.stdout:          # iterate line‑by‑line (streaming)
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    logger.warning(f"Unable to parse JSON line: {line}")
                    continue

                # Initialise CSV writer on first record –‑ we need the header order
                if csv_writer is None:
                    fieldnames = list(record.keys())
                    csv_writer = csv.DictWriter(
                        ckpt_file, fieldnames=fieldnames, extrasaction="ignore"
                    )
                    # Write header only if the file is empty
                    if ckpt_file.tell() == 0:
                        csv_writer.writeheader()

                # Append the record to the checkpoint file
                csv_writer.writerow(record)

            # Capture any stderr after the loop finishes
            err = proc.stderr.read()
            if err:
                logger.info(f"cwdXplore stderr: {err.strip()}")

            # Ensure the subprocess exited cleanly
            proc.wait()
            if proc.returncode != 0:
                raise RuntimeError(
                    f"cwdXplore exited with code {proc.returncode}. "
                    f"Check {checkpoint_path} for partial results."
                )

        logger.debug(f"Loading checkpoint file {checkpoint_path}")
        self.dataframe = pd.read_csv(checkpoint_path)
        logger.info(f"The first instance of dataframe is created with columns: {self.dataframe.columns.to_list()}")
        logger.info(f"The shape of the first metadata dataframe is {self.dataframe.shape}")

        # ------------------------------------------------------------------
        # 5️⃣  Run the same ETL step you already had.
        # ------------------------------------------------------------------
        if self.config.extract.localxplore:
            self.dataframe = self.feature_engineering(self.dataframe)

        logger.info(
            f"Extraction of {len(self.dataframe)} documents' metadata from Local "
            f"ended successfully (checkpoint saved at {checkpoint_path})"
        )
        return self

        # records = []
        # processed = 0
        # batch_size = 100
        # checkpoint_file = Path(os.path.join(workspace_path, "local_checkpoint.csv"))
        # start_time = time.time()

        # # Create CSV header if not exists
        # if not checkpoint_file.exists():
        #     with open(checkpoint_file, "w", newline="", encoding="utf-8") as f:
        #         writer = csv.writer(f)
        #         writer.writerow(
        #             ["fullpath", "file_path", "lastmodifieddate", "file_extension"]
        #         )

        # for line in process.stdout:
        #     line = line.strip()
        #     if not line:
        #         continue

        #     try:
        #         record = json.loads(line)
        #     except json.JSONDecodeError:
        #         continue

        #     records.append(record)
        #     processed += 1

        #     # Respect max_files
        #     if self.args.max_files and processed >= self.args.max_files:
        #         logger.info(f"Reached max_files limit: {self.args.max_files}")
        #         break

        #     # Log progress
        #     if processed % 50 == 0:
        #         elapsed = time.time() - start_time
        #         speed = processed / elapsed if elapsed > 0 else 0
        #         logger.info(
        #             f"Processed {processed} files | Speed: {speed:.2f} files/sec"
        #         )

        #     # Checkpoint every 100 files
        #     if len(records) >= batch_size:
        #         self._write_checkpoint(records, checkpoint_file)
        #         logger.info(f"Checkpoint saved at {processed} files")
        #         records = []

        # # Write remaining
        # if records:
        #     self._write_checkpoint(records, checkpoint_file)

        # process.wait()

        # logger.info(f"Extraction complete. Total files: {processed}")

        # # Load checkpoint CSV into dataframe instead of giant JSON
        # self.dataframe = pd.read_csv(checkpoint_file)

        # if self.config.extract.localxplore:
        #     self.dataframe = self.feature_engineering(self.dataframe)

        # logger.info(
        #     f"Extraction of {len(self.dataframe)} documents' metadata from Local ended successfully"
        # )

        # return self

    def flatten_single_element_lists(self) -> "LocalExtractor":
        """Flatten single-element lists in all the columns of dataframe"""
        logger.debug("Flattening single elements lists")
        if self.dataframe is None:  
            raise ValueError("self.dataframe must not be None")

        self.dataframe = self.dataframe.apply(
            lambda x: x.map(
                lambda y: y[0] if isinstance(y, list) and len(y) == 1 else y
            )
        )
        return self

    def extract_documents_content(
        self, encodings: Optional[List[str]] = ["utf-8", "latin-1", "windows-1252"]
    ) -> "LocalExtractor":
        """Extract the content of each document and save them to dataframe.

        This method iterates through the file paths in the dataframe, attempts to read each file
        using the specified encodings, and stores the content in a new column named 'content'.
        If a file cannot be read using any of the specified encodings, an error message is logged,
        and an empty string is stored in the 'content' column for that file.

        :param encodings: A list of encodings to try when reading the files. Default is ["utf-8", "latin-1", "windows-1252"].
        :type encodings: Optional[List[str]]okay so
        :return: The Extractor instance with the 'content' column in dataframe.
        :rtype: LocalExtractor
        """
        logger.debug("Extracting documents content")
        if self.dataframe is None or len(self.dataframe) == 0:
            raise ValueError("self.dataframe must not be None or empty")
        logger.info(f"The shape of the extracted dataframe without content is :{self.dataframe.shape}")
        os_name = platform.system()
        logger.info(f"The OS platform we are using is {os_name}")
        full_path_column = ""
        if os_name == "Windows":
            full_path_column = "windowsfullpath"
            if full_path_column not in self.dataframe.columns.to_list():
                full_path_column = "unixfullpath"
        elif os_name == "Linux":
            full_path_column = "unixfullpath"

        if full_path_column not in self.dataframe.columns.to_list():
            full_path_column = "filepath"
            if full_path_column not in self.dataframe.columns.to_list():
                full_path_column = "file_path"

        if full_path_column in self.dataframe.columns:
            paths = self.dataframe[full_path_column].tolist()
        else:
            if not self.config.paths.extract_prefix_path:
                raise ValueError(
                    f"Column '{full_path_column}' is unavailable and 'extract_prefix_path' is not specified under 'paths' in the configuration"
                )
            try:
                paths = (
                    self.config.paths.extract_prefix_path / self.dataframe["file_path"]
                ).to_list()
            except KeyError as e:
                logger.error(
                    "Column 'file_path' does not exist in dataframe. Consider including it in the DSXplore query."
                )
                raise

        contents = []
        logger.info(f"We have in total {len(paths)} paths for every extracted file")
        logger.info(f"The paths looks like: {paths[0]}")
        for path in paths:
            decode_success = False
            file_not_found = False
            for encoding in encodings:
                try:
                    with open(path, "r", encoding=encoding) as file:
                        contents.append(file.read())
                        decode_success = True
                        break
                except FileNotFoundError:
                    logger.error(f"File not found: {path}")
                    contents.append("")
                    file_not_found = True
                    break
                except (UnicodeDecodeError, LookupError):
                    logger.warning(f"Failed to read {path} with encoding: {encoding}")

            if file_not_found:
                continue

            if not decode_success:
                with open(path, "r", encoding="utf-8", errors="replace") as file:
                    logger.error(
                        "All encodings failed. Reading with UTF-8 and errors='replace'"
                    )
                    contents.append(file.read())
        self.dataframe[self.config.extract.content_column] = contents
        return self


    @staticmethod
    def _count_code_blocks(html_content: str) -> int:
        """Count the number of <pre> tags with the class 'code' in HTML content.

        :param html_content: The HTML content to parse.
        :type html_content: str
        :return: The number of <pre class='code'> tags.
        :rtype: int
        """
        soup = BeautifulSoup(html_content, "lxml")
        pre_tags = soup.find_all("pre", class_="code")
        return len(pre_tags)


    def filter_dataframe(
        self, condition: Callable[[pd.DataFrame], pd.Series]
    ) -> "LocalExtractor":
        """Filter dataframe based on a condition.

        :param condition: A function that takes a DataFrame and returns a boolean Series for filtering.
        :return: The Extractor object with the filtered dataframe.
        """
        logger.debug(f"Filtering dataframe with condition: {condition}")
        if self.dataframe is None:
            raise ValueError("self.dataframe must not be None")
        self.dataframe = self.dataframe[condition(self.dataframe)]
        return self


    def get_current_branch(repo_path="."):
        repo = Repo(repo_path, search_parent_directories=True)
        config_reader = repo.config_reader()
        try:
            name = config_reader.get_value("user", "name")
        except Exception:
            name = None
        try:
            email = config_reader.get_value("user", "email")
        except Exception:
            email = None
        if repo.head.is_detached:
            return f"DETACHED_HEAD at {repo.head.commit.hexsha}", name, email

        return repo.active_branch.name, name, email


    def filter_extensions(self, extensions_set: Set[str]) -> "LocalExtractor":
        """Filter dataframe based on the extension of the files.
        Only keep rows where the file extension is in `extensions_set`.

        :param extensions_set: The set of extensions to keep.
        :return: The LocalExtractor object with the filtered dataframe.
        """
        logger.debug(f"Filtering dataframe based on extensions: {extensions_set}")
        if self.dataframe is None or len(self.dataframe) == 0:
            raise ValueError("self.dataframe must not be None or empty")

        # Extract the extensions from the 'file_path' column
        self.dataframe["extension"] = self.dataframe["file_path"].apply(
            lambda x: "".join(Path(x).suffixes)[1:] if Path(x).suffixes else ""
        )

        # Filter the dataframe based on the extensions
        self.dataframe = self.dataframe[
            self.dataframe["extension"].isin(extensions_set)
        ]

        # Drop the temporary 'extension' column
        self.dataframe.drop(columns=["extension"], inplace=True)

        return self

    def save_dataframe(self, save_path: Path = None, append: bool = False) -> None:
        """Save dataframe to a CSV file.

        :param save_path: CSV file path where to save dataframe.
                        If not provided, `self.config.paths.root / self.extract_output` is used by default.
        :param append: Whether to append to an existing CSV file. If the file does not exist,
                    it will write the header. If `append=False`, it will overwrite the file.
        """
        if self.dataframe is None:
            raise ValueError("self.dataframe must not be None")
        if save_path:
            if os.path.exists(save_path):
                save_path = save_path
            else:
                save_path = self.config.paths.root / self.config.paths.extract_output
        else:
            save_path = self.config.paths.root / self.config.paths.extract_output
        # Check if file exists
        file_exists = save_path.exists()

        if file_exists and append:
            logger.info(
                f"File '{save_path}' already exists, appending data without the header."
            )
        elif file_exists and not append:
            logger.warning(
                f"File '{save_path}' already exists, it will be overwritten."
            )

        try:
            # Determine the mode and header based on append and file existence
            mode = "a" if append else "w"
            write_header = not (append and file_exists)

            # Save dataframe to CSV
            self.dataframe.to_csv(
                save_path, mode=mode, index=False, header=write_header
            )
            logger.info(
                f"Dataframe (len={len(self.dataframe)}) successfully saved to '{save_path}'"
            )

        except PermissionError:
            logger.error(
                f"Permission denied when trying to save dataframe to '{save_path}'."
            )
            raise
        except FileNotFoundError:
            logger.error(f"File path '{save_path}' not found.")
            raise
        except Exception as e:
            logger.error(f"Failed to save dataframe to '{save_path}': {e}")
            raise

    def generate_hash(self, filepath, content):
        # combine path + content (so even same content in diff file has diff hash)
        data = (str(filepath) + str(content)).encode('utf-8')
        return hashlib.sha256(data).hexdigest()


    def _create_sqlite_db(self, df, table_name, version, con, cur, path_key):
        """
        is_chunked is a placeholder which will let us know if the file has already been chunked or not.
        0 - FALSE
        1 - TRUE
        as in SQLite there is no real bool value
        """
        cur.execute(f""" 
        CREATE TABLE IF NOT EXISTS "{table_name}" (
            file_hash TEXT PRIMARY KEY,
            windowsfullpath TEXT NOT NULL DEFAULT "",
            unixfullpath TEXT NOT NULL DEFAULT "",
            file_path TEXT,
            lastmodifieddate TEXT,
            file_extension TEXT,
            content TEXT,
            version INTEGER NOT NULL,
            is_chunked INTEGER NOT NULL DEFAULT 0
        )
        """)

        for _, row in df.iterrows():
            file_hash = self.generate_hash(str(row[path_key]), row['content'])
            cur.execute(f"""
                INSERT OR REPLACE INTO "{table_name}" 
                (file_hash, {path_key}, file_path, lastmodifieddate, file_extension, content, version)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (file_hash, str(row[path_key]), str(row['file_path']), row['lastmodifieddate'],
                row['file_extension'], row['content'], version))

        con.commit()


    # Function to insert new file record
    def _insert_file(self, df, table_name, con, cur, path_key):
        for ind, row in df.iterrows():
            # hash file content
            file_hash = self.generate_hash(str(row[path_key]), row['content'])

            # check if this path already exists
            cur.execute(f"SELECT version, file_hash FROM '{table_name}' WHERE {path_key} = ? ORDER BY version DESC LIMIT 1", (row[path_key],))
            db_row = cur.fetchone()
            if db_row:
                current_version, latest_file_id = db_row
                # Check if hash is same → no change
                if latest_file_id == file_hash:
                    logging.info(f"No change in {str(row[path_key])}, skipping insert.")
                    continue
                    
                # If changed, insert with version + 1
                # delete old entries for this file_hash
                cur.execute(f"DELETE FROM '{table_name}' WHERE file_hash = ?", (latest_file_id,))
                con.commit()
                new_version = current_version + 1

            else:
                # First time insertion
                new_version = 1

            cur.execute(f"""
                INSERT INTO "{table_name}" 
                (file_hash, {path_key}, file_path, lastmodifieddate, file_extension, content, version)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (file_hash, str(row[path_key]), str(row['file_path']), row['lastmodifieddate'],
                row['file_extension'], row['content'], new_version))

            con.commit()
    
    
    def run_pipeline(
        self,
        folders: Optional[List[str]] = None,
        extension: Optional[List[str]] = None,
        patterns: Optional[List[str]] = None,
        modified_filepaths: Optional[List[str]] = None,
        workspace_path: str = None,
        version:int = None,
        construct_output_path: bool = False,
    ) -> "LocalExtractor":
        """
        Orchestrate full Local extraction pipeline.
        """
        output_path = None
        if construct_output_path:
            name = f"Local_{extension or ''}.csv"
            output_path = self.config.paths.root / self.config.paths.extract_output / name


        args = parse_args()

        cli_filepaths = None
        cli_extensions = None

        if args.filepaths:
            # cli_filepaths = [p.strip() for p in args.filepaths.split(",") if p.strip()]
            cli_filepaths = [e.strip().lstrip(".") for e in json.loads(args.filepaths)]

        if args.extensions:
            # cli_extensions = [e.strip().lstrip(".") for e in args.extensions.split(",") if e.strip()]
            print(f"The extensions coming from cli looks like: {args.extensions} and the type is {type(args.extensions)}")
            cli_extensions = [e.strip().lstrip(".") for e in args.extensions]

        try:
            logger.info(f"Start Extracting metadata from local")
            self.extract_metadata_from_local(folders, extension, patterns, modified_filepaths, workspace_path, cli_filepaths, cli_extensions, args).flatten_single_element_lists()
            # TODO
            # if extensions_set:
            #     self.filter_extensions(extensions_set)
        except ValueError as e:
            logger.error(e)
            return
        
        try:
            logger.info(f"Starting the extraction of content from the extracted set of files.")
            self.extract_documents_content()
        except ValueError as e:
            logger.error(e)
            return
        for col in self.config.extract.count_tokens_columns:
            args = self.config.extract.tokenizer_args
            if args:
                self.count_column_number_tokens(col, **args.model_dump())

        for cond in self.config.extract.filter_conditions:
            self.filter_dataframe(cond)

        # TODO: THIS WILL ONLY SUPPORT ONE FRAMEWORK AT A TIME i.e., there will be only one table for extracted files unlike csv where we had different csv for different frameworks
        if self.config.extract.localxplore.get_sqlite_format:
            if output_path is None:
                output_path = os.path.normpath(self.config.paths.root / self.extract_output)
            
            workspace_path = str(os.path.normpath(Path(workspace_path))).split('\\')[-1]
            workspace_name = f"{workspace_path}_{version}"
            table_info = str(output_path).split('\\')[-1].split('.')[0]
            table_name = f"{workspace_name}_{table_info}"
            # setting up connection to db
            # Making the DB inside of home dir
            home_dir = Path.home()   # works on Windows, Linux, macOS
            my_lib_path = os.path.join(home_dir , ".LocalXplore")
            if not os.path.exists(my_lib_path):
                os.mkdir(my_lib_path)
            
            con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
            # creating curson for traversal
            cur = con.cursor()  
            """
            sqlite_master: is SQLite's internal catalog of tables, indexes, triggers, etc.
            """
            cur.execute("SELECT name from sqlite_master WHERE type = 'table' AND name =?;", (table_name,))
            tables = cur.fetchall()
            if platform.system().lower() == "linux":
                path_key = 'unixfullpath'
            elif platform.system().lower() == "windows":
                path_key = 'windowsfullpath'
            if not tables:
                self._create_sqlite_db(df = self.dataframe, table_name = table_name, version = 1, con = con, cur = cur, path_key = path_key)
            else:
                self._insert_file(df = self.dataframe, table_name = table_name, con = con, cur = cur, path_key = path_key)

        else:
            self.save_dataframe(output_path)

        return self