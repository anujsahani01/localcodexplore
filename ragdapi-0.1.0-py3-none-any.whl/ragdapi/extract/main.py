import os

from ragdapi.observability.in_process.decorators import Observability


# To deactivate transformers warnings
os.environ["TRANSFORMERS_VERBOSITY"] = "error"

import sys
import logging
from typing import Set
from pathlib import Path
from ragdapi.extract.extractor import Extractor
from ragdapi.extract.gitlab_extractor import GitLabExtractor
from ragdapi.extract.local_extractor import LocalExtractor
from ragdapi.schemas.config import Config
from ragdapi.utils.logger import setup_logging
from ragdapi.utils.udf import load_csv_column
from ragdapi.utils.udf import parse_args
from pydantic import ValidationError
from ragdapi.utils.config_utils import (
    list_config_files,
    load_config,
    get_config_selection,
    validate_config_selection,
    get_default_config_dir,
)
from ragdapi.extract.dsslm_loader import SLMClient
import json

# implementing gitignore like functionality
import pathspec

logger = logging.getLogger(__name__)


# TODO We may include some more advaced features if required.
def _read_indexignore(config, args) -> "pathspec":
    with open(
        os.path.join(args.workspace, config.extract.localxplore.index_ignore_rules),
        "r",
        encoding="utf-8",
    ) as f:
        data = f.read()
        lines = data.splitlines()
        spec = pathspec.PathSpec.from_lines(
            pathspec.patterns.GitWildMatchPattern, lines
        )
    return spec


def _index_ignore_extraction(spec):
    folders = []
    extension = []
    patterns = []

    for pattern in spec.patterns:
        raw = pattern.pattern.strip()

        if raw.startswith("#"):
            pass
        # extrcating folders
        elif raw.endswith("/"):
            if raw not in folders:
                folders.append(raw)
        elif raw.startswith("."):
            if raw not in extension:
                extension.append(raw)
        else:
            if raw not in patterns:
                patterns.append(raw)

    return folders, extension, patterns


def main(argv=None):
    args = parse_args(argv)
    setup_logging(args.debug, args.redirect)
    logging.debug("Running in DEBUG mode")

    try:
        config_files = list_config_files()
    except FileNotFoundError as e:
        logger.error(e)
        sys.exit(1)

    config_name = args.config
    if config_name:
        try:
            validate_config_selection(config_name, config_files)
        except ValueError as e:
            logger.error(f"Invalid config selection: {e}")
            sys.exit(1)
    else:
        config_name = get_config_selection(config_files)

    config = load_config(config_name)

    # WARNING: ONLY ONE EXTRACTOR CAN BE USED AT A TIME
    if config.extract.gitlab:
        GitLabExtractor.from_config(config).run_pipeline()

    elif config.extract.localxplore:
        # Laoding the patterns
        spec = _read_indexignore(config, args)

        # extracting requirements
        folders, extension, patterns = _index_ignore_extraction(spec)

        print(f"Folders to Ignore: \n{folders}")
        print(f"Extensions to Ignore: \n{extension}")
        print(f"Patterns to Ignore: \n{patterns}")

        # extracting metadata from DSSLM
        # response = SLMClient.from_config(config).run_query()

        config_dir = get_default_config_dir()
        config_file = config_dir / (config_name + ".json")
        if not config_file.exists():
            raise FileNotFoundError(f"The config file '{config_file}' does not exist.")

        with config_file.open("r") as f:
            config_dict = json.load(f)

        if config_dict.get("extract").get("localxplore"):
            if args.workspace is not None:
                if config_dict.get("paths").get("root"):
                    config_dict["paths"]["root"] = str(
                        os.path.normpath(Path(args.workspace))
                    )
                if config_dict.get("extract").get("localxplore").get("filepaths"):
                    config_dict["extract"]["localxplore"]["filepaths"] = args.filepaths

        try:
            config = Config(name=config_name, **config_dict)
        except ValidationError as e:
            logging.error(e)
            sys.exit(1)

        ############ TODO: Integrate output from SLM to chunks. Fix SLMClient code first. ##################
        # if config.extract.localxplore:
        #     if args.workspace is not None:
        #         if config.paths.root:
        #             config["paths"]["root"] = str(os.path.normpath(Path(args.workspace)))

        extractor = LocalExtractor.from_config(config)
        extractor.run_pipeline(
            folders=folders,
            extension=extension,
            patterns=patterns,
            modified_filepaths=args.filepaths,
            workspace_path=args.workspace,
            version=args.version,
            construct_output_path=False,
        )

        logger.info("Local Extraction pipeline completed")

    elif config.extract.dsxplore:
        # Get extensions and frameworks from the config
        extensions = config.extract.extensions
        frameworks = config.extract.frameworks
        sure_shot_binaries = config.extract.sure_shot_binaries
        # binary_extensions = config.extract.binary_exts

        # Get extensions and frameworks from a CSV file column
        if isinstance(extensions, Path):
            # TODO: make the column customizable
            extensions = load_csv_column(extensions, "extension")

        if isinstance(frameworks, Path):
            frameworks = load_csv_column(frameworks, "framework")

        if isinstance(sure_shot_binaries, Path):
            sure_shot_binaries = load_csv_column(sure_shot_binaries, "extensions")

        if frameworks or extensions:
            if not (config.paths.root / config.paths.extract_output).is_dir():
                raise ValueError(
                    "'root/extract_output' must be a valid directory when extensions or frameworks are given."
                )

        if frameworks and extensions:
            # Case 1: Both frameworks and extensions
            logger.info(
                f"The set of binary extensions we will be skipped before extraction are: "
            )
            skipped_exts = []
            for exts in extensions:
                if exts in sure_shot_binaries:
                    skipped_exts.append(exts)
            logger.info(
                f"\n_____________________\n{skipped_exts}\n_____________________\n"
            )
            extensions_set = set(extensions) - set(sure_shot_binaries)

            # so from the extensiosn set we will be removing the binary set of extensions

            logger.info(
                f"Processing {len(frameworks)} frameworks with {len(extensions)} extensions"
            )
            # binary_extensions_set = set(binary_extensions)

            for i, framework in enumerate(frameworks, 1):
                logger.info(f"Processing framework {i}/{len(frameworks)}: {framework}")
                if f"{framework}.csv" not in os.listdir(
                    os.path.join(config.paths.root, config.paths.extract_output)
                ):
                    extractor = Extractor.from_config(config)
                    extractor.run_pipeline(
                        framework=framework,
                        extension=None,
                        extensions_set=extensions_set,
                        construct_output_path=True,
                    )
                else:
                    logger.info(f"The framework {framework} is already extracted.")

        elif frameworks:
            # Case 2: Only frameworks
            logger.info(f"Processing {len(frameworks)} frameworks only")
            for i, framework in enumerate(frameworks, 1):
                if f"{framework}.csv" not in os.listdir(
                    os.path.join(config.paths.root, config.paths.extract_output)
                ):
                    logger.info(
                        f"Processing framework {i}/{len(frameworks)}: {framework}"
                    )
                    extractor = Extractor.from_config(config)
                    extractor.run_pipeline(
                        framework=framework,
                        extension=None,
                        extensions_set=None,
                        construct_output_path=True,
                    )

        elif extensions:
            # Case 3: Only extensions
            logger.info(f"Processing {len(extensions)} extensions only")
            for i, extension in enumerate(extensions, 1):
                logger.info(f"Processing extension {i}/{len(extensions)}: {extension}")
                if f"{extension}.csv" not in os.listdir(
                    os.path.join(config.paths.root, config.paths.extract_output)
                ):
                    extractor = Extractor.from_config(config)
                    extractor.run_pipeline(
                        framework=None,
                        extension=extension,
                        extensions_set=None,
                        construct_output_path=True,
                    )

        else:
            # Case 4: Neither frameworks nor extensions
            logger.info("Processing without specific frameworks or extensions")
            extractor = Extractor.from_config(config)
            extractor.run_pipeline(
                framework=None,
                extension=None,
                extensions_set=None,
                construct_output_path=False,
            )

    logger.info("Extraction pipeline completed")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
        logger.info("Program interrupted by user. Exiting gracefully. ✨")
