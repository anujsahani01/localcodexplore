import sys
import json
import logging
import requests
import platform
import transformers
import pandas as pd
from tqdm import tqdm
from io import StringIO
from pathlib import Path
from itertools import chain
from bs4 import BeautifulSoup
from subprocess import PIPE, Popen
from multiprocessing import Pool
from typing import List, Set, Optional, Callable
from concurrent.futures import ProcessPoolExecutor
from ragdapi.observability.in_process.decorators import Observability
from ragdapi.schemas.config import Config
from ragdapi.transform.chunkers.utils.processor_swagger import generate_markdown
from ragdapi.utils.config_utils import update_config_dsxplore_filters
from ragdapi.transform.chunkers.utils import ast_parsers_nodes as astcst
import asyncio
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import re
import os
from typing import List, Optional, Tuple, Any, Union


logger = logging.getLogger(__name__)


class DSXploreArguments:
    def __init__(
        self,
        query: str,
        filters: List[str],
        commands: Optional[dict],
        options: Optional[List[str]],
    ) -> None:
        """Constructor for DSXploreArguments

        :param query: The query to be used for the extraction
        :param filters: The filters to be used for the extraction
        :param commands: Optional dictionary of commands and their associated values
        :param options: Optional list of pure commands without values (like --json, --all)
        """
        self.dsxplore_script = self.dsxplore_script = (
            Path(__file__).parent / "dsxplore.py"
        )
        if not self.dsxplore_script.exists():
            raise FileNotFoundError(
                f"dsxplore.py was not found in {Path(__file__).parent}. You can download it from https://dsxplore.dsone.3ds.com/mashup-ui/resources/dsxplore.py.zip"
            )

        self.query = query
        self.filters = filters if filters else []
        self.commands = commands if commands else {}
        self.options = options

    def generate_command(self) -> List[str]:
        """Generate DSXplore command from arguments

        :return: DSXplore command
        :rtype: List[str]
        """

        list_commands = chain([[cmd, value] for cmd, value in self.commands.items()])

        return [
            sys.executable,
            "-X",
            "utf-8",
            str(self.dsxplore_script),
            self.query,
            *self.filters,
            *chain(*list_commands),
            *self.options,
        ]


class Extractor:
    def __init__(self, config: Config):
        """Constructor for Extractor

        :param config:
        """
        self.config = config
        self.extract_output = config.paths.extract_output
        self.args = DSXploreArguments(
            config.extract.dsxplore.query,
            config.extract.dsxplore.filters,
            config.extract.dsxplore.commands,
            config.extract.dsxplore.options,
        )
        self.dataframe = None

        logger.info(f"Extractor initialized with config: {self.config.name}")

    @classmethod
    def from_config(cls, config: Config) -> "Extractor":
        return cls(config)

    def extract_metadata_from_dsxplore(self) -> "Extractor":
        """Extract documents' metadata from DSXplore using the provided DSXploreArguments"""
        logger.info("Started extraction from DSXplore")
        self.args = DSXploreArguments(
            self.config.extract.dsxplore.query,
            self.config.extract.dsxplore.filters,
            self.config.extract.dsxplore.commands,
            self.config.extract.dsxplore.options,
        )
        logging.info(
            f"The DSXplore command is : {' '.join(self.args.generate_command())}"
        )
        process = Popen(self.args.generate_command(), stdout=PIPE, stderr=PIPE)
        out, err = process.communicate()
        if err:
            logger.info(f"DSXplore stderr: {err.decode('utf-8').strip()}")

        try:
            self.dataframe = pd.read_json(StringIO(out.decode("utf-8")))
            if self.config.extract.format_json:
                logger.info(
                    f"The json is being formatted where null values are being replaced by string"
                )
                self.dataframe = self.dataframe.where(
                    pd.notnull(self.dataframe), "null"
                )
            else:
                logger.info(
                    f"The json is not formatted so we are not converting Nan to string"
                )

            # exclusing binary files form getting chunked.
            if self.config.extract.skip_binaries:
                logger.info(f"We are skiping the binary extensions while extrcation")
                with open(self.config.extract.binary_exts, "r") as f:
                    binary_exts = json.load(f)
                for ind, rows in self.dataframe.iterrows():
                    if rows["file_extension"] in binary_exts["BINARY_EXTENSIONS"]:
                        self.dataframe.drop(ind, inplace=True)
                self.dataframe.reset_index(drop=True, inplace=True)
            else:
                logger.info(f"We are not skipping the binaries while extraction")

            if len(self.dataframe) == 200000:
                raise ValueError(f"DSXplore returned maximum 200000 number of results")
            logger.info(
                f"Extraction of {len(self.dataframe)} documents' metadata from DSXplore ended successfully"
            )
        except Exception as e:
            logger.error(
                f"Problem encountered when extracting metadata from DSXplore: {e}"
            )
            raise
        return self

    def flatten_single_element_lists(self) -> "Extractor":
        """Flatten single-element lists in all the columns of dataframe"""
        logger.debug("Flattening single elements lists")
        if self.dataframe is None:
            raise ValueError("self.dataframe must not be None")

        self.dataframe = self.dataframe.apply(
            lambda x: x.map(
                lambda y: y[0] if isinstance(y, list) and len(y) == 1 else y
            )
        )
        logging.info(
            f"The shape of the dataframe after flattening: {self.dataframe.shape}"
        )
        return self

    # Helpers
    def digit_heavy(self, decoded: str, numeric_threshold: float = 0.7) -> bool:
        cleaned = re.sub(r"[^\d\s\.,\-eE+]", "", decoded)
        total_chars = len(decoded)
        num_chars = len(cleaned)
        if total_chars == 0:
            return False
        return (num_chars / total_chars) > numeric_threshold

    def token_numeric_ratio(self, decoded: str, threshold=0.7) -> bool:
        tokens = re.split(r"\s+|,|;|\||\t", decoded)
        tokens = [t.strip() for t in tokens if t.strip()]
        if not tokens:
            return False
        numeric_tokens = [
            t
            for t in tokens
            if re.fullmatch(r"[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?", t)
        ]
        return (len(numeric_tokens) / len(tokens)) > threshold

    # Define byte-based binary detection
    def is_binary_string(
        self,
        content: Union[bytes, str],
        extension: str,
        df,
        extention_list: list,
        sure_shot_non_binaries: list,
        binary_threshold=0.3,
        numeric_threshold=0.8,
        encodings=["utf-8", "latin-1", "windows-1252"],
    ) -> bool:
        """
        This method is used to filter out the binary files or the files which has 80% of numerical chars in it.

        content: The original conten to of the file extracted
        binary_threshold: Means if the code file has more than 30% of non-asciii chars then if will be considered as binary
        numeric_threishold: Tf the file has more tha 70%  of numbers
        """
        if not content or str(content).lower in ["nan", "null", "none"]:
            return False  # Empty is not binary or numeric-heavy

        if extension in extention_list:
            logger.info(f"Skipping the exts: {extension}")
            return True
        # Convert string to bytes
        if isinstance(content, str):
            for encoding in encodings:
                try:
                    content = content.encode("utf-8", errors="ignore")
                    decode_success = True
                    break
                except FileNotFoundError:
                    logger.error(f"File not found: {df['filepath']}")
                    file_not_found = True
                    break
                except (UnicodeDecodeError, LookupError):
                    logger.warning(
                        f"Failed to read {df['filepath']} with encoding: {encoding}"
                    )

                if file_not_found:
                    continue
        else:
            return True

        # filtering large files into 8k chars
        sample = content[:8000]

        # Define valid text characters (ASCII)
        text_characters = bytearray({7, 8, 9, 10, 12, 13, 27} | set(range(0x20, 0x7F)))

        # Removing ASCII characters prsent in binary files.
        nontext = sample.translate(None, text_characters)
        binary_ratio = len(nontext) / len(sample)
        if binary_ratio > binary_threshold:
            return True

        # Filtering only number files
        try:
            decoded = sample.decode("utf-8", errors="ignore")
            printable_chars = [c for c in decoded if c.isprintable()]
            if not printable_chars:
                try:
                    decoded = sample.decode("utf-8", errors="ignore")
                    if not decoded.strip():
                        return False

                    # Enhanced digit-heavy heuristics
                    if self.digit_heavy(
                        decoded, numeric_threshold
                    ) or self.token_numeric_ratio(decoded, numeric_threshold):
                        return True
                except Exception:
                    pass

                return False  # Not enough data to decide

            num_digits = sum(c.isdigit() for c in printable_chars)
            digit_ratio = num_digits / len(printable_chars)
            if digit_ratio > numeric_threshold:
                if extension not in sure_shot_non_binaries:
                    return True  # Numeric-heavy file → classify as binary-like
                else:
                    return False
        except Exception:
            pass

        return False  # Not binary, not numeric-heavy → text

    async def is_binary_async(
        self, content, extension, executor, df, exts_list, sure_shot_non_binaries
    ):
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            executor,
            self.is_binary_string,
            content,
            extension,
            df,
            exts_list,
            sure_shot_non_binaries,
        )

    async def detect_binary_rows_async(
        self,
        df: pd.DataFrame,
        exts_list: List,
        sure_shot_non_binaries: List,
        content_col: str = "content",
        extension_col: str = "file_extension",
        max_workers: int = 10,
    ) -> pd.Series:
        executor = ThreadPoolExecutor(max_workers=max_workers)

        tasks = [
            self.is_binary_async(
                content, extension, executor, df, exts_list, sure_shot_non_binaries
            )
            for content, extension in zip(df[content_col], df[extension_col])
        ]

        results = await asyncio.gather(*tasks)
        return pd.Series(results, index=df.index)

    def extract_documents_content(
        self,
        name,
        encodings: Optional[List[str]] = ["utf-8", "latin-1", "windows-1252"],
    ) -> "Extractor":
        """Extract the content of each document and save them to dataframe.

        This method iterates through the file paths in the dataframe, attempts to read each file
        using the specified encodings, and stores the content in a new column named 'content'.
        If a file cannot be read using any of the specified encodings, an error message is logged,
        and an empty string is stored in the 'content' column for that file.

        :param encodings: A list of encodings to try when reading the files. Default is ["utf-8", "latin-1", "windows-1252"].
        :type encodings: Optional[List[str]]
        :return: The Extractor instance with the 'content' column in dataframe.
        :rtype: Extractor
        """
        logger.debug("Extracting documents content")
        if self.dataframe is None or len(self.dataframe) == 0:
            self.dataframe[self.config.extract.content_column] = ""
            raise ValueError("self.dataframe must not be None or empty")
        os_name = platform.system()
        full_path_column = ""
        if os_name == "Windows":
            full_path_column = "windowsfullpath"
            if full_path_column not in self.dataframe.columns.to_list():
                full_path_column = "unixfullpath"
        elif os_name == "Linux":
            full_path_column = "unixfullpath"

        if full_path_column in self.dataframe.columns:
            paths = self.dataframe[full_path_column].tolist()
        else:
            if not self.config.paths.extract_prefix_path:
                raise ValueError(
                    f"Column '{full_path_column}' is unavailable and 'extract_prefix_path' is not specified under 'paths' in the configuration"
                )
            try:
                paths = (
                    self.config.paths.extract_prefix_path / self.dataframe["file_path"]
                ).to_list()
            except KeyError as e:
                logger.error(
                    "Column 'file_path' does not exist in dataframe. Consider including it in the DSXplore query."
                )
                raise

        contents = []
        for path in paths:
            decode_success = False
            file_not_found = False
            for encoding in encodings:
                try:
                    with open(path, "r", encoding=encoding) as file:
                        contents.append(file.read())
                        decode_success = True
                        break
                except FileNotFoundError:
                    logger.error(f"File not found: {path}")
                    contents.append("")
                    file_not_found = True
                    break
                except (UnicodeDecodeError, LookupError):
                    logger.warning(f"Failed to read {path} with encoding: {encoding}")

            if file_not_found:
                continue

            if not decode_success:
                with open(path, "r", encoding="utf-8", errors="replace") as file:
                    logger.error(
                        "All encodings failed. Reading with UTF-8 and errors='replace'"
                    )
                    contents.append(file.read())
        self.dataframe[self.config.extract.content_column] = contents
        # dropping files with no content
        # TODO: Not skipping files without extensions
        # self.dataframe.dropna(subset=["file_extension"], inplace=True)
        self.dataframe.dropna(
            subset=[self.config.transform.column_to_chunk], inplace=True
        )
        # Inefficient Method to filter binary files
        # for idx, rows in df.iterrows():
        #     if filetype.guess(str(rows['content']).encode("utf-8")) is not None:
        #         df.drop(idx, inplace = True)
        if self.config.transform.skip_binaries:
            with open("./binary_exts.json", "r", encoding="utf-8") as f:
                data = json.load(f)

            exts_list_raw = list(set(data.get("BINARY_EXTENSIONS")))
            """
            Making sure that the binary extension list does not have any files which are non binary
            """
            sure_shot_non_binaries_df = pd.read_csv(
                self.config.extract.sure_shot_non_binaries
            )
            sure_shot_non_binaries = sure_shot_non_binaries_df["extensions"].to_list()
            exts_list = list(set(exts_list_raw) - set(sure_shot_non_binaries))
            binary_flags = asyncio.run(
                self.detect_binary_rows_async(
                    self.dataframe,
                    exts_list,
                    sure_shot_non_binaries,
                    content_col=self.config.transform.column_to_chunk,
                )
            )
            df_binary = self.dataframe[binary_flags == True]
            binary_exts = df_binary["file_extension"].tolist()
            logger.info(f"The list of binary extensions detected: {binary_exts}")
            with open("detected_binaries_exts.json", "w") as f:
                for item in binary_exts:
                    f.write(
                        f"{item}\n"
                    )  # Use an f-string to add a newline character after each item
            if df_binary is not None or len(df_binary) != 0:
                os.makedirs(
                    os.path.join(self.config.paths.root, "binaries"), exist_ok=True
                )
                df_binary.to_csv(
                    os.path.join(self.config.paths.root, f"binaries/{name}")
                )
            diff = set(binary_exts) - set(exts_list)
            # diff = list(diff)
            # Step 4: If new extensions found, update and write file
            if diff:
                updated_exts = list(set(exts_list).union(diff))
                data["BINARY_EXTENSIONS"] = updated_exts
                # with open("./binary_exts.json", "r", encoding = 'utf-8') as f:
                #     data = json.load(f)
                # exts = data.get('BINARY_EXTENSIONS')
                # exts.extend(binary_exts)
                # updated_set = list(set(exts))
                # data['BINARY_EXTENSIONS'] = updated_set

                with open("./binary_exts.json", "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=4)

            # removing binary files
            pre = len(self.dataframe)
            no_bins = self.dataframe[binary_flags == False]
            post = len(no_bins)
            logging.info(f"The number of binary files removed are: {int(pre-post)}")
        self.dataframe.reset_index(inplace=True)
        return self

    def add_number_code_blocks_column(self) -> "Extractor":
        """Add a column to dataframe that contains the number of <pre> tags
        with the class 'code' in the HTML content of the 'content' column.

        This method iterates through the 'content' column of dataframe,
        parses the HTML content using BeautifulSoup, counts the <pre> tags
        with the class 'code', and stores the result in a new column named
        'number_code_blocks'.

        :return: The Extractor instance with 'number_code_blocks' column in dataframe.
        """
        logger.debug("Addidng number_code_blocks column")
        if self.dataframe is None:
            raise ValueError("self.dataframe must not be None")

        if self.config.extract.content_column not in self.dataframe.columns:
            raise ValueError("Column 'content' must be in self.dataframe")

        tqdm.pandas(desc="Adding number_code_blocks")

        self.dataframe["number_code_blocks"] = self.dataframe[
            self.config.extract.content_column
        ].progress_apply(Extractor._count_code_blocks)

        return self

    @staticmethod
    def _count_code_blocks(html_content: str) -> int:
        """Count the number of <pre> tags with the class 'code' in HTML content.

        :param html_content: The HTML content to parse.
        :type html_content: str
        :return: The number of <pre class='code'> tags.
        :rtype: int
        """
        soup = BeautifulSoup(html_content, "lxml")
        pre_tags = soup.find_all("pre", class_="code")
        return len(pre_tags)

    def count_column_number_tokens(
        self,
        column_name: str,
        tokenizer_name: str,
        cache_dir: Path = None,
        api_url: str = None,
        api_key: str = None,
    ) -> "Extractor":
        """Count the number of tokens for all rows in 'column_name' column in dataframe
        and save the count in a new "number_tokens_{column_name}" column.
        If `api_url` and `api_key` are provided, counting the number of tokens is done
        via API calls (post requests) that request tokenization using `tokenizer_name`.
        Otherwise, the counting is done using `tokenizer_name` as a HuggingFace tokenizer
        (using `cache_dir` to load the tokenizer if provided).

        :return: The Extractor object with the 'number_tokens_{column_name}' column in dataframe.
        """
        logger.debug(
            f"Addidng number_tokens_{column_name} column with arguments: {tokenizer_name}, {cache_dir}, {api_url}, {api_key}"
        )
        if self.dataframe is None:
            raise ValueError("self.dataframe must not be None")

        if column_name not in self.dataframe.columns:
            raise ValueError(f"Column '{column_name}' must be in self.dataframe")

        if api_url and api_key:
            tqdm.pandas(desc="Counting tokens with remote tokenizer")
            try:
                self.dataframe[f"number_tokens_{column_name}"] = self.dataframe[
                    column_name
                ].progress_apply(
                    lambda x: Extractor._get_token_count_from_api(
                        x, tokenizer_name, api_url, api_key
                    )
                )
            except Exception as e:
                logger.error(f"Error while counting tokens with remote tokenizer: {e}")
        else:
            tokenizer = transformers.AutoTokenizer.from_pretrained(
                tokenizer_name, cache_dir=cache_dir
            )
            # NOTE: sequential code
            # tqdm.pandas(desc="Counting tokens with local tokenizer")
            # self.dataframe[f"number_tokens_{column_name}"] = self.dataframe[
            #     column_name
            # ].progress_apply(lambda x: len(tokenizer.tokenize(x)))

            # NOTE: multiprocess parallel code
            def count_tokens(text: str) -> int:
                return len(tokenizer.tokenize(text))

            try:
                # Uses all available CPU cores by default
                # with ProcessPoolExecutor() as executor:
                #     self.dataframe[f"number_tokens_{column_name}"] = list(
                #         tqdm(
                #             executor.map(
                #                 self._get_token_count,
                #                 self.dataframe[column_name],
                #             ),
                #             total=len(self.dataframe),
                #             desc="Counting tokens with local tokenizer",
                #         )
                #     )

                def init_pool_tokenizer(tokenizer_name: str, cache_dir: Path = None):
                    global global_tokenizer
                    global_tokenizer = transformers.AutoTokenizer.from_pretrained(
                        tokenizer_name, cache_dir=cache_dir
                    )

                with Pool(
                    initializer=init_pool_tokenizer,
                    initargs=(tokenizer_name, cache_dir),
                ) as pool:
                    results = list(
                        tqdm(
                            pool.imap(
                                Extractor._get_token_count,
                                self.dataframe[column_name].astype(str).values,
                            ),
                            total=len(self.dataframe),
                            desc=f"Counting tokens in {column_name} with local tokenizer",
                        )
                    )
                    self.dataframe[f"number_tokens_{column_name}"] = results
            except Exception as e:
                logger.error(f"Error counting tokens with local tokenizer: {e}")

        return self

    @staticmethod
    def _get_token_count(
        text: str,
    ) -> int:
        if not text:
            return 0
        return len(global_tokenizer.tokenize(text))

    @staticmethod
    def _get_token_count_from_api(
        text: str, tokenizer_model_name: str, api_url: str, api_key: str
    ) -> int:
        """Get the token count for a given text using an API.

        This static method sends a POST request to a specified API URL with the
        provided text and tokenizer model name, and returns the token count
        from the response.

        :param text: The text to tokenize.
        :type text: str
        :param tokenizer_model_name: The name of the tokenizer model to use.
        :type tokenizer_model_name: str
        :param api_url: The URL of the API to request the token count from.
        :type api_url: str
        :param api_key: The API key for authorization.
        :type api_key: str
        :return: The number of tokens in the text as determined by the API.
        :rtype: int
        :raises HTTPError: If the API request fails or returns an error status.
        """
        headers = {
            "accept": "application/json",
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        payload = {"model": tokenizer_model_name, "prompt": text}
        response = requests.post(api_url, json=payload, headers=headers)
        if response.status_code == 200:
            input_ids = response.json().get("input_ids", [])
            return len(input_ids)
        else:
            response.raise_for_status()

    def add_swagger(self) -> "Extractor":
        """Add a column to dataframe that contains id="swagger-ui" class
        in the HTML content of the 'content' column.

        This method iterates through the 'content' column of dataframe,
        parses the HTML content using BeautifulSoup, check the presence of
        a swagger key and stores the result as a boolean in a new column named
        'is_swagger'.

        :return: The Extractor instance with 'is_swagger' column in dataframe.
        """
        logging.debug("Addidng swagger boolean")
        if self.dataframe is None:
            raise ValueError("self.dataframe must not be None")

        if self.config.extract.content_column not in self.dataframe.columns:
            raise ValueError("Column 'content' must be in self.dataframe")

        tqdm.pandas(desc="Adding is_swagger")

        self.dataframe["is_swagger"] = self.dataframe[
            self.config.extract.content_column
        ].progress_apply(Extractor._is_swagger)

        return self

    @staticmethod
    def _is_swagger(html_content: str) -> bool:
        """Check is the html is a swagger"""
        soup = BeautifulSoup(html_content, "lxml")
        return len(soup.find_all(id="swagger-ui")) > 0

    def replace_swagger(self) -> "Extractor":
        """Replace content in rows where is_swagger is True with '###'.
        If the 'is_swagger' column doesn't exist, it will be computed first.

        :return: The Extractor instance with modified 'content' column.
        """
        logging.debug("Replacing swagger content")

        # Check if 'is_swagger' column exists, if not compute it
        if "is_swagger" not in self.dataframe.columns:
            logging.debug(
                "'is_swagger' column not found. Adding it by calling add_swagger."
            )
            self.add_swagger()

        # Ensure the dataframe has been filtered and processed properly
        if "is_swagger" not in self.dataframe.columns:
            raise ValueError(
                "Column 'is_swagger' must exist in dataframe after adding swagger."
            )

            # Apply the `process_swagger_content` function to the content where 'is_swagger' is True
        self.dataframe.loc[
            self.dataframe["is_swagger"], self.config.extract.content_column
        ] = self.dataframe.loc[
            self.dataframe["is_swagger"], self.config.extract.content_column
        ].apply(
            self._process_swagger_content
        )

        print("replacement done")
        return self

    @staticmethod
    def _process_swagger_content(html_content: str) -> str:
        """Process the swagger HTML content and return the modified content."""
        # Example processing: strip all HTML tags
        soup = BeautifulSoup(html_content, "lxml")
        # Find the <pre> tag with id 'api-content' and class 'code'
        pre_tag = soup.find("pre", {"class": "code", "id": "api-content"})

        if pre_tag:
            # Extract the text inside the <pre> tag (which should be the JSON)
            json_content = pre_tag.get_text(strip=True)
            try:
                # Parse the extracted JSON string into a Python dictionary
                json_dict = json.loads(json_content)
                return generate_markdown(json_dict)
            except json.JSONDecodeError:
                logging.error("Failed to decode JSON content")
                return {}  # Return an empty dict on JSON decode error
        else:
            logging.warning("No API content found in the Swagger HTML")
            return soup.get_text()

    def drop_columns(
        self,
        columns_to_drop: List[str] = [
            "mime",
            "icon_url",
            "did",
            "url",
            "type",
            "file_name_parts",
            "group_hit_number",
            "slice",
            "rank",
        ],
    ) -> "Extractor":
        """Drop `columns_to_drop` from dataframe.
        If a column is not found in dataframe columns, ignore it.

        :param columns_to_drop: Th list of columns to drop.
        :return: The Extractor object without dropped columns in dataframe.
        """
        logger.debug(f"Dropping columns {columns_to_drop}")
        if self.dataframe is None:
            raise ValueError("self.dataframe must not be None")
        self.dataframe.drop(columns=columns_to_drop, inplace=True, errors="ignore")
        return self

    def filter_dataframe(
        self, condition: Callable[[pd.DataFrame], pd.Series]
    ) -> "Extractor":
        """Filter dataframe based on a condition.

        :param condition: A function that takes a DataFrame and returns a boolean Series for filtering.
        :return: The Extractor object with the filtered dataframe.
        """
        logger.debug(f"Filtering dataframe with condition: {condition}")
        if self.dataframe is None:
            raise ValueError("self.dataframe must not be None")
        self.dataframe = self.dataframe[condition(self.dataframe)]
        return self

    def filter_extensions(self, extensions_set: Set[str]) -> "Extractor":
        """Filter dataframe based on the extension of the files.
        Only keep rows where the file extension is in `extensions_set`.

        :param extensions_set: The set of extensions to keep.
        :return: The Extractor object with the filtered dataframe.
        """
        logger.debug(f"Filtering dataframe based on extensions: {extensions_set}")
        if self.dataframe is None or len(self.dataframe) == 0:
            raise ValueError("self.dataframe must not be None or empty")

        # Extract the extensions from the 'file_path' column
        # self.dataframe["extension"] = self.dataframe["file_path"].apply(
        #     lambda x: "".join(Path(x).suffixes)[1:] if Path(x).suffixes else ""
        # )
        # changing this as we want only the last part of the extension
        self.dataframe["extension"] = self.dataframe["file_path"].apply(
            lambda x: Path(x).suffix[1:] if Path(x).suffix else ""
        )
        # Filter the dataframe based on the extensions
        self.dataframe = self.dataframe[
            self.dataframe["extension"].isin(extensions_set)
        ]

        # Drop the temporary 'extension' column
        self.dataframe.drop(columns=["extension"], inplace=True)

        return self

    def save_dataframe(self, save_path: Path = None, append: bool = False) -> None:
        """Save dataframe to a CSV file.

        :param save_path: CSV file path where to save dataframe.
                        If not provided, `self.config.paths.root / self.extract_output` is used by default.
        :param append: Whether to append to an existing CSV file. If the file does not exist,
                    it will write the header. If `append=False`, it will overwrite the file.
        """
        if self.dataframe is None:
            raise ValueError("self.dataframe must not be None")

        save_path = save_path or self.config.paths.root / self.extract_output
        # Check if file exists
        file_exists = save_path.exists()

        if file_exists and append:
            logger.info(
                f"File '{save_path}' already exists, appending data without the header."
            )
        elif file_exists and not append:
            logger.warning(
                f"File '{save_path}' already exists, it will be overwritten."
            )

        try:
            # Determine the mode and header based on append and file existence
            mode = "a" if append else "w"
            write_header = not (append and file_exists)

            # Save dataframe to CSV
            self.dataframe.to_csv(
                save_path, mode=mode, index=False, header=write_header
            )
            logger.info(
                f"Dataframe (len={len(self.dataframe)}) successfully saved to '{save_path}'"
            )

        except PermissionError:
            logger.error(
                f"Permission denied when trying to save dataframe to '{save_path}'."
            )
            raise
        except FileNotFoundError:
            logger.error(f"File path '{save_path}' not found.")
            raise
        except Exception as e:
            logger.error(f"Failed to save dataframe to '{save_path}': {e}")
            raise

    @Observability(component_type="extract")
    def run_pipeline(
        self,
        framework: Optional[str] = None,
        extension: Optional[str] = None,
        extensions_set: Optional[Set[str]] = None,
        construct_output_path: bool = False,
    ) -> "Extractor":
        """
        Orchestrate full extraction pipeline.
        """
        if framework and extension:
            raise ValueError("Only one of framework and extension can be provided.")
        if framework:
            logger.info(f"Extracting from framework: {framework}")
            update_config_dsxplore_filters(self.config, framework=framework)
            logger.debug(f"Updated DSXplore arguments: {self.config.extract.dsxplore}")
        if extension:
            logger.info(f"Extracting documents with extension: {extension}")
            update_config_dsxplore_filters(self.config, extension=extension)
            logger.debug(f"Updated DSXplore arguments: {self.config.extract.dsxplore}")


        # Generate output filename - used for binary file logging and optional output path
        name = f"{extension or ''}{framework or ''}.csv" if (extension or framework) else "extract.csv"
        output_path = None
        if construct_output_path:
            name = f"{extension or ''}{framework or ''}.csv"
            output_path = (
                self.config.paths.root / self.config.paths.extract_output / name
            )
        try:
            self.extract_metadata_from_dsxplore().flatten_single_element_lists()
            if extensions_set:
                self.filter_extensions(extensions_set)
        except ValueError as e:
            logger.error(e)
            return
        try:
            logger.info(f"The shape of the dataframe is {self.dataframe.head(5)}")
            self.extract_documents_content(name)
        except ValueError as e:
            logger.error(e)
            return
        for col in self.config.extract.count_tokens_columns:
            args = self.config.extract.tokenizer_args
            if args:
                self.count_column_number_tokens(col, **args.model_dump())
        if self.config.extract.number_code_blocks:
            self.add_number_code_blocks_column()
        if self.config.extract.swagger_count:
            self.add_swagger()
        if self.config.extract.swagger_replacement:
            self.replace_swagger()
        for cond in self.config.extract.filter_conditions:
            self.filter_dataframe(cond)
        if self.config.extract.drop_columns:
            self.drop_columns(self.config.extract.drop_columns)
        logging.info(f"Saving the extracted data at: {output_path}")
        self.save_dataframe(output_path)

        return self
