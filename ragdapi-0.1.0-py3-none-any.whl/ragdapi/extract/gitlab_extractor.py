import logging
import requests

import base64
import pandas as pd
from pathlib import Path
from ragdapi.schemas.config import Config
from ragdapi.transform.chunkers.utils.processor_swagger import generate_markdown

logger = logging.getLogger(__name__)

import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class GitLabExtractor:
    def __init__(self, config: Config):
        """Constructor for GitLabExtractor

        :param config:
        """
        self.config = config
        self.extract_output = config.paths.extract_output
        self.gitlab_args = config.extract.gitlab
        self.dataframe = None

        logger.info(f"GitLabExtractor initialized with config: {self.config.name}")

    @classmethod
    def from_config(cls, config: Config) -> "GitLabExtractor":
        return cls(config)

    def extract_metadata_from_gitlab(self) -> "GitLabExtractor":
        """Extract documents' metadata from GitLab"""
        logger.info("Started extraction from GitLab")

        tree_url = f"{self.gitlab_args.url}/api/v4/projects/{self.gitlab_args.project_id}/repository/tree"

        params = {
            "path": self.gitlab_args.folder_path,
            "ref": self.gitlab_args.branch,
            "per_page": 100,
            "recursive": "true" if self.gitlab_args.recursive else "false",
        }

        headers = {"PRIVATE-TOKEN": self.gitlab_args.private_token}

        try:
            # TODO: setting verify to False as a temporary fix, should be fixed
            response = requests.get(
                tree_url, headers=headers, params=params, verify=False
            )
            items = response.json()

            # Filter for files with the desired extension
            files = [
                item
                for item in items
                if item["type"] == "blob"
                and Path(item["name"]).suffix in self.config.extract.extensions
            ]

            # Filter out some file paths
            files = [
                item
                for item in files
                if item["name"] not in self.gitlab_args.exclude_paths
            ]

            self.dataframe = pd.DataFrame(files)
            self.dataframe[self.config.transform.code_file_extension] = self.dataframe[
                self.config.transform.code_file
            ].apply(lambda x: Path(x).suffix[1:] if Path(x).suffix else "")

            logger.info(
                f"Extraction of {len(self.dataframe)} documents' metadata from GitLab ended successfully"
            )

        except Exception as e:
            logger.error(
                f"Problem encountered when extracting metadata from GitLab: {e}"
            )
            raise
        return self

    def extract_documents_content(self) -> "GitLabExtractor":
        """Extract the content of each document and save them to dataframe.

        This method iterates through the file paths in the dataframe, and stores the content in a new column named 'content'.

        :return: The GitLabExtractor instance with the 'content' column in dataframe.
        :rtype: GitLabExtractor
        """
        logger.debug("Extracting documents content")
        if self.dataframe is None or len(self.dataframe) == 0:
            raise ValueError("self.dataframe must not be None or empty")

        path_column_name = "path"

        if not path_column_name in self.dataframe.columns:
            raise ValueError(f"Column '{path_column_name}' not found in dataframe")

        def get_file_content(path: str) -> str:
            encoded_path = requests.utils.quote(path, safe="")
            url = f"{self.gitlab_args.url}/api/v4/projects/{self.gitlab_args.project_id}/repository/files/{encoded_path}"
            params = {"ref": self.gitlab_args.branch}
            headers = {"PRIVATE-TOKEN": self.gitlab_args.private_token}
            try:
                response = requests.get(
                    url, headers=headers, params=params, verify=False
                )
                file_data = response.json()
                content = base64.b64decode(file_data["content"]).decode("utf-8")
                return content
            except Exception as e:
                logger.error(e)
                return ""

        self.dataframe[self.config.extract.content_column] = self.dataframe[
            path_column_name
        ].apply(get_file_content)

        return self

    def save_dataframe(self, save_path: Path = None, append: bool = False) -> None:
        """Save dataframe to a CSV file.

        :param save_path: CSV file path where to save dataframe.
                        If not provided, `self.config.paths.root / self.extract_output` is used by default.
        :param append: Whether to append to an existing CSV file. If the file does not exist,
                    it will write the header. If `append=False`, it will overwrite the file.
        """
        if self.dataframe is None:
            raise ValueError("self.dataframe must not be None")

        save_path = save_path or self.config.paths.root / self.extract_output

        # Check if file exists
        file_exists = save_path.exists()

        if file_exists and append:
            logger.info(
                f"File '{save_path}' already exists, appending data without the header."
            )
        elif file_exists and not append:
            logger.warning(
                f"File '{save_path}' already exists, it will be overwritten."
            )

        try:
            # Determine the mode and header based on append and file existence
            mode = "a" if append else "w"
            write_header = not (append and file_exists)

            # Save dataframe to CSV
            self.dataframe.to_csv(
                save_path, mode=mode, index=False, header=write_header
            )
            logger.info(
                f"Dataframe (len={len(self.dataframe)}) successfully saved to '{save_path}'"
            )

        except PermissionError:
            logger.error(
                f"Permission denied when trying to save dataframe to '{save_path}'."
            )
            raise
        except FileNotFoundError:
            logger.error(f"File path '{save_path}' not found.")
            raise
        except Exception as e:
            logger.error(f"Failed to save dataframe to '{save_path}': {e}")
            raise

    def run_pipeline(
        self, save_path: Path = None, append: bool = False
    ) -> "GitLabExtractor":
        """
        Orchestrate full GitLab extraction pipeline.
        """
        self.extract_metadata_from_gitlab()
        self.extract_documents_content()
        self.save_dataframe(save_path, append)
        return self
