import sys
import json
import logging
from typing import List
from pathlib import Path
from pydantic import ValidationError
from ragdapi.schemas.config import Config

logger = logging.getLogger(__name__)


def get_default_config_dir() -> Path:
    module_path = Path(__file__)
    module_directory = module_path.parent
    config_dir = module_directory / "../config"
    return config_dir.resolve()


def list_config_files(config_dir: Path = get_default_config_dir()) -> List[str]:
    """Return config names found under *config_dir* (including subdirectories).

    Each name is the path relative to *config_dir* without the ``.json``
    extension, e.g. ``"subfolder/my_config"``.
    """
    if not config_dir.exists():
        raise FileNotFoundError(
            f"The config directory '{config_dir}' does not exist. "
            f"Please create it and add at least one config file."
        )

    config_files = sorted(
        str(f.relative_to(config_dir).with_suffix(""))
        for f in config_dir.rglob("*.json")
        if f.is_file()
    )
    if not config_files:
        raise FileNotFoundError(
            f"No config files found in '{config_dir}' or its subdirectories. "
            f"Please add at least one config file."
        )

    return config_files


def load_config(
    config_name: str, config_dir: Path = get_default_config_dir()
) -> Config:
    """Load and validate a config by name.

    *config_name* may include forward-slash separated subdirectory
    components, e.g. ``"subfolder/my_config"``.
    """
    config_file = (config_dir / config_name).with_suffix(".json")
    if not config_file.exists():
        raise FileNotFoundError(f"The config file '{config_file}' does not exist.")

    with config_file.open("r") as f:
        config_data = json.load(f)

    try:
        config = Config(name=config_name, **config_data)
    except ValidationError as e:
        logging.error(e)
        sys.exit(1)

    return config


def validate_config_selection(config_name: str, config_files: List[str]):
    if config_name not in config_files:
        raise ValueError(
            f"Invalid config file selected: {config_name}. Available options are: {config_files}"
        )


def get_config_selection(config_files: List[str]) -> str:
    print("Available configuration files (without extensions):")
    for config_file in config_files:
        print(f"- {config_file}")

    config_name = input(
        "Please select a configuration file by entering its full name without the extension: "
    )
    config_name = config_name.strip()
    if config_name not in config_files:
        print(f"Invalid selection. Available options are: {config_files}")
        sys.exit(1)

    return config_name


def update_config_dsxplore_filters(
    config: Config, extension: str = None, framework: str = None
) -> Config:
    """Update configuration' DSXplore filters with extension and framework."""
    if extension:
        config.extract.dsxplore.filters = [
            f
            for f in config.extract.dsxplore.filters
            if not f.startswith("file_extension:")
        ]
        config.extract.dsxplore.filters.append(f"file_extension:{extension}")

    if framework:
        config.extract.dsxplore.filters = [
            f
            for f in config.extract.dsxplore.filters
            if not f.startswith("framework_category:")
        ]
        config.extract.dsxplore.filters.append(f"framework_category:{framework}")
