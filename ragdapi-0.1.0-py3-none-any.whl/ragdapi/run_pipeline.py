import os

# To deactivate transformers warnings
os.environ["TRANSFORMERS_VERBOSITY"] = "error"

import sys
import subprocess
import logging
from ragdapi.utils.logger import setup_logging
from ragdapi.utils.udf import parse_args
from ragdapi.utils.config_utils import (
    list_config_files,
    get_config_selection,
    validate_config_selection,
)

logger = logging.getLogger(__name__)


def run_step(script, config_name, debug, redirect):
    command = ["python", script, "--config", config_name]
    if debug:
        command.append("--debug")
    if redirect:
        command.extend(["--redirect", redirect])
    try:
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        logger.info(f"stderr: {result.stderr}")
    except subprocess.CalledProcessError as e:
        # If the subprocess fails, log the error and raise an exception
        logger.error(f"Subprocess failed with exit code {e.returncode}")
        logger.error(f"stderr: {e.stderr}")
        raise RuntimeError(f"Subprocess failed: {e}") from e


def main():
    args = parse_args()
    setup_logging(args.debug, args.redirect)

    try:
        config_files = list_config_files()
    except FileNotFoundError as e:
        logger.error(e)
        sys.exit(1)

    if args.config:
        config_name = args.config
        try:
            validate_config_selection(config_name, config_files)
        except ValueError as e:
            logger.error(e)
            sys.exit(1)
    else:
        config_name = get_config_selection(config_files)

    logger.info(f"Starting pipeline with configuration: {config_name}")

    try:
        run_step("ragdapi/extract/main.py", config_name, args.debug, args.redirect)
        run_step("ragdapi/transform/main.py", config_name, args.debug, args.redirect)
        run_step("ragdapi/map/main.py", config_name, args.debug, args.redirect)
        run_step("ragdapi/load/main.py", config_name, args.debug, args.redirect)
    except Exception as e:
        logger.error(
            f"An error occurred during the pipeline execution: {e}", exc_info=True
        )
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
        logger.info("Program interrupted by user. Exiting gracefully.")
