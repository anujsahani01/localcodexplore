"""
Common AWS utilities for observability.
Shared between all observability modules.
"""

import logging
import subprocess
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class ObservabilityAWSManager:
    """Unified AWS manager for observability uploads."""

    def __init__(self, aws_profile: str = "sbi_publisher"):
        self.aws_profile = aws_profile

    def upload_to_s3(self, local_file_path: Path, s3_bucket_path: str) -> bool:
        """
        Upload file to S3.
        
        Args:
            local_file_path: Local file to upload
            s3_bucket_path: S3 destination path
            
        Returns:
            True if successful, False otherwise
        """
        logger.info(f"Uploading {local_file_path} to {s3_bucket_path}")
        
        command = [
            "aws", "s3", "cp",
            str(local_file_path),
            s3_bucket_path,
            "--profile", self.aws_profile
        ]

        try:
            result = subprocess.run(args=command, capture_output=True, text=True)

            if result.returncode == 0:
                logger.info("AWS S3 upload successful")
                logger.debug(result.stdout)
                return True
            else:
                logger.error("AWS S3 upload failed")
                logger.error(result.stderr)
                return False
                
        except Exception as e:
            logger.error(f"Error during AWS S3 upload: {e}")
            return False

    @staticmethod
    def get_bucket_path_from_config(config_obj, component_type: str) -> Optional[str]:
        """Get AWS bucket path from configuration."""
        if not config_obj:
            return None
        
        try:
            component_config = getattr(config_obj, component_type, None)
            if component_config:
                observability_config = getattr(component_config, "observability", None)
                if observability_config:
                    aws_bucket_path = getattr(observability_config, "aws_bucket_path", None)
                    if aws_bucket_path:
                        logger.debug(f"Found component-specific AWS bucket path for {component_type}: {aws_bucket_path}")
                        return aws_bucket_path
        except (AttributeError, TypeError) as e:
            logger.debug(f"Error accessing component-specific config for {component_type}: {e}")
        
        logger.warning(f"No AWS bucket path found for component {component_type}")
        return None
