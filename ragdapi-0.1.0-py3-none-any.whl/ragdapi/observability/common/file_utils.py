"""
Common file processing utilities for observability.
Shared between in-process and post-process approaches.
"""

import json
import logging
from pathlib import Path
from typing import List

import pandas as pd

logger = logging.getLogger(__name__)


class ObservabilityFileProcessor:
    """Unified file processor for both decorator and post-process observability."""
    
    @staticmethod
    def load_file(file_path: Path) -> pd.DataFrame:
        """Load file into DataFrame."""
        if file_path.suffix.lower() == ".csv":
            return pd.read_csv(file_path)
        elif file_path.suffix.lower() == ".json":
            with open(file_path, 'r') as f:
                data = json.load(f)
            return pd.DataFrame(data)
        else:
            raise ValueError(f"Unsupported file type: {file_path.suffix}")
    
    @staticmethod
    def process_single_file(file_path: Path, content_column: str, collector):
        """Process a single file."""
        try:
            print(f"🔴🔴🔴Loading file: {file_path}")
            df = ObservabilityFileProcessor.load_file(file_path)
            logger.info(f"Processing {file_path.name} with {len(df)} records")
            collector.aggregate_all_stats(df, content_column)
        except Exception as e:
            logger.error(f"Error processing {file_path}: {e}")
            raise
    
    @staticmethod
    def process_directory(source_dir: Path, content_column: str, collector):
        """Process all files in a directory."""
        csv_files = list(source_dir.glob("*.csv"))
        json_files = list(source_dir.glob("*.json"))
        
        if not csv_files and not json_files:
            raise ValueError(f"No CSV/JSON files found in directory: {source_dir}")
        
        all_files = csv_files + json_files
        logger.info(f"Directory detected with {len(all_files)} files - processing")
        
        for file_path in all_files:
            try:
                ObservabilityFileProcessor.process_single_file(file_path, content_column, collector)
            except Exception as e:
                logger.error(f"Error processing {file_path}: {e}")
                continue
    
    @staticmethod
    def get_files_in_directory(source_dir: Path) -> List[Path]:
        """Get all processable files in a directory."""
        csv_files = list(source_dir.glob("*.csv"))
        json_files = list(source_dir.glob("*.json"))
        return csv_files + json_files