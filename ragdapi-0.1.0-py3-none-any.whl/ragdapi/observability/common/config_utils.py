"""
Common configuration utilities for observability.
Shared between in-process and post-process approaches.
"""

import json
import logging
from typing import Dict, Any, List, Optional
from pathlib import Path


logger = logging.getLogger(__name__)


class ObservabilityConfigHandler:
    """Unified configuration handler for both decorator and post-process observability."""
    
    @staticmethod
    def extract_observability_config(config_obj) -> Dict[str, Any]:
        """Extract observability configuration and convert to dict."""
        observability_config = getattr(config_obj, "observability", None)
        if observability_config is None:
            return {}
        
        # Convert Pydantic object to dict if needed
        if hasattr(observability_config, '__dict__'):
            return vars(observability_config)
        elif hasattr(observability_config, 'dict'):  # Pydantic method
            return observability_config.dict()
        elif isinstance(observability_config, dict):
            return observability_config
        else:
            return {}
    
    @staticmethod
    def extract_paths_config(config_obj):
        """Extract paths configuration."""
        return getattr(config_obj, "paths", None)
    
    @staticmethod
    def extract_filters(config_obj, component_type: str = None) -> List[str]:
        """Extract filters from config."""
        if hasattr(config_obj, "extract") and config_obj.extract:
            extract_config = config_obj.extract
            dsxplore_config = getattr(extract_config, "dsxplore", None)
            if dsxplore_config:
                return getattr(dsxplore_config, "filters", []) or []
        return []
    
    @staticmethod
    def get_content_column(config_obj, step: str) -> str:
        """Get content column name for a step."""
        if (step == "extract" and hasattr(config_obj, "extract") and 
            config_obj.extract and hasattr(config_obj.extract, "count_tokens_columns") and 
            config_obj.extract.count_tokens_columns):
            return config_obj.extract.count_tokens_columns[0]
        elif step == "transform":
            return "page_content"
        return "content"
    
    @staticmethod
    def get_data_type(config_obj) -> str:
        """Get data type from config."""
        if hasattr(config_obj, "observability") and config_obj.observability:
            return getattr(config_obj.observability, "type", "code")
        return "code"
    
    @staticmethod
    def get_extract_csv_path(config_obj, step: str, root_path):
        """Get extract CSV path for transform step."""
        if (step == "transform" and hasattr(config_obj, "paths") and 
            hasattr(config_obj.paths, "extract_output")):
            extract_path = Path(root_path) / config_obj.paths.extract_output
            logger.info(f"Using extract CSV for token preservation: {extract_path}")
            return extract_path
        return None
    
    @staticmethod
    def is_observability_enabled(config_obj) -> bool:
        """Check if observability is enabled."""
        observability_config = ObservabilityConfigHandler.extract_observability_config(config_obj)
        return ObservabilityConfigHandler.safe_get(observability_config, "launch_observability", False)
    
    @staticmethod
    def convert_to_dict(config_obj) -> Dict[str, Any]:
        """Convert config to dictionary."""
        try:
            if hasattr(config_obj, 'dict') and callable(getattr(config_obj, 'dict')):  # Pydantic
                return config_obj.dict()
            elif hasattr(config_obj, '__dict__'):
                return vars(config_obj)
            elif hasattr(config_obj, '_asdict'):
                return config_obj._asdict()
            elif isinstance(config_obj, dict):
                return config_obj
            else:
                return json.loads(json.dumps(config_obj, default=str))
        except Exception as e:
            logger.warning(f"Could not convert config to dictionary: {e}")
            return {}
    
    @staticmethod
    def safe_get(obj, key: str, default=None):
        """Safely get attribute/key from object or dict."""
        if obj is None:
            return default
        
        # Try dictionary-style access first
        if isinstance(obj, dict):
            return obj.get(key, default)
        
        # Try attribute access
        return getattr(obj, key, default)