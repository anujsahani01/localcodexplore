"""
Common validation utilities for observability.
"""

import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)


class ObservabilityValidator:
    """Unified validator for observability configurations."""
    
    @staticmethod
    def validate_config(config_obj) -> bool:
        """Validate required configuration."""
        if (not config_obj or not hasattr(config_obj, "observability") or 
            not config_obj.observability or
            not getattr(config_obj.observability, "launch_observability", False)):
            logger.info("Observability is not enabled.")
            return False
        
        if (not hasattr(config_obj, "paths") or not config_obj.paths or 
            not hasattr(config_obj.paths, "root")):
            logger.error("Missing required paths in config")
            return False
        
        return True
    
    @staticmethod
    def validate_step_config(requested_step: str, step_name: str, 
                           paths_config: Any, input_attr: str, output_attr: str) -> bool:
        """Check if a step should be processed."""
        if requested_step not in (step_name, "all"):
            return False
        
        if not hasattr(paths_config, input_attr):
            return False
        
        output_path = getattr(paths_config, output_attr, "")
        if not str(output_path).strip():
            logger.info(f"Skipping '{step_name}': empty {output_attr} in config")
            return False
        
        return True
    
    @staticmethod
    def get_processing_steps(config_obj, requested_step: str) -> List[str]:
        """Build list of processing steps to execute."""
        if not config_obj or not hasattr(config_obj, "paths"):
            return []
        
        steps = []
        paths_config = config_obj.paths
        
        # Define step configurations
        step_configs = {
            "extract": ("extract_output", "observability_extract_output"),
            "transform": ("transform_output", "observability_transform_output"),
            "map": ("map_output", "observability_map_output")
        }
        
        for step_name, (input_attr, output_attr) in step_configs.items():
            if ObservabilityValidator.validate_step_config(requested_step, step_name, paths_config, input_attr, output_attr):
                steps.append(step_name)
        
        return steps