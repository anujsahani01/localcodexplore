CONTENT_COLUMN = "content"
FILE_EXTENSION_COLUMN = "file_extension"
FRAMEWORK_COLUMN = "framework"
SCOPEPATH_COLUMN = "scopepath"
FILE_SIZE_COLUMN = "file_size"
NUMBER_TOKENS_COLUMN = "number_tokens"
IS_SWAGGER_COLUMN = "is_swagger"
NUMBER_CODE_BLOCKS_COLUMN = "number_code_blocks"
TITLE_COLUMN = "title"
RELEASE_COLUMN = "tool_level"
RELEASE_TYPE_COLUMN = "release_type"


RELEVANT_METADATA_FIELDS = [
    "title",
    "file_extension",
    "file_size",
    "framework",
    "classimpl",
    "mkcs_error_count",
    "is_cd_reflected_code",
    "lastmodifieddate",
]
