from multiprocessing import Pool
import json
import logging
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional
from pathlib import Path
import gc

from ragdapi.observability.collectors.extract_collector import ExtractStatsCollector
from ragdapi.observability.collectors.transform_collector import TransformStatsCollector 
from ragdapi.observability.collectors.code_collector import CodeStatsCollector
from ragdapi.observability.collectors.doc_collector import DocStatsCollector
from ragdapi.observability.common.aws_utils import ObservabilityAWSManager

from ragdapi.observability.common.config_utils import ObservabilityConfigHandler
from ragdapi.observability.common.validation_utils import ObservabilityValidator

logger = logging.getLogger(__name__)


# Custom JSON encoder to handle NumPy data types
class NumpyEncoder(json.JSONEncoder):
    """Custom JSON encoder for NumPy data types."""
    def default(self, o: Any) -> Any:
        """Override the default method to handle NumPy types and Path objects."""
        # Handle numpy integer types
        for numpy_type in [np.int8, np.int16, np.int32, np.int64, 
                          np.uint8, np.uint16, np.uint32, np.uint64]:
            if isinstance(o, numpy_type):
                return int(o)
                
        # Handle numpy floating types
        for numpy_type in [np.float16, np.float32, np.float64]:
            if isinstance(o, numpy_type):
                return float(o)
                
        # Handle other numpy types
        if isinstance(o, np.ndarray):
            return o.tolist()
        if isinstance(o, Path):
            return str(o)
        if pd.isna(o):
            return None
            
        return super().default(o)


def load_single_file_worker(file_path):
    """Worker function for parallel file loading using Pool."""
    try:
        if file_path.suffix.lower() == ".csv":
            return pd.read_csv(file_path)
        elif file_path.suffix.lower() == ".json":
            with open(file_path, 'r') as f:
                data = json.load(f)
            if isinstance(data, list):
                return pd.DataFrame(data)
            else:
                logger.warning(f"Skipping {file_path}: not a list")
                return None
    except Exception as e:
        logger.error(f"Error loading {file_path}: {e}")
        return None
    

class ObservabilityManager:
    """Manages observability statistics collection and persistence."""
    
    def __init__(self, output_path: Path, config: Optional[Dict[str, Any]] = None):
        self.output_path = output_path
        self.config = config
        self.aws_manager = ObservabilityAWSManager()
        
        if self.output_path.parent:
            self.output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Delegate to common utilities
    def extract_filters(self) -> List[str]:
        """Extract filters from config."""
        return ObservabilityConfigHandler.extract_filters(self.config)
    
    def get_content_column(self, step: str) -> str:
        """Get content column name for a step."""
        return ObservabilityConfigHandler.get_content_column(self.config, step)
    
    def get_extract_csv_path(self, step: str, root_path: Path) -> Optional[Path]:
        """Get extract CSV path for transform step."""
        return ObservabilityConfigHandler.get_extract_csv_path(self.config, step, root_path)
    
    def get_data_type(self) -> str:
        """Get data type from config."""
        return ObservabilityConfigHandler.get_data_type(self.config)
    
    def validate_config(self) -> bool:
        """Validate required configuration."""
        return ObservabilityValidator.validate_config(self.config)
    
    def build_processing_steps(self, requested_step: str) -> List[str]:
        """Build list of processing steps to execute."""
        return ObservabilityValidator.get_processing_steps(self.config, requested_step)
    
    def get_step_paths(self, step: str) -> tuple[Path, Path]:
        """Get input and output paths for a step."""
        if not self.config or not hasattr(self.config, "paths"):
            raise ValueError("Missing paths configuration")
        
        root_path = Path(self.config.paths.root)
        input_path = root_path / getattr(self.config.paths, f"{step}_output")
        output_path = root_path / getattr(self.config.paths, f"observability_{step}_output")
        
        return input_path, output_path
    
    def get_collector(self, collector_type: str, data_type: str, filters: Optional[List[str]] = None, extract_csv_path: Optional[Path] = None):
        """Get appropriate collector."""
        actual_filters = filters or []
        
        if collector_type == "extract":
            if data_type == "code":
                return CodeStatsCollector(self.output_path, actual_filters)
            elif data_type == "doc":
                return DocStatsCollector(self.output_path, actual_filters)
            else:
                return ExtractStatsCollector(self.output_path, actual_filters)
        elif collector_type == "transform":
            return TransformStatsCollector(self.output_path, actual_filters, extract_csv_path, config=self.config)
        else:
            return ExtractStatsCollector(self.output_path, actual_filters)

    def _process_files_streaming(self, all_files: List[Path], collector, content_column: str):
        """Process files in streaming mode"""
        total_files = len(all_files)
        # TODO: Make batch size configurable as an argument
        batch_size = 1  # Small batches to control memory
        num_workers = min(12, total_files)
        
        logger.info(f"Processing {total_files} files in streaming mode (batch_size={batch_size})")
        
        for i in range(0, total_files, batch_size):
            batch_files = all_files[i:i + batch_size]
            batch_num = i // batch_size + 1
            total_batches = (total_files + batch_size - 1) // batch_size
            
            logger.info(f"Batch {batch_num}/{total_batches}: processing {len(batch_files)} files")
            
            # Load current batch
            if len(batch_files) == 1:
                # Single file
                df = load_single_file_worker(batch_files[0])
                if df is not None:
                    # STREAMING: Process immediately without accumulation
                    collector.aggregate_all_stats(df, content_column)
                    del df  # Free immediately
            else:
                # Multiple files in batch
                with Pool(processes=num_workers) as pool:
                    # Process each file result as it comes
                    for df in pool.imap(load_single_file_worker, batch_files, chunksize=5):
                        if df is not None:
                            # STREAMING: Process immediately
                            collector.aggregate_all_stats(df, content_column)
                            del df  # Free immediately
            
            # Force garbage collection after each batch
            gc.collect()
            
            # Progress report
            processed_files = min((batch_num * batch_size), total_files)
            logger.info(f"Processed {processed_files}/{total_files} files, memory freed")
        
        logger.info(f"Streaming processing complete: {total_files} files processed")

    def collect_stats(
        self,
        collector_type: str,
        data_type: str,
        source: Optional[Path] = None,
        dataframe: Optional[pd.DataFrame] = None,
        filters: Optional[List[str]] = None,
        content_column: str = "content",
        extract_csv_path: Optional[Path] = None,
        config: Optional[Dict[str, Any]] = None
    ):
        """
        Collect statistics - uses streaming for large datasets.
        """
        # Store config for use by collectors
        if config:
            self.config = config
            
        logger.info(f"Collecting stats for {collector_type}")
        
        # Get the appropriate collector
        collector = self.get_collector(
            collector_type=collector_type,
            data_type=data_type,
            filters=filters,
            extract_csv_path=extract_csv_path
        )
        
        # Handle DataFrame vs source
        if dataframe is not None:
            # DataFrame provided - process normally
            logger.info(f"Processing provided DataFrame with {len(dataframe)} records")
            collector.aggregate_all_stats(dataframe, content_column)
            
        elif source is not None:
            # Source provided - check if streaming needed
            if source.is_file():
                # Single file - load and process
                if source.suffix.lower() == ".csv":
                    df = pd.read_csv(source)
                elif source.suffix.lower() == ".json":
                    with open(source, 'r') as f:
                        data = json.load(f)
                    df = pd.DataFrame(data)
                else:
                    raise ValueError(f"Unsupported file type: {source.suffix}")
                
                logger.info(f"Processing single file with {len(df)} records")
                collector.aggregate_all_stats(df, content_column)
                
            elif source.is_dir():
                # Directory - use streaming
                csv_files = list(source.glob("*.csv"))
                json_files = list(source.glob("*.json"))
                
                if not csv_files and not json_files:
                    raise FileNotFoundError(f"No CSV/JSON files found in directory: {source}")
                
                all_files = csv_files + json_files
                logger.info(f"Directory detected with {len(all_files)} files - using streaming mode")
                
                # STREAMING: Process files without accumulating DataFrames
                self._process_files_streaming(all_files, collector, content_column)
            else:
                raise ValueError(f"Source must be a file or directory, got: {source}")
        else:
            raise ValueError("Either source or dataframe must be provided")
        
        logger.info(f"Statistics collection completed for {collector_type}")
        return collector
    
    
    def save_observability_data(self, data: List[Dict[str, Any]]) -> None:
        """Save observability data to the configured path."""
        try:
            with open(self.output_path, 'w') as f:
                json.dump(data, f, indent=2, cls=NumpyEncoder)
            logger.info(f"Successfully saved observability data to {self.output_path}")
        except Exception as e:
            logger.error(f"Error saving observability data to {self.output_path}: {e}")
            raise
    
    def is_upload_to_aws_enabled(self) -> bool:
        """Check if AWS upload is enabled."""
        if self.config and hasattr(self.config, "observability") :
            return getattr(self.config.observability, "upload_to_aws")
             
        return False
    
    def upload_to_aws(self, s3_bucket_path: str) -> None:
        """Upload observability data to AWS S3."""
        try:
            success = self.aws_manager.upload_to_s3(self.output_path, s3_bucket_path)
            if success:
                logger.info(f"Successfully uploaded observability data to {s3_bucket_path}")
            else:
                raise Exception("Upload failed")
        except Exception as e:
            logger.error(f"Error uploading observability data to {s3_bucket_path}: {e}")
            raise
    
    def get_aws_bucket_path(self, step: str) -> Optional[str]:
        """Get AWS bucket path for a step."""
        return ObservabilityAWSManager.get_bucket_path_from_config(self.config, step)