#!/usr/bin/env python3
"""
Observability Pipeline Runner

This script runs observability analysis on files from the RAG data pipeline,
collecting metrics for extraction and transformation outputs.
"""

import argparse
import logging
import os
import sys
from pathlib import Path
from ragdapi.observability.manager.observability_manager import ObservabilityManager
from ragdapi.observability.common.config_utils import ObservabilityConfigHandler

from ragdapi.utils.logger import setup_logging
from ragdapi.utils.config_utils import list_config_files, load_config

logger = logging.getLogger(__name__)


def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description="RAG Data Pipeline Observability Runner")
    parser.add_argument("--config", type=str, help="Configuration file to use for observability")
    parser.add_argument(
        "--step", choices=["extract", "transform", "map", "all"], default="all",
        help="step to process: extract, transform, map, or all (default: all)"
    )
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    return parser.parse_args()


def select_config(config_name, config_files):
    """Select and validate configuration file."""
    if not config_name:
        return select_config_interactively(config_files)
    
    return validate_config_name(config_name, config_files)


def select_config_interactively(config_files):
    """Interactive configuration selection."""
    print("Available config files:")
    for i, config_file in enumerate(config_files, 1):
        print(f"{i}. {config_file}")
    
    selection = input("Enter config file name or number: ")
    try:
        index = int(selection) - 1
        if 0 <= index < len(config_files):
            return config_files[index]
        else:
            raise ValueError("Invalid selection")
    except ValueError:
        return validate_selection(selection.strip(), config_files)


def validate_selection(selection, config_files):
    """Validate user selection."""
    if selection in config_files:
        return selection
    elif selection + ".json" in config_files:
        return selection + ".json"
    else:
        logger.error(f"Config file not found: {selection}")
        sys.exit(1)


def validate_config_name(config_name, config_files):
    """Validate provided config name."""
    if config_name in config_files:
        return config_name
    elif config_name + ".json" in config_files:
        return config_name + ".json"
    elif os.path.exists(f"ragdapi/config/{config_name}"):
        return f"ragdapi/config/{config_name}"
    else:
        logger.error(f"Config file not found: {config_name}")
        sys.exit(1)


def process_step(manager: ObservabilityManager, step: str):
    """Process a single observability step."""
    logger.info(f"Processing {step} step")
    
    # Get paths from manager
    input_path, output_path = manager.get_step_paths(step)
    
    # Get step-specific configuration from manager
    data_type = manager.get_data_type()
    filters = manager.extract_filters()
    content_column = manager.get_content_column(step)
    extract_csv_path = manager.get_extract_csv_path(step, Path(manager.config.paths.root))
    
    # Collect statistics
    collector = manager.collect_stats(
        collector_type=step,
        data_type=data_type,
        source=input_path,
        filters=filters,
        content_column=content_column,
        extract_csv_path=extract_csv_path,
        config=manager.config
    )
    
    # Save results
    summary_data = collector.get_summary()
    manager.save_observability_data(summary_data)
    
    # Upload to AWS if configured
    if manager.is_upload_to_aws_enabled():
        aws_bucket_path = manager.get_aws_bucket_path(step)
        if aws_bucket_path:
            logger.info(f"Uploading data to AWS: {aws_bucket_path}")
            manager.upload_to_aws(aws_bucket_path)
        else:
            logger.warning(f"AWS upload enabled but no bucket path for {step}")
    
    logger.info(f"{step.capitalize()} observability completed successfully")


def main():
    """Main entry point."""
    args = parse_args()
    setup_logging(args.debug)
    
    if args.debug:
        logger.setLevel(logging.DEBUG)
    
    # Select and load configuration
    config_files = list_config_files()
    config_name = select_config(args.config, config_files)
    
    try:
        config = load_config(config_name)
    except Exception as e:
        logger.error(f"Error loading config: {e}")
        sys.exit(1)
    
    # Check if observability is enabled using common utility
    if not ObservabilityConfigHandler.is_observability_enabled(config):
        return
    
    # Initialize manager with config
    manager = ObservabilityManager(output_path=Path("temp"), config=config)
    
    # Build processing steps
    steps = manager.build_processing_steps(args.step)
    if not steps:
        logger.error("No components to process")
        sys.exit(1)
    
    # Process each step
    for step in steps:
        try:
            # Update manager output path for this step
            _, output_path = manager.get_step_paths(step)
            manager.output_path = output_path
            
            process_step(manager, step)
            
        except Exception as e:
            logger.error(f"Error processing {step}: {e}")
            sys.exit(1)
    
    logger.info("All observability analyses completed successfully")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Program interrupted. Exiting.")
        sys.exit(0)