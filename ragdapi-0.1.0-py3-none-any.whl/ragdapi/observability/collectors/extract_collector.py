import logging
import pandas as pd
from pathlib import Path
from typing import List, Dict, Any, Optional

from ragdapi.observability.collectors.base_collector import BaseStatsCollector

logger = logging.getLogger(__name__)


class ExtractStatsCollector(BaseStatsCollector):
    """
    Statistics collector for extract data.
    
    Collects and aggregates metrics related to document extraction, such as
    document counts, file extensions, file sizes, and token counts.
    """
    
    def __init__(self, output_path: Path, filters: Optional[List[str]] = None):
        """
        Initialize the extract collector.
        
        Args:
            output_path: Path to save output
            filters: Optional list of filters used during extraction
        """
        super().__init__(output_path, filters)

        self.total_documents = 0
        self.total_empty_content = 0
        self.file_extension_counts = {}

        self.all_file_sizes = []  # for quantile accumulation
        self.all_token_counts = []  # for quantile accumulation

        self.file_sizes = {}
        self.token_counts = {}

    def aggregate_all_stats(self, df: pd.DataFrame, content_column: str = "content"):
        """
        Perform all necessary aggregations on a DataFrame.
        
        Args:
            df: The DataFrame to analyze
            content_column: Name of the column containing document content
            
        Returns:
            self (for chaining)
        """
        logger.info("Aggregating statistics from DataFrame")
        
        # Extract metadata fields
        self._extract_metadata_fields(df)
        
        # Aggregate document counts
        self._aggregate_document_counts(df, content_column)
        
        # Aggregate file extension counts
        self._aggregate_file_extension_counts(df, content_column)
        
        # Aggregate file sizes
        self._aggregate_file_sizes(df)
        
        # Aggregate token counts
        self._aggregate_token_counts(df)
        
        return self
    
    def _extract_metadata_fields(self, df: pd.DataFrame):
        """Extract metadata fields from the DataFrame."""
        logger.debug("Extracting metadata fields")
        self.metadatas = list(set(self.metadatas + df.columns.tolist()))
    
    def _aggregate_document_counts(self, df: pd.DataFrame, content_column: str):
        """Aggregate document counts."""
        logger.debug("Aggregating document counts")
        self.total_documents += len(df)
        
        if content_column in df.columns:
            self.total_empty_content += df[content_column].isna().sum()
    
    def _aggregate_file_extension_counts(self, df: pd.DataFrame, content_column: str):
        """Aggregate file extension counts with filled/empty breakdown using vectorized operations."""
        logger.debug("Aggregating file extension counts")
        if "file_extension" in df.columns:
            if content_column not in df.columns:
                content_column = "text"
                logger.warning("Content column not found, using default value: text")
        
            ext_df = df[["file_extension", content_column]].copy()
            ext_df["file_extension"] = ext_df["file_extension"].astype(str)
            valid = ext_df["file_extension"].notnull() & ext_df["file_extension"].ne("nan") & ext_df["file_extension"].ne("")
            ext_df = ext_df[valid]
            grp = ext_df.groupby("file_extension")[content_column]
            stats = grp.agg(total="size", empty=lambda s: s.isna().sum())
            stats["filled"] = stats["total"] - stats["empty"]
            for ext, row in stats.iterrows():
                counts = {"empty": int(row["empty"]), "filled": int(row["filled"])}
                if ext in self.file_extension_counts:
                    self.file_extension_counts[ext]["empty"] += counts["empty"]
                    self.file_extension_counts[ext]["filled"] += counts["filled"]
                else:
                    self.file_extension_counts[ext] = counts
    
    def _aggregate_file_sizes(self, df: pd.DataFrame):
        """Aggregate file size statistics."""
        logger.debug("Aggregating file size statistics")
        
        if "file_size" in df.columns:
            numeric_sizes = pd.to_numeric(df["file_size"], errors='coerce')
            valid_sizes = numeric_sizes.dropna()
            
            if len(valid_sizes) > 0:
                self.all_file_sizes.extend(valid_sizes.tolist())
                
                all_sizes_series = pd.Series(self.all_file_sizes)
                
                self.file_sizes = {
                    "count": len(all_sizes_series),
                    "total": int(all_sizes_series.sum()),
                    "mean": float(all_sizes_series.mean()),
                    "median": float(all_sizes_series.median()),
                    "std": float(all_sizes_series.std()),
                    "min": float(all_sizes_series.min()),
                    "firstQuartile": float(all_sizes_series.quantile(0.25)),
                    "thirdQuartile": float(all_sizes_series.quantile(0.75)),
                    "max": float(all_sizes_series.max())
                }
                
                logger.debug(f"File size stats (ALL DATA): count={self.file_sizes['count']}, median={self.file_sizes['median']:.0f}")
            else:
                logger.warning("No valid file size data found")
        else:
            logger.debug("No file_size column found in DataFrame")

    def _aggregate_token_counts(self, df: pd.DataFrame):
        """Aggregate token count statistics."""
        logger.debug("Aggregating token count statistics")
        
        token_column = None
        for col_name in ["number_tokens_content", "number_tokens_text"]:
            if col_name in df.columns:
                token_column = col_name
                break
        
        if token_column:
            logger.debug(f"Found token column: {token_column}")
            
            numeric_data = pd.to_numeric(df[token_column], errors='coerce')
            valid_data = numeric_data.dropna()
            
            if len(valid_data) > 0:
                
                self.all_token_counts.extend(valid_data.tolist())
                
                
                all_tokens_series = pd.Series(self.all_token_counts)
                
                self.token_counts = {
                    "count": len(all_tokens_series),
                    "total": int(all_tokens_series.sum()),
                    "mean": float(all_tokens_series.mean()),
                    "median": float(all_tokens_series.median()),
                    "std": float(all_tokens_series.std()),
                    "min": float(all_tokens_series.min()),
                    "firstQuartile": float(all_tokens_series.quantile(0.25)),
                    "thirdQuartile": float(all_tokens_series.quantile(0.75)),
                    "max": float(all_tokens_series.max())
                }
                
                logger.debug(f"Token stats (ALL DATA): count={self.token_counts['count']}, median={self.token_counts['median']:.0f}")
            else:
                logger.warning(f"No valid data in token column: {token_column}")
        else:
            logger.debug("No token columns found in DataFrame")
    
    def get_summary(self) -> List[Dict[str, Any]]:
        """
        Get a summary of all extract statistics.
        
        Returns:
            List of statistics dictionaries for reporting
        """
        summary = self.get_base_summary("extract")
        
        # Add document content statistics
        summary.append({
            "uri": "document_content",
            "class": "content.DocumentContent",
            "total": self.total_documents,
            "empty": self.total_empty_content,
            "filled": self.total_documents - self.total_empty_content
        })
        
        # Add file extension statistics
        for ext, counts in self.file_extension_counts.items():
            summary.append({
                "uri": f"documents_per_file_extension_{ext}",
                "class": "documents.DocumentsPerFileExtension",
                "extension": ext,
                "empty": counts.get("empty", 0),
                "filled": counts.get("filled", 0),
                "total": counts.get("empty", 0) + counts.get("filled", 0)
            })
        
        # Add file size statistics
        if self.file_sizes:
            summary.append({
                "uri": "file_sizes",
                "class": "files.FileSizes",
                "summary": self.file_sizes
            })
        
        # Add token count statistics
        if self.token_counts:
            summary.append({
                "uri": "token_counts",
                "class": "tokens.TokenCounts",
                "summary": self.token_counts
            })
        
        return summary