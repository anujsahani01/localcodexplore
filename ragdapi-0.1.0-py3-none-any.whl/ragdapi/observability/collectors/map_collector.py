import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
import pandas as pd
import json

from ragdapi.observability.collectors.base_collector import BaseStatsCollector

logger = logging.getLogger(__name__)

class MapStatsCollector(BaseStatsCollector):
    """
    Statistics collector for map (mapping) step.
    
    Simple collector focusing on essential mapping metrics:
    - Number of mapped chunks
    - Schema template information
    """
    
    def __init__(self, output_path: Path, filters: Optional[List[str]] = None, config: Optional[Dict[str, Any]] = None):
        super().__init__(output_path, filters)
        self.config = config or {}
        
        # Core mapping metrics
        self.mapping_metrics = {
            "total_mapped_chunks": 0
        }
        
        # Schema template information
        self.schema_info = self._extract_schema_info()

    def _extract_schema_info(self) -> Dict[str, Any]:
        """
        Extract schema template information from config.
        
        Returns:
            Dictionary with schema information
        """
        schema_info = {
            "template_path": "",
            "template_name": "",
            "schema_fields": []
        }
        
        try:
            # Get template path from config
            map_config = self.config.get("map", {})
            template_path = map_config.get("schema_template_path", "")
            
            if template_path:
                schema_info["template_path"] = template_path
                schema_info["template_name"] = Path(template_path).name
                
                # Try to load the template to extract fields
                try:
                    full_path = Path(template_path)
                    if full_path.exists():
                        with open(full_path, 'r') as f:
                            template_content = json.load(f)
                            # Extract field names from template (assuming it's a dict with field keys)
                            if isinstance(template_content, dict):
                                schema_info["schema_fields"] = list(template_content.keys())
                        logger.info(f"Loaded schema template: {schema_info['template_name']} with {len(schema_info['schema_fields'])} fields")
                    else:
                        logger.warning(f"Schema template file not found: {template_path}")
                except Exception as e:
                    logger.warning(f"Could not load schema template: {e}")
            else:
                logger.warning("No schema template path found in config")
                
        except Exception as e:
            logger.error(f"Error extracting schema info: {e}")
            
        return schema_info

    def aggregate_all_stats(self, mapped_data: List[Dict[str, Any]]):
        """
        Aggregate essential map statistics from mapped data.
        
        Args:
            mapped_data: List of mapped chunk dictionaries
            
        Returns:
            self (for chaining)
        """
        logger.info("Aggregating map statistics from %d mapped chunks", len(mapped_data))
        
        # Simple count of mapped chunks
        self.mapping_metrics["total_mapped_chunks"] = len(mapped_data)
        
        return self

    def get_summary(self) -> List[Dict[str, Any]]:
        """
        Get summary organized by class for downstream ingestion.
        
        Returns:
            List of statistics dictionaries organized by class
        """
        summary = self.get_base_summary("map")
        
        # 1. config.Arguments - Map configuration
        summary.append({
            "uri": "map_config",
            "class": "config.Arguments",
            "filters": self.filters,
            "template_path": self.schema_info["template_path"],
            "template_name": self.schema_info["template_name"]
        })
        
        # 2. mapping.ChunkCount - Simple chunk count
        summary.append({
            "uri": "mapped_chunks",
            "class": "mapping.ChunkCount",
            "total_mapped_chunks": self.mapping_metrics["total_mapped_chunks"]
        })
        
        # 3. schema.TemplateInfo - Schema template information
        summary.append({
            "uri": "schema_template",
            "class": "schema.TemplateInfo",
            "template_path": self.schema_info["template_path"],
            "template_name": self.schema_info["template_name"],
            "schema_fields": self.schema_info["schema_fields"],
            "field_count": len(self.schema_info["schema_fields"])
        })
        
        return summary