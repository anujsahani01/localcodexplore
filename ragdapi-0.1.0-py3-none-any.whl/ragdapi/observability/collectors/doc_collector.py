import logging
import pandas as pd
from pathlib import Path
from typing import List, Dict, Any, Optional
from collections import defaultdict

from ragdapi.observability.collectors.extract_collector import ExtractStatsCollector

logger = logging.getLogger(__name__)


class DocStatsCollector(ExtractStatsCollector):
    """
    Statistics collector for document data.
    
    Extends the extract collector with document-specific metrics like
    Swagger documentation and code blocks statistics.
    """
    
    def __init__(self, output_path: Path, filters: Optional[List[str]] = None):
        """
        Initialize the document collector.
        
        Args:
            output_path: Path to save output
            filters: Optional list of filters used during extraction
        """
        super().__init__(output_path, filters)

        self.all_code_blocks = [] # storing all code blocks for statistics
        self.swagger_summary = defaultdict(int)
        self.code_blocks_summary = defaultdict(float)
    
    def aggregate_all_stats(self, df: pd.DataFrame, content_column: str = "content"):
        """
        Perform all necessary document-specific aggregations on a DataFrame.
        
        Args:
            df: The DataFrame to analyze
            content_column: Name of the column containing document content
            
        Returns:
            self (for chaining)
        """
        # First run standard extract aggregations
        super().aggregate_all_stats(df, content_column)
        
        # Run document-specific aggregations
        self._aggregate_swagger(df)
        self._aggregate_code_blocks(df)
        
        return self
        
    def _aggregate_swagger(self, df: pd.DataFrame):
        """Aggregate Swagger-related statistics."""
        logger.debug("Aggregating Swagger-related statistics")
        
        if "is_swagger" in df.columns:
            try:
                counts = df["is_swagger"].value_counts().to_dict()
                for key, value in counts.items():
                    self.swagger_summary[key] += value
            except Exception as e:
                logger.warning(f"Error aggregating Swagger statistics: {e}")
    
    def _aggregate_code_blocks(self, df: pd.DataFrame):
        """Aggregate code block statistics."""
        logger.debug("Aggregating code block statistics")
        
        if "number_code_blocks" in df.columns:
            try:
                numeric_data = pd.to_numeric(df["number_code_blocks"], errors='coerce')
                valid_data = numeric_data.dropna()
                
                if len(valid_data) > 0:
                    self.all_code_blocks.extend(valid_data.tolist())
                    
                    all_blocks_series = pd.Series(self.all_code_blocks)
                    
                    self.code_blocks_summary = {
                        "mean": float(all_blocks_series.mean()),
                        "median": float(all_blocks_series.median()),
                        "std": float(all_blocks_series.std()),
                        "min": float(all_blocks_series.min()),
                        "firstQuartile": float(all_blocks_series.quantile(0.25)),
                        "thirdQuartile": float(all_blocks_series.quantile(0.75)),
                        "max": float(all_blocks_series.max()),
                        "total": int(all_blocks_series.sum())
                        

                    }
                    
                    logger.debug(f"Code blocks stats (ALL DATA): count={self.code_blocks_summary['count']}, mean={self.code_blocks_summary['mean']:.2f}")
                    
            except Exception as e:
                logger.warning(f"Error aggregating code block statistics: {e}")
    
    def get_summary(self) -> List[Dict[str, Any]]:
        """
        Get a summary of all document statistics.
        
        Returns:
            List of statistics dictionaries for reporting
        """
        summary = super().get_summary()
        
        # Add swagger summary
        summary.append({
            "uri": "swagger_summary",
            "class": "swagger.SwaggerSummary",
            "true": self.swagger_summary.get(True, 0),
            "false": self.swagger_summary.get(False, 0)
        })
        
        # Add code blocks summary
        summary.append({
            "uri": "code_blocks_summary",
            "class": "code.CodeBlocksSummary",
            "summary": self.code_blocks_summary
        })
        
        return summary