import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from collections import defaultdict
import pandas as pd

from ragdapi.observability.collectors.base_collector import BaseStatsCollector

logger = logging.getLogger(__name__)


# TODO: Remove hard coded constants like column names
class TransformStatsCollector(BaseStatsCollector):
    """
    Statistics collector for transform (chunking) step.

    Focuses on essential chunking quality and distribution metrics
    organized by classes for downstream ingestion.
    """

    def __init__(
        self,
        output_path: Path,
        filters: Optional[List[str]] = None,
        extract_csv_path: Optional[Path] = None,
        config: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(output_path, filters)
        self.extract_csv_path = extract_csv_path
        self.config = config or {}

        # Core chunking metrics
        self.chunk_metrics = {"total_chunks": 0, "token_sizes": [], "empty_count": 0}

        # Document fragmentation metrics
        self.fragmentation_metrics = {
            "chunks_per_document": [],
            "token_preservation_ratios": [],
            "lost_chunk_counts": [],
            "total_original_tokens": 0,
            "total_chunk_tokens": 0,
            "documents_analyzed": 0,
            "documents_with_losses": [],
        }

        # Distribution metrics
        self.file_extension_counts = {}

        # Quality metrics
        self.quality_metrics = {"size_variance": 0.0, "empty_percentage": 0.0}

        self.config_metrics = self._extract_config_metrics()

    def _extract_config_metrics(self) -> Dict[str, Any]:
        """Extract transform configuration metrics from config."""
        metrics = {
            "chunker_name": "",
            "max_chunk_size": 0,
            "chunk_overlap": 0,
            "tokenizer_name": "",
        }

        try:

            if hasattr(self.config, "transform") and self.config.transform:
                transform_config = self.config.transform
                if (
                    hasattr(transform_config, "chunking_strategies")
                    and transform_config.chunking_strategies
                ):
                    strategies = transform_config.chunking_strategies

                    if strategies and len(strategies) > 0:
                        strategy = strategies[0]
                        metrics["chunker_name"] = getattr(
                            strategy, "chunker_name", "unknown"
                        )

                        if hasattr(strategy, "args") and strategy.args:
                            args = strategy.args
                            metrics["max_chunk_size"] = getattr(
                                args, "max_chunk_size", 0
                            )
                            metrics["chunk_overlap"] = getattr(args, "chunk_overlap", 0)
                            metrics["tokenizer_name"] = getattr(
                                args, "tokenizer_name", "unknown"
                            )

                        logger.info(
                            f"Extracted config: chunker={metrics['chunker_name']}, max_size={metrics['max_chunk_size']}"
                        )
                    else:
                        logger.warning(
                            "No chunking strategies found in transform config"
                        )
                else:
                    logger.warning(
                        "No chunking_strategies attribute in transform config"
                    )
            else:
                logger.warning("No transform config found")
        except Exception as e:
            logger.warning(f"Error extracting transform config metrics: {e}")

        return metrics

    def aggregate_all_stats(
        self, df: pd.DataFrame, content_column: str = "page_content"
    ):
        """
        Extract metrics from all chunks in a DataFrame.

        Args:
            df: DataFrame with chunk data (from JSON chunks converted to DataFrame)
            content_column: Name of content column (default: "page_content" for chunks)

        Returns:
            self (for chaining)
        """
        logger.info("Aggregating transform statistics from %d chunks", len(df))

        # Ensure required columns exist
        df = self._normalize_chunk_dataframe(df, content_column)

        # Load and join with extract data for original token counts
        if self.extract_csv_path and self.extract_csv_path.exists():
            df = self._join_with_extract_data(df)
        else:
            logger.warning(
                "Extract CSV not provided. Token preservation metrics will be skipped."
            )

        # Compute core metrics
        self._compute_chunk_metrics(df)
        self._compute_fragmentation_metrics(df)
        self._compute_distribution_metrics(df)
        self._compute_quality_metrics(df)

        return self

    def _normalize_chunk_dataframe(
        self, df: pd.DataFrame, content_column: str
    ) -> pd.DataFrame:
        """
        Normalize chunk DataFrame to expected format.
        """
        df = df.copy()

        # Rename content column to standard name
        if content_column != "content" and content_column in df.columns:
            df["content"] = df[content_column]

        # Extract nested metadata if needed (for chunks from JSON)
        if "metadata" in df.columns and df["metadata"].dtype == "object":
            print("🚀🚀", df.columns)
            # Extract common metadata fields
            df["displayurl"] = df["metadata"].apply(
                lambda x: x.get("displayurl", "") if isinstance(x, dict) else ""
            )
            df["title"] = df["metadata"].apply(
                lambda x: x.get("title", "") if isinstance(x, dict) else ""
            )
            df["file_extension"] = df["metadata"].apply(
                lambda x: (
                    x.get("file_extension", "unknown")
                    if isinstance(x, dict)
                    else "unknown"
                )
            )
            df["chunk_tokens"] = df["metadata"].apply(
                lambda x: x.get("num_tokens", 0) if isinstance(x, dict) else 0
            )

        # Ensure required columns exist
        for col in ["displayurl", "title", "file_extension", "chunk_tokens", "content"]:
            if col not in df.columns:
                default_values = {
                    "title": "",
                    "file_extension": "unknown",
                    "chunk_tokens": 0,
                    "content": "",
                }
                df[col] = default_values[col]

        # Add computed fields
        df["is_empty"] = df["content"].astype(str).str.strip() == ""

        return df

    def _join_with_extract_data(self, chunks_df: pd.DataFrame) -> pd.DataFrame:
        """Join with extract CSV for token preservation metrics."""
        try:
            if self.extract_csv_path.is_file():
                extract_df = pd.read_csv(self.extract_csv_path)
            elif self.extract_csv_path.is_dir():
                # Load all CSV files from directory
                csv_files = list(self.extract_csv_path.glob("*.csv"))
                if not csv_files:
                    logger.warning(f"No CSV files found in {self.extract_csv_path}")
                    chunks_df["original_tokens"] = 0
                    return chunks_df

                # Concatenate all CSV files
                extract_dfs = []
                for csv_file in csv_files:
                    extract_dfs.append(pd.read_csv(csv_file))
                extract_df = pd.concat(extract_dfs, ignore_index=True)
            else:
                logger.warning(
                    f"Extract path {self.extract_csv_path} is neither file nor directory"
                )
                chunks_df["original_tokens"] = 0
                return chunks_df

            logger.info("Loaded extract CSV with %d rows", len(extract_df))

            # Find token column
            possible_token_cols = [
                "number_tokens_content",
                "number_tokens_text",
                "number_tokens_file",
            ]
            token_col = None
            for col in possible_token_cols:
                if col in extract_df.columns:
                    token_col = col
                    break

            if not token_col:
                logger.warning(
                    "No token column found in extract CSV. Available columns: %s",
                    list(extract_df.columns),
                )
                logger.warning(
                    "Token preservation metrics will be skipped. Expected columns: %s",
                    possible_token_cols,
                )
                chunks_df["original_tokens"] = 0
                return chunks_df

            logger.info(f"Using token column: {token_col}")

            doc_tokens = extract_df.groupby("displayurl")[token_col].sum().reset_index()
            doc_tokens.rename(columns={token_col: "original_tokens"}, inplace=True)

            logger.info(
                "Grouped extract data by displayurl: %d unique documents",
                len(doc_tokens),
            )
            logger.debug("Sample original tokens: %s", doc_tokens.head())

            # Join with chunks
            result = chunks_df.merge(doc_tokens, on="displayurl", how="left")
            result["original_tokens"] = result["original_tokens"].fillna(0)

            logger.info(
                "Join results - chunks with original_tokens > 0: %d",
                (result["original_tokens"] > 0).sum(),
            )
            logger.info(
                "Sample preservation data: original_tokens range [%d, %d]",
                result["original_tokens"].min(),
                result["original_tokens"].max(),
            )

            return result

        except Exception as e:
            logger.warning(f"Error joining with extract data: {e}")
            chunks_df["original_tokens"] = 0
            return chunks_df

    def _compute_chunk_metrics(self, df: pd.DataFrame):
        """Compute core chunk metrics."""
        self.chunk_metrics["total_chunks"] += len(df)
        self.chunk_metrics["token_sizes"] += df["chunk_tokens"].tolist()
        self.chunk_metrics["empty_count"] += int(df["is_empty"].sum())

        logger.info(
            f"Accumulated {len(df)} chunks, total now: {self.chunk_metrics['total_chunks']}"
        )

    def _compute_fragmentation_metrics(self, df: pd.DataFrame):
        """Compute fragmentation and preservation metrics."""
        total_original_tokens = self.fragmentation_metrics.get(
            "total_original_tokens", 0
        )
        total_chunk_tokens = self.fragmentation_metrics.get("total_chunk_tokens", 0)
        documents_analyzed = self.fragmentation_metrics.get("documents_analyzed", 0)
        documents_with_losses = self.fragmentation_metrics.get(
            "documents_with_losses", []
        )

        for displayurl, group in df.groupby("displayurl"):
            if displayurl and displayurl.strip():  # Skip empty titles
                chunk_count = len(group)
                self.fragmentation_metrics["chunks_per_document"].append(chunk_count)

                if "original_tokens" in df.columns:
                    original_tokens = group["original_tokens"].iloc[0]
                    chunk_tokens_sum = group["chunk_tokens"].sum()

                    # Accumulate totals for global stats
                    if original_tokens > 0:
                        total_original_tokens += original_tokens
                        total_chunk_tokens += chunk_tokens_sum
                        documents_analyzed += 1

                        preservation_ratio = (
                            min(1.0, chunk_tokens_sum / original_tokens)
                            if original_tokens > 0
                            else 0.0
                        )
                        self.fragmentation_metrics["token_preservation_ratios"].append(
                            preservation_ratio
                        )

                        if chunk_tokens_sum < original_tokens:
                            lost_tokens = original_tokens - chunk_tokens_sum
                            self.fragmentation_metrics["lost_chunk_counts"].append(
                                lost_tokens
                            )

                            document_title = (
                                group["title"].iloc[0]
                                if "title" in group.columns
                                else "Unknown"
                            )

                            documents_with_losses.append(
                                {
                                    "title": document_title,
                                    "displayurl": displayurl,
                                    "original_tokens": original_tokens,
                                    "chunk_tokens": chunk_tokens_sum,
                                    "lost_tokens": lost_tokens,
                                    "preservation_ratio": preservation_ratio,
                                    "chunks_count": chunk_count,
                                }
                            )
                        else:
                            self.fragmentation_metrics["lost_chunk_counts"].append(0)
                    else:
                        logger.debug(f"No original tokens for document: {displayurl}")

        # Store global totals for summary
        self.fragmentation_metrics["total_original_tokens"] = total_original_tokens
        self.fragmentation_metrics["total_chunk_tokens"] = total_chunk_tokens
        self.fragmentation_metrics["documents_analyzed"] = documents_analyzed
        self.fragmentation_metrics["documents_with_losses"] = documents_with_losses

        if total_original_tokens > 0:
            global_preservation_ratio = total_chunk_tokens / total_original_tokens
        else:
            global_preservation_ratio = 0.0

        logger.info(f"Global token analysis:")
        logger.info(f"  - Total original tokens: {total_original_tokens:,}")
        logger.info(f"  - Total chunk tokens: {total_chunk_tokens:,}")
        logger.info(f"  - Global preservation ratio: {global_preservation_ratio:.3f}")
        logger.info(f"  - Documents analyzed: {documents_analyzed}")

    def _compute_distribution_metrics(self, df: pd.DataFrame):
        """Compute distribution by file extension."""
        if "file_extension" in df.columns:
            ext_df = df[["file_extension", "content"]].copy()
            ext_df["file_extension"] = ext_df["file_extension"].astype(str)

            # Filter valid extensions
            valid = (
                ext_df["file_extension"].notnull()
                & ext_df["file_extension"].ne("nan")
                & ext_df["file_extension"].ne("")
                & ext_df["file_extension"].ne("unknown")
            )
            ext_df = ext_df[valid]

            if len(ext_df) > 0:
                grp = ext_df.groupby("file_extension")["content"]
                stats = grp.agg(
                    total="size", empty=lambda s: s.astype(str).str.strip().eq("").sum()
                )
                stats["filled"] = stats["total"] - stats["empty"]

                for ext, row in stats.iterrows():
                    counts = {"empty": int(row["empty"]), "filled": int(row["filled"])}
                    if ext in self.file_extension_counts:
                        self.file_extension_counts[ext]["empty"] += counts["empty"]
                        self.file_extension_counts[ext]["filled"] += counts["filled"]
                    else:
                        self.file_extension_counts[ext] = counts

    def _compute_quality_metrics(self, df: pd.DataFrame):
        """Compute quality metrics."""
        if len(self.chunk_metrics["token_sizes"]) > 0:
            token_series = pd.Series(self.chunk_metrics["token_sizes"])
            self.quality_metrics["size_variance"] = float(token_series.var())

            if self.chunk_metrics["total_chunks"] > 0:
                empty_percentage = (
                    self.chunk_metrics["empty_count"]
                    / self.chunk_metrics["total_chunks"]
                ) * 100
                self.quality_metrics["empty_percentage"] = float(empty_percentage)
            else:
                logger.info("No chunks were found, empty_percentage is set")
                self.quality_metrics["empty_percentage"] = 0.0

    def get_summary(self) -> List[Dict[str, Any]]:
        """Get summary organized by class."""
        summary = self.get_base_summary("transform")

        # Transform config
        summary.append(
            {
                "uri": "transform_config",
                "class": "config.ChunkArguments",
                "chunking_strategy": self.config_metrics["chunker_name"],
                "max_chunk_size": self.config_metrics["max_chunk_size"],
                "chunk_overlap": self.config_metrics["chunk_overlap"],
                "tokenizer": self.config_metrics["tokenizer_name"],
            }
        )

        # Chunk content metrics
        summary.append(
            {
                "uri": "chunk_content",
                "class": "chunks.ChunkContent",
                "total_chunks": self.chunk_metrics["total_chunks"],
                "empty_chunks": self.chunk_metrics["empty_count"],
                "empty_percentage": self.quality_metrics["empty_percentage"],
            }
        )

        # Chunk size stats
        if self.chunk_metrics["token_sizes"]:
            token_stats = pd.Series(self.chunk_metrics["token_sizes"]).describe()
            summary.append(
                {
                    "uri": "chunk_size_stats",
                    "class": "chunks.ChunkSize",
                    "mean": float(token_stats["mean"]),
                    "median": float(token_stats["50%"]),
                    "std": float(token_stats["std"]),
                    "min": int(token_stats["min"]),
                    "max": int(token_stats["max"]),
                    "variance": self.quality_metrics["size_variance"],
                }
            )

        if self.fragmentation_metrics["chunks_per_document"]:
            fragmentation_stats = pd.Series(
                self.fragmentation_metrics["chunks_per_document"]
            ).describe()

            chunks_per_doc = pd.Series(
                self.fragmentation_metrics["chunks_per_document"]
            )
            logger.info(f"Document fragmentation analysis:")
            logger.info(f"  - Total documents: {len(chunks_per_doc)}")
            logger.info(f"  - Total chunks distributed: {chunks_per_doc.sum()}")
            logger.info(f"  - Max chunks in single doc: {chunks_per_doc.max()}")
            logger.info(
                f"  - Documents with >100 chunks: {(chunks_per_doc > 100).sum()}"
            )

            summary.append(
                {
                    "uri": "document_fragmentation",
                    "class": "documents.Fragmentation",
                    "mean_chunks_per_doc": float(fragmentation_stats["mean"]),
                    "median_chunks_per_doc": float(fragmentation_stats["50%"]),
                    "max_chunks_per_doc": int(fragmentation_stats["max"]),
                }
            )

        if self.fragmentation_metrics["token_preservation_ratios"]:
            preservation_stats = pd.Series(
                self.fragmentation_metrics["token_preservation_ratios"]
            ).describe()
            lost_tokens_series = pd.Series(
                self.fragmentation_metrics["lost_chunk_counts"]
            )

            total_original = self.fragmentation_metrics.get("total_original_tokens", 0)
            total_chunks = self.fragmentation_metrics.get("total_chunk_tokens", 0)
            global_preservation = (
                total_chunks / total_original if total_original > 0 else 0.0
            )

            summary.append(
                {
                    "uri": "token_preservation",
                    "class": "quality.TokenPreservation",
                    "mean_preservation_ratio": float(preservation_stats["mean"]),
                    "median_preservation_ratio": float(preservation_stats["50%"]),
                    "min_preservation_ratio": float(preservation_stats["min"]),
                    "max_preservation_ratio": float(preservation_stats["max"]),
                    "global_token_preservation_ratio": float(global_preservation),
                    "total_tokens_before_chunking": int(total_original),
                    "total_tokens_after_chunking": int(total_chunks),
                    "total_lost_tokens": int(lost_tokens_series.sum()),
                    "max_lost_tokens_per_document": (
                        int(lost_tokens_series.max())
                        if len(lost_tokens_series) > 0
                        else 0
                    ),
                    "mean_lost_tokens_per_document": (
                        float(lost_tokens_series.mean())
                        if len(lost_tokens_series) > 0
                        else 0.0
                    ),
                    "documents_with_token_loss": int((lost_tokens_series > 0).sum()),
                    "total_documents_analyzed": int(
                        self.fragmentation_metrics.get("documents_analyzed", 0)
                    ),
                }
            )

            documents_with_losses = self.fragmentation_metrics.get(
                "documents_with_losses", []
            )
            logger.info(
                f"Documents with losses found in get_summary: {len(documents_with_losses)}"
            )

            if documents_with_losses:
                documents_with_losses.sort(key=lambda x: x["lost_tokens"], reverse=True)

                for i, doc_loss in enumerate(documents_with_losses):
                    logger.info(
                        f"Adding DocumentTokenLoss #{i+1}: {doc_loss['title']} - {doc_loss['lost_tokens']:,} tokens lost"
                    )
                    summary.append(
                        {
                            "uri": f"document_token_loss_{i+1}",
                            "class": "quality.DocumentTokenLoss",
                            "title": doc_loss["title"],
                            "displayurl": doc_loss["displayurl"],
                            "original_tokens": doc_loss["original_tokens"],
                            "chunk_tokens": doc_loss["chunk_tokens"],
                            "lost_tokens": doc_loss["lost_tokens"],
                            "preservation_ratio": round(
                                doc_loss["preservation_ratio"], 6
                            ),
                            "loss_percentage": round(
                                (doc_loss["lost_tokens"] / doc_loss["original_tokens"])
                                * 100,
                                2,
                            ),
                            "chunks_count": doc_loss["chunks_count"],
                        }
                    )
            else:
                logger.warning(
                    "No documents_with_losses found in fragmentation_metrics"
                )
                logger.warning(
                    f"Available fragmentation_metrics keys: {list(self.fragmentation_metrics.keys())}"
                )

        # File extension distribution
        for ext, counts in self.file_extension_counts.items():
            summary.append(
                {
                    "uri": f"chunks_per_file_extension_{ext}",
                    "class": "chunks.ChunksPerFileExtension",
                    "extension": ext,
                    "empty": counts.get("empty", 0),
                    "filled": counts.get("filled", 0),
                    "total": counts.get("empty", 0) + counts.get("filled", 0),
                }
            )

        return summary
