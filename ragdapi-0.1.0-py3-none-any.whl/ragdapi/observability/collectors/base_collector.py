from abc import ABC, abstractmethod
import logging
import pandas as pd
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


class BaseStatsCollector(ABC):
    """
    Base class for all statistics collectors.
    
    This class defines the common interface and functionality for all collectors,
    such as timing, metadata handling, and human-readable formatting.
    """
    
    def __init__(
        self, 
        output_path: Path,
        filters: Optional[List[str]] = None
    ):
        """
        Initialize the base collector.
        
        Args:
            output_path: Path to save output
            filters: Optional list of filters used during collection
        """
        self.output_path = output_path
        self.filters = filters if filters else []
        self.metadatas = []
        self.start_time = None
        self.end_time = None
        self.execution_time = None
    
    def start_log(self, start_time=None):
        """
        Record the start time for the operation.
        
        Args:
            start_time: Optional timestamp to use (defaults to current time)
            
        Returns:
            self (for chaining)
        """
        # Record start timestamp and formatted string
        self._start_dt = datetime.fromtimestamp(start_time) if start_time else datetime.now()
        self.start_time = self._start_dt.strftime("%Y-%m-%dT%H:%M:%S")
        logger.debug(f"Started at {self.start_time}")
        return self
    
    def end_log(self, end_time=None):
        """
        Record the end time and calculate execution duration.
        
        Args:
            end_time: Optional timestamp to use (defaults to current time)
            
        Returns:
            self (for chaining)
        """
        # Record end timestamp and formatted string
        self._end_dt = datetime.fromtimestamp(end_time) if end_time else datetime.now()
        self.end_time = self._end_dt.strftime("%Y-%m-%dT%H:%M:%S")
        logger.debug(f"Ended at {self.end_time}")
        # Calculate execution duration
        if hasattr(self, '_start_dt') and self._start_dt:
            delta = self._end_dt - self._start_dt
            minutes, seconds = divmod(int(delta.total_seconds()), 60)
            self.execution_time = f"{minutes}m {seconds}s"
            logger.debug(f"Execution time: {self.execution_time}")
        
        return self
    
    def get_base_summary(self, process_name: str) -> List[Dict[str, Any]]:
        """
        Get base summary statistics.
        
        Args:
            process_name: Name of the process being analyzed
            
        Returns:
            List of summary dictionaries with base statistics
        """
        summary = [
            {
                "uri": "process_logs",
                "class": "process.ProcessLogs",
                "process": process_name,
                "startTime": self.start_time,
                "endTime": self.end_time,
                "executionTime": self.execution_time,
            },
            {
                "uri": "arguments",
                "class": "config.Arguments",
                "metadatas": list(self.metadatas),
                "filters": self.filters
            }
        ]
        return summary
    
    @abstractmethod
    def aggregate_all_stats(self, df: pd.DataFrame, content_column: str = "content"):
        """
        Base method for performing aggregations on a DataFrame.
        
        This method should be overridden by subclasses to implement
        specific aggregation logic.
        
        Args:
            df: The DataFrame to analyze
            content_column: Name of the column containing document content
            
        Returns:
            self (for chaining)
        """
        """Subclasses must implement this method to perform specific aggregations."""
        pass
        
    def get_summary(self) -> List[Dict[str, Any]]:
        """
        Get summary statistics.
        
        Returns:
            List of summary dictionaries
        """
        return self.get_base_summary("base")