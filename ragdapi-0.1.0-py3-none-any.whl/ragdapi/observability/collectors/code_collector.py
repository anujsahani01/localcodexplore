import logging
from pathlib import Path
import pandas as pd
from typing import List, Dict, Any, Optional
from collections import defaultdict

from ragdapi.observability.collectors.extract_collector import ExtractStatsCollector

logger = logging.getLogger(__name__)

class CodeStatsCollector(ExtractStatsCollector):
    """
    Statistics collector for code data.
    
    Extends the extract collector with code-specific metrics like frameworks,
    release types, and language statistics.
    """
    
    def __init__(self, output_path: Path, filters: Optional[List[str]] = None):
        """
        Initialize the code collector.
        
        Args:
            output_path: Path to save output
            filters: Optional list of filters used during extraction
        """
        super().__init__(output_path, filters)
        # Type annotations for all dictionary attributes
        self.documents_per_framework: Dict[str, int] = defaultdict(int)
        
        # Nested defaultdict(int) for two-level counts
        self.documents_per_framework_per_release_type: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        self.documents_per_file_extension_per_release_type: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        self.frameworks_per_release_type: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    
    def aggregate_all_stats(self, df: pd.DataFrame, content_column: str = "content"):
        """
        Perform all necessary code-specific aggregations on a DataFrame.
        
        Args:
            df: The DataFrame to analyze
            content_column: Name of the column containing document content
            
        Returns:
            self (for chaining)
        """
        # Run standard extract aggregations
        super().aggregate_all_stats(df, content_column)
        
        # Run code-specific aggregations
        self._aggregate_frameworks_per_release_type(df)
        self._aggregate_documents_per_framework(df)
        self._aggregate_documents_per_framework_per_release_type(df)
        self._aggregate_documents_per_file_extension_per_release_type(df)
        
        return self
    
    def _aggregate_frameworks_per_release_type(self, df: pd.DataFrame):
        """Aggregate framework counts per release type."""
        logger.debug("Aggregating framework counts per release type")
        
        if "release_type" in df.columns and "framework" in df.columns:
            try:

                grouped_dict = df.groupby(["release_type", "framework"]).size().to_dict()
                
                for key_tuple, count in grouped_dict.items():
                    if not isinstance(key_tuple, tuple) or len(key_tuple) != 2:
                        continue
                        
                    rt, fw = key_tuple
                    
                    rt_str = str(rt)
                    fw_str = str(fw)
                    
                    if rt_str and fw_str and rt_str != "nan" and fw_str != "nan":
                        self.frameworks_per_release_type[rt_str][fw_str] += count
            except Exception as e:
                logger.warning(f"Error aggregating frameworks per release type: {e}")
    
    def _aggregate_documents_per_framework(self, df: pd.DataFrame):
        """Aggregate document counts per framework."""
        logger.debug("Aggregating document counts per framework")
        
        if "framework" in df.columns:
            # Count documents per framework
            try:
                fw_counts = df["framework"].value_counts().to_dict()
                for fw, count in fw_counts.items():
                    if fw and fw != "nan":
                        self.documents_per_framework[fw] += count
            except Exception as e:
                logger.warning(f"Error aggregating documents per framework: {e}")
    
    def _aggregate_documents_per_framework_per_release_type(self, df: pd.DataFrame):
        """Aggregate document counts per framework per release type."""
        logger.debug("Aggregating document counts per framework per release type")
        
        if "release_type" in df.columns and "framework" in df.columns:
            try:
                grouped_dict = df.groupby(["release_type", "framework"]).size().to_dict()
                
                for key_tuple, count in grouped_dict.items():
                    if not isinstance(key_tuple, tuple) or len(key_tuple) != 2:
                        continue
                        
                    rt, fw = key_tuple
                    
                    rt_str = str(rt)
                    fw_str = str(fw)
                    
                    if rt_str and fw_str and rt_str != "nan" and fw_str != "nan":
                        self.documents_per_framework_per_release_type[rt_str][fw_str] += count
            except Exception as e:
                logger.warning(f"Error aggregating documents per framework per release type: {e}")
    
    def _aggregate_documents_per_file_extension_per_release_type(self, df: pd.DataFrame):
        """Aggregate document counts per file extension per release type."""
        logger.debug("Aggregating document counts per file extension per release type")
        
        if "release_type" in df.columns and "file_extension" in df.columns:
            try:

                grouped_dict = df.groupby(["release_type", "file_extension"]).size().to_dict()
                
                for key_tuple, count in grouped_dict.items():
                    if not isinstance(key_tuple, tuple) or len(key_tuple) != 2:
                        continue
                        
                    rt, ext = key_tuple
                    
                    rt_str = str(rt)
                    ext_str = str(ext)
                    
                    if rt_str and ext_str and rt_str != "nan" and ext_str != "nan":
                        self.documents_per_file_extension_per_release_type[rt_str][ext_str] += count
            except Exception as e:
                logger.warning(f"Error aggregating documents per file extension per release type: {e}")
    
    def get_summary(self) -> List[Dict[str, Any]]:
        """
        Get a summary of all code statistics.
        
        Returns:
            List of statistics dictionaries for reporting
        """
        summary = super().get_summary()
        
        # Add top 5 frameworks per release type
        for rt, fw_dict in self.frameworks_per_release_type.items():
            sorted_fw_rt = dict(sorted(fw_dict.items(), key=lambda x: x[1], reverse=True))
            if sorted_fw_rt:
                summary.append({
                    "uri": f"frameworks_{rt}",
                    "class": "frameworks.FrameworksPerReleaseType",
                    "releaseType": rt,
                    "frameworks": sorted_fw_rt
                })
        
        # Add document counts per framework
        sorted_doc_fw = dict(sorted(self.documents_per_framework.items(), key=lambda x: x[1], reverse=True))
        for fw, count in sorted_doc_fw.items():
            summary.append({
                "uri": f"documents_per_framework_{fw}",
                "class": "documents.DocumentsPerFramework",
                "framework": fw,
                "documentCount": count
            })
        
        # Add document counts per framework per release type
        for rt, fw_dict in self.documents_per_framework_per_release_type.items():
            # sort frameworks for this release type
            sorted_doc_fw_rt = sorted(fw_dict.items(), key=lambda x: x[1], reverse=True)
            for fw, count in sorted_doc_fw_rt:
                summary.append({
                    "uri": f"documents_per_framework_release_type_{rt}_{fw}",
                    "class": "documents.DocumentsPerFrameworkPerReleaseType",
                    "releaseType": rt,
                    "framework": fw,
                    "documentCount": count
                })
        
        # Add document counts per file extension per release type
        for rt, ext_dict in self.documents_per_file_extension_per_release_type.items():
            # sort file extensions for this release type
            sorted_doc_fe_rt = sorted(ext_dict.items(), key=lambda x: x[1], reverse=True)
            for ext, count in sorted_doc_fe_rt:
                summary.append({
                    "uri": f"documents_per_file_extension_release_type_{rt}_{ext}",
                    "class": "documents.DocumentsPerFileExtensionPerReleaseType",
                    "releaseType": rt,
                    "fileExtension": ext,
                    "documentCount": count
                })
        
        return summary