"""
Decorators for tracing pipeline components.

This module provides decorators that can be used to automatically
collect and report metrics for different components in the RAG pipeline.
"""

import time
import logging
import functools
from pathlib import Path
from typing import Dict, Any

from ragdapi.observability.in_process.utils import (
    DataSourceExtractor,
    AccumulatorManager,
)
from ragdapi.observability.common.config_utils import ObservabilityConfigHandler
from ragdapi.observability.common.file_utils import ObservabilityFileProcessor

logger = logging.getLogger(__name__)

_global_stats_accumulator = {}


class Observability:
    """
    A class to track the execution of pipeline components and collect Observability statistics.
    This decorator can be applied to running methods of pipeline components.
    """

    def __init__(self, component_type: str):
        self.component = component_type
        self.accumulator_manager = AccumulatorManager(_global_stats_accumulator)

    def __call__(self, func):
        @functools.wraps(func)
        def wrapper(instance, *args, **kwargs):
            # 1) Check if observability is enabled
            config_obj = getattr(instance, "config", instance)
            observability_config = (
                ObservabilityConfigHandler.extract_observability_config(config_obj)
            )

            if not ObservabilityConfigHandler.safe_get(
                observability_config, "launch_observability", False
            ):
                return func(instance, *args, **kwargs)

            # 2) Execute function with timing
            start_ts = time.time()
            result = func(instance, *args, **kwargs)
            end_ts = time.time()
            logger.info(f"[trace][{self.component}] exec in {end_ts - start_ts:.2f}s")

            # 3) Setup paths and manager
            paths_config = ObservabilityConfigHandler.extract_paths_config(config_obj)
            save_path = self._get_save_path(paths_config, kwargs)

            # 4) Manage accumulator
            accumulator = self.accumulator_manager.get_or_create_accumulator(
                self.component, save_path, start_ts
            )
            self.accumulator_manager.update_accumulator(accumulator, end_ts)

            logger.info(
                f"Processing call #{accumulator['call_count']} for {self.component}"
            )

            # 5) Get data source
            logging.info(f"The paths config is: {paths_config}")
            data_source = DataSourceExtractor.get_data_source(
                self.component, instance, result, paths_config
            )
            if data_source["dataframe"] is None and data_source["source"] is None:
                logger.warning(
                    f"No data found for {self.component} component, call #{accumulator['call_count']}"
                )
                return result

            # 6) Initialize collector if needed
            if accumulator["collector"] is None:
                self._initialize_collector(
                    accumulator, config_obj, observability_config, data_source
                )

            # 7) Process data
            self._process_data(accumulator["collector"], data_source)

            # 8) Save results
            self._save_results(accumulator)

            # 9) Upload to AWS using manager (no more duplication!)
            self._upload_to_aws(accumulator["manager"], self.component)

            return result

        return wrapper

    def _get_save_path(self, paths_config, kwargs) -> Path:
        """Get save path for observability data."""
        root = getattr(paths_config, "root", ".") if paths_config else "."
        filename = getattr(
            paths_config,
            f"observability_{self.component}_output",
            f"observability_{self.component}.json",
        )
        return Path(kwargs.get("save_path", Path(root) / filename)).resolve()

    def _initialize_collector(
        self,
        accumulator: Dict[str, Any],
        config_obj,
        observability_config: Dict[str, Any],
        data_source: Dict[str, Any],
    ):
        """Initialize collector in accumulator."""
        filters = ObservabilityConfigHandler.extract_filters(config_obj, self.component)
        config_dict = ObservabilityConfigHandler.convert_to_dict(config_obj)

        if config_dict:
            accumulator["manager"].config = config_obj

        accumulator["collector"] = accumulator["manager"].get_collector(
            collector_type=self.component,
            data_type=ObservabilityConfigHandler.safe_get(
                observability_config, "type", "generic"
            ),
            filters=filters,
            extract_csv_path=data_source["extract_csv_path"],
        )

        logger.info(f"Created accumulating collector for {self.component}")

    def _process_data(self, collector, data_source: Dict[str, Any]):
        """Process data using the collector."""
        dataframe = data_source["dataframe"]
        source = data_source["source"]
        content_column = data_source["content_column"]

        if dataframe is not None:
            logger.info(f"Accumulating DataFrame with {len(dataframe)} records")
            collector.aggregate_all_stats(dataframe, content_column)

        elif source is not None:
            logger.info(f"Accumulating from source {source}")

            if source.is_file():
                ObservabilityFileProcessor.process_single_file(
                    source, content_column, collector
                )
            elif source.is_dir():
                ObservabilityFileProcessor.process_directory(
                    source, content_column, collector
                )
            else:
                raise ValueError(f"Source must be a file or directory, got: {source}")

    def _save_results(self, accumulator: Dict[str, Any]):
        """Save accumulated results."""
        collector = accumulator["collector"]
        manager = accumulator["manager"]

        collector.start_log(start_time=accumulator["first_start_time"])
        collector.end_log(end_time=accumulator["last_end_time"])

        accumulated_summary = collector.get_summary()
        manager.save_observability_data(accumulated_summary)

        logger.info(
            f"Saved accumulated stats for {self.component} (call #{accumulator['call_count']})"
        )

    def _upload_to_aws(self, manager, component_type: str):
        """Upload to AWS using manager's methods."""
        if manager.is_upload_to_aws_enabled():
            aws_bucket_path = manager.get_aws_bucket_path(component_type)
            if aws_bucket_path:
                try:
                    manager.upload_to_aws(aws_bucket_path)
                    logger.info(
                        f"Uploaded accumulated {component_type} observability to AWS"
                    )
                except Exception as e:
                    logger.error(
                        f"Failed to upload {component_type} observability to AWS: {e}"
                    )
            else:
                logger.warning(
                    f"AWS upload enabled but no bucket path for {component_type}"
                )
