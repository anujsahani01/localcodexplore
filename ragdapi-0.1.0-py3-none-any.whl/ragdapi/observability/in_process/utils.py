"""
Utility classes for observability decorators.
Uses common modules to avoid duplication.
"""

import logging
from pathlib import Path
from typing import Dict, Any

from ragdapi.observability.manager.observability_manager import ObservabilityManager


logger = logging.getLogger(__name__)


class DataSourceExtractor:
    """Handle data source extraction for decorator observability (decorator-specific logic)."""

    @staticmethod
    def get_data_source(component_type: str, instance, result, paths_cfg):
        """Get data source based on component type."""
        if component_type == "transform":
            return DataSourceExtractor._get_transform_source(
                paths_cfg, instance, result
            )
        else:
            logging.info(f"Getting the extracted datasource: {result}")
            return DataSourceExtractor._get_extract_source(instance, result)

    @staticmethod
    def _get_transform_source(paths_cfg, instance=None, result=None):
        """Get transform data source from generated JSON files."""

        root = getattr(paths_cfg, "root", ".") if paths_cfg else "."
        transform_output = getattr(paths_cfg, "transform_output", "transform")
        extract_csv_path = Path(root) / getattr(paths_cfg, "extract_output", "extract")
        transform_path = Path(root) / transform_output

        json_file = None

        if transform_path.is_file() and transform_path.suffix == ".json":
            json_file = transform_path
        else:
            if (
                instance
                and hasattr(instance, "files_to_process")
                and instance.files_to_process
            ):
                first_file = instance.files_to_process[0]
                potential_json = Path(root) / f"{first_file.stem}.json"
                if potential_json.exists():
                    json_file = potential_json
                else:
                    if transform_path.is_dir():
                        potential_json = transform_path / f"{first_file.stem}.json"
                        if potential_json.exists():
                            json_file = potential_json

        if json_file and json_file.exists():
            logger.info(f"Using transform JSON file for observability: {json_file}")

            return {
                "source": json_file,
                "dataframe": None,
                "content_column": "page_content",
                "extract_csv_path": (
                    extract_csv_path if extract_csv_path.exists() else None
                ),
            }

        json_files = list(Path(root).glob("*.json"))
        transform_json_files = [
            f for f in json_files if "transform" in f.name or "chunk" in f.name
        ]

        if transform_json_files:
            json_file = transform_json_files[0]
            logger.info(f"Using fallback transform JSON file: {json_file}")

            return {
                "source": json_file,
                "dataframe": None,
                "content_column": "page_content",
                "extract_csv_path": (
                    extract_csv_path if extract_csv_path.exists() else None
                ),
            }

        logger.warning("No transform JSON file found for observability")
        return {
            "source": None,
            "dataframe": None,
            "content_column": "page_content",
            "extract_csv_path": extract_csv_path if extract_csv_path.exists() else None,
        }

    @staticmethod
    def _get_extract_source(instance, result):
        """Get extract data source."""
        target = result if hasattr(result, "dataframe") else instance
        dataframe = getattr(target, "dataframe", None)
        return {
            "source": None,
            "dataframe": dataframe,
            "content_column": "content",
            "extract_csv_path": None,
        }


class AccumulatorManager:
    """Manage global statistics accumulator for multiple step instance calls. (decorator-specific logic)."""

    def __init__(self, global_accumulator_ref: Dict[str, Any]):
        """Initialize with reference to global accumulator."""
        self.global_accumulator = global_accumulator_ref

    def get_or_create_accumulator(
        self, component_type: str, save_path: Path, start_time: float
    ) -> Dict[str, Any]:
        """Get existing accumulator or create new one."""
        accumulator_key = f"{component_type}_{save_path}"

        if accumulator_key not in self.global_accumulator:
            self.global_accumulator[accumulator_key] = {
                "collector": None,
                "manager": ObservabilityManager(save_path),
                "first_start_time": start_time,
                "last_end_time": start_time,
                "call_count": 0,
            }
            logger.info(f"Initialized accumulator for {component_type}")

        return self.global_accumulator[accumulator_key]

    def update_accumulator(self, accumulator: Dict[str, Any], end_time: float):
        """Update accumulator with new timing."""
        accumulator["call_count"] += 1
        accumulator["last_end_time"] = end_time
