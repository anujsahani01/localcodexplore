import ast
from pydantic import BaseModel, Field, field_validator, model_validator
from typing import List, Optional, Union, Dict, Callable, Any
from pathlib import Path
import os
import requests

from ragdapi.schemas.observability import TraceabilityArgs


class DSXplore(BaseModel):
    query: str
    commands: Dict[str, str] = Field(default_factory=dict)
    filters: List[str] = Field(default_factory=list)
    options: List[str] = Field(default_factory=list)


class GitLab(BaseModel):
    url: str = Field(..., description="The GitLab URL")
    project_id: str = Field(..., description="The GitLab project ID")
    folder_path: str = Field(..., description="The folder path")
    branch: str = Field(..., description="The branch")
    private_token: str = Field(..., description="The GitLab private access token")
    exclude_paths: List[str] = Field(default_factory=list)
    recursive: bool = Field(
        default=True, description="Whether to recursively search for files"
    )


class LocalXplore(BaseModel):
    all_files: bool = Field(
        default=True, description="If we want to extract all files from local dir"
    )
    max_files: Optional[int] = Field(
        default=None, description="The maximum number of file we want to ignore"
    )
    index_ignore_rules: str = Field(
        ...,
        description="This points to the indexignore file which has all the files, folders, patterns to be ignored.",
    )
    slm_query_path: Optional[Path] = None
    get_sqlite_format: Optional[bool] = Field(
        default=False,
        description="If we want the extracted files to be saved in sqlite db  isntead of csv format",
    )
    filepaths: Optional[List[str]] = Field(
        default_factory=list,
        description="The list of relative filepaths to be included",
    )
    extensions: Optional[List[str]] = Field(
        default_factory=list, description="The list of extensions to be included"
    )


class SLMClient(BaseModel):
    service_url: str = Field(..., description="This points to the DS SLM endpoint")
    username: str = Field(..., description="The username for service account")
    password: str = Field(..., description="The password for service account")


class TokenizerArgs(BaseModel):
    tokenizer_name: str
    cache_dir: Optional[str] = None
    api_url: Optional[str] = None
    api_key: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def check_api_args(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        api_url = values.get("api_url")
        api_key = values.get("api_key")

        if api_key and not api_url:
            raise ValueError(
                "If api_key is provided, api_url must be provided as well."
            )

        return values

    @model_validator(mode="after")
    def run_todo_checks(self):
        self._check_cache_dir()
        self._check_api_connectivity()
        # self._check_model_online()
        return self

    # checks chache dir exists if not creates one
    def _check_cache_dir(self):
        if not self.cache_dir:
            return

        if not os.path.exists(self.cache_dir):
            try:
                os.makedirs(self.cache_dir, exist_ok=True)
            except Exception as exc:
                raise ValueError(
                    f"Failed to create cache directory '{self.cache_dir}': {exc}"
                ) from exc

    # checks API url works
    def _check_api_connectivity(self):
        if not self.api_url:
            return  # No API mode used

        try:
            payload = {
                "model": self.tokenizer_name,
                "input": "ping",
            }
            r = requests.post(
                self.api_url,
                json=payload,
                headers=(
                    {
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {self.api_key}",
                    }
                    if self.api_key
                    else {}
                ),
                timeout=5,
            )
            if r.status_code >= 400:
                raise ValueError(
                    f"API URL is reachable but returned error: {r.status_code} -> {r.text}"
                )
        except requests.RequestException as exc:
            raise ValueError(
                f"Failed to connect to API URL '{self.api_url}': {exc}"
            ) from exc

    # checks if the model is online
    def _check_model_online(self):
        if not self.api_url or not self.tokenizer_name:
            return

        # TODO: i do not know what endpoint it uses for health
        health_url = f"{self.api_url.rstrip('/')}/health"

        try:
            r = requests.post(
                health_url,
                headers=(
                    {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}
                ),
                timeout=5,
            )
            if r.status_code != 200:
                raise ValueError(
                    f"Tokenizer service seems offline at {health_url}. "
                    f"Status: {r.status_code}"
                )
        except requests.RequestException:
            raise ValueError(f"[WARN] Health endpoint unreachable: {health_url}")


class ExtractArgs(BaseModel):
    dsxplore: Optional[DSXplore] = None
    localxplore: Optional[LocalXplore] = None
    gitlab: Optional[GitLab] = None
    query_dsslm: Optional[SLMClient] = None
    content_column: str = "content"
    extensions: Optional[Union[List[str], Path]] = Field(default_factory=list)
    frameworks: Optional[Union[List[str], Path]] = Field(default_factory=list)
    binary_exts: Optional[Union[List[str], Path]] = Field(default_factory=list)
    sure_shot_binaries: Optional[Union[List[str], Path]] = Field(default_factory=list)
    sure_shot_non_binaries: Optional[Union[List[str], Path]] = Field(
        default_factory=list
    )
    skip_binaries: bool = Field(
        default=False, description="If we want to skip the binary "
    )
    format_json: bool = Field(
        default=False,
        description="If we want to format the json(Eg: No accepting NULL values)",
    )
    drop_columns: Optional[List[str]] = Field(default_factory=list)
    filter_conditions: Optional[List[str]] = Field(default_factory=list)
    number_code_blocks: bool = False
    count_tokens_columns: List[str] = Field(default_factory=list)
    tokenizer_args: Optional[TokenizerArgs] = None
    swagger_count: bool = False
    swagger_replacement: bool = False
    observability: Optional[TraceabilityArgs] = None

    # TODO: ASI84 (GET KNOWLEDGE ON THIS)
    # @model_validator(mode="before")
    # @classmethod
    # def validate_tokenizer_args(cls, values: Dict[str, Any]) -> Dict[str, Any]:
    #     if values.get("count_tokens_columns") and "tokenizer_args" not in values:
    #         raise ValueError(
    #             "tokenizer_args must be provided when count_tokens_columns is provided"
    #         )
    #     return values

    # TODO: Save the callables in a new field
    @field_validator("filter_conditions")
    @classmethod
    def validate_filter_conditions(cls, filter_conditions: List[str]) -> List[Callable]:
        callables = []
        for condition in filter_conditions:
            try:
                # Parse the string expression into an AST
                parsed_expr = ast.parse(condition, mode="eval")
                if not isinstance(parsed_expr.body, ast.Lambda):
                    raise ValueError(
                        f"The expression must be a lambda function: {condition}"
                    )

                # Compile the AST into a code object
                compiled_lambda = compile(parsed_expr, "<string>", "eval")

                # Evaluate the code object into a callable lambda function
                lambda_func = eval(compiled_lambda, {"__builtins__": {}})
                if not callable(lambda_func):
                    raise ValueError(f"Compiled function is not callable: {condition}")

                callables.append(lambda_func)
            except SyntaxError as e:
                raise ValueError(f"Invalid lambda function syntax: {condition}") from e
            except Exception as e:
                raise ValueError(
                    f"Failed to validate lambda function: {condition}"
                ) from e

        return callables

    @field_validator("extensions", "frameworks")
    @classmethod
    def validate_list_or_path(
        cls, value: Optional[Union[List[str], Path]], field
    ) -> Optional[Union[List[str], Path]]:
        if value is None:
            return value

        if isinstance(value, list):
            if not all(isinstance(item, str) for item in value):
                raise ValueError(f'"{field.name}" must be a list of strings')
            return value

        if isinstance(value, Path):
            if value.suffix == ".csv" and value.exists():
                return value
            raise ValueError(
                f'"{field.name}" must be a Path to a CSV file if it is a Path object'
            )

        raise ValueError(
            f'"{field.name}" must be either a list of strings or a Path to a CSV file'
        )
