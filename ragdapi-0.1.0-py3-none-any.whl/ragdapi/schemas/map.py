from pydantic import BaseModel, model_validator
from typing import Dict, Any
from pathlib import Path
import json
import os

def get_map_config_as_dict(schema_path):
    if Path(schema_path).is_file():
        with open(schema_path, "r") as f:
            schema_template = json.load(f)
        return schema_template
    else:
        raise FileNotFoundError(f"File {schema_path} does not exist.")

def get_default_schema_template_dir() -> Path:
    module_path = Path(__file__)
    module_directory = module_path.parent
    config_dir = module_directory / "../map/schemas"
    return config_dir.resolve()

class MapArgs(BaseModel):
    schema_template_path: str
    schema_template: Dict[str, Any]

    @model_validator(mode="before")
    @classmethod
    def validate_schema_template(cls, values):
        rel_path = values.get("schema_template_path")
        full_path = get_default_schema_template_dir()
        schema_template_path = os.path.join(full_path, rel_path.split("/")[-1])
        schema_template = get_map_config_as_dict(schema_template_path)
        if not schema_template:
            raise ValueError(f"Schema template file is empty")
        values["schema_template"] = schema_template
        return values
