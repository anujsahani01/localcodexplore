from pydantic import BaseModel
from typing import Literal

class GlobalTraceabilityArgs(BaseModel):
    launch_observability: bool
    type: Literal["doc", "code"]
    upload_to_aws: bool

class TraceabilityArgs(BaseModel):
    aws_bucket_path : str

