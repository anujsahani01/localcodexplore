from typing import Optional
from pydantic import BaseModel
from typing import Optional
from ragdapi.schemas.paths import Paths
from ragdapi.schemas.extract import ExtractArgs
from ragdapi.schemas.transform import TransformArgs
from ragdapi.schemas.map import MapArgs
from ragdapi.schemas.load import LoadArgs
from ragdapi.schemas.observability import GlobalTraceabilityArgs


class Config(BaseModel):
    name: str
    paths: Optional[Paths] = None
    extract: Optional[ExtractArgs] = None
    transform: Optional[TransformArgs] = None
    map: Optional[MapArgs] = None
    load: Optional[LoadArgs] = None
    observability: Optional[GlobalTraceabilityArgs] = None
