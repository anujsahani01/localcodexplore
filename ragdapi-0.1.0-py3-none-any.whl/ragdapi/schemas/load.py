import os
import time
import hmac
import hashlib
import requests
from pydantic import BaseModel, Field, field_validator, model_validator
from typing import Optional, Any


def fetch_ispass_username_password(
    password_id: str, public_key: str, private_key: str
) -> tuple:
    """
    Fetches username and password from ispass API using the provided password_id, public_key, and private_key.
    """
    ispass_base_url = "https://ispass.dsone.3ds.com/index.php/"
    req_uri = f"api/v5/passwords/{password_id}.json"

    request_body = ""

    # Calculate the HMAC hash
    timestamp = str(int(time.time()))
    unhashed = req_uri + timestamp + request_body
    hash = hmac.new(
        private_key.encode("utf-8"), unhashed.encode("utf-8"), hashlib.sha256
    ).hexdigest()

    # Set up headers
    headers = {
        "X-Public-Key": public_key,
        "X-Request-Hash": hash,
        "X-Request-Timestamp": timestamp,
        "Content-Type": "application/json; charset=utf-8",
    }

    # Send the GET request
    url = ispass_base_url + req_uri
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise exception in case of error
        response_body = response.json()
        return response_body["username"], response_body["password"]
    except requests.RequestException as e:
        raise ValueError(f"Failed to fetch username and password from ispass API: {e}")


class LoadArgs(BaseModel):
    """Model for the arguments required to load data into a RAG datasource."""

    rag_service_url: str = Field(
        description="Base URL of the RAG service."
    )
    datasourcename: str = Field(
        description="Name of the target datasource."
    )
    ds_tenant: str = Field(
        description="DS tenant identifier for SSO authentication."
    )
    username: Optional[str] = Field(
        default=None,
        description="SSO username. Mutually exclusive with ispass_* fields.",
    )
    password: Optional[str] = Field(
        default=None,
        description=(
            "SSO password. Mutually exclusive with ispass_* fields. "
            "Can be a plain-text password or the name of an environment "
            "variable containing the password (e.g. 'MY_SECRET_PASSWORD')."
        ),
    )

    @field_validator("password", mode="before")
    @classmethod
    def _resolve_password_env_var(cls, value: Optional[str]) -> Optional[str]:
        """If *value* matches an environment variable name, return its content."""
        if value is not None and value in os.environ:
            return os.environ[value]
        return value

    checkpoint_file_name: Optional[str] = Field(
        default=None,
        description="Explicit checkpoint filename override. When omitted, a name is derived from the config name and datasource.",
    )

    loading_batch_size: int = Field(
        default=50,
        description="Number of chunks sent per API ingest call.",
    )
    reading_batch_size: int = Field(
        default=1000,
        description="Number of chunks buffered in memory when streaming large files via ijson.",
    )
    streaming_file_size_limit_mb: int = Field(
        default=1000,
        description="Files larger than this threshold (in MB) are streamed instead of loaded fully into memory.",
    )

    chunks_per_second: float = Field(
        default=100.0,
        description="Target ingestion rate (chunks/sec). Acts as both the initial and maximum rate.",
    )
    min_chunks_per_second: float = Field(
        default=10.0,
        description="Floor to prevent the adaptive rate from dropping too low during back-pressure.",
    )
    rate_recovery_factor: float = Field(
        default=1.25,
        description="Multiplicative factor to gradually recover the ingestion rate after a successful request.",
    )
    rate_reduction_factor: float = Field(
        default=0.5,
        description="Multiplicative factor to reduce the ingestion rate on 507 Insufficient Storage.",
    )
    insufficient_storage_wait: int = Field(
        default=120,
        description="Initial wait time (seconds) on 507 Insufficient Storage before retrying. Doubles on each consecutive 507.",
    )

    max_retries: int = Field(
        default=5,
        description="Maximum number of general retries per batch.",
    )
    max_507_retries: int = Field(
        default=10,
        description="Maximum retries specifically for 507 Insufficient Storage errors.",
    )
    initial_backoff_seconds: int = Field(
        default=60,
        description="Initial backoff time (seconds) between general retries. Doubles on each retry.",
    )

    ispass_public_key: Optional[str] = Field(
        default=None,
        description="ISPass API public key for credential retrieval.",
    )
    ispass_private_key: Optional[str] = Field(
        default=None,
        description="ISPass API private key for credential retrieval.",
    )
    ispass_password_id: Optional[str] = Field(
        default=None,
        description="ISPass password entry ID for credential retrieval.",
    )

    @model_validator(mode="before")
    @classmethod
    def validate_load_args(cls, data: Any) -> Any:
        """ """
        # Check if both username/password and ispass_* fields are present
        if (data.get("username") or data.get("password")) and (
            data.get("ispass_public_key")
            or data.get("ispass_private_key")
            or data.get("ispass_password_id")
        ):
            raise ValueError(
                "Cannot provide both ispass_* fields and username/password."
            )

        # If any ispass_* field is provided, ensure all are present
        if any(
            [
                data.get("ispass_public_key"),
                data.get("ispass_private_key"),
                data.get("ispass_password_id"),
            ]
        ):
            if not all(
                [
                    data.get("ispass_public_key"),
                    data.get("ispass_private_key"),
                    data.get("ispass_password_id"),
                ]
            ):
                raise ValueError("All ispass_* fields must be provided together.")
            else:
                # Fetch the username and password from the ispass API
                try:
                    username, password = fetch_ispass_username_password(
                        data.get("ispass_password_id"),
                        data.get("ispass_public_key"),
                        data.get("ispass_private_key"),
                    )
                    # Set the fetched username and password
                    data["username"] = username
                    data["password"] = password
                except ValueError:
                    raise

        return data
