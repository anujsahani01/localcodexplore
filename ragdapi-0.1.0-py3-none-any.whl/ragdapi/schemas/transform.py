import inspect
import importlib
from pathlib import Path
from typing import List, Dict, Any, Optional, Type, TypeVar
from pydantic import BaseModel, Field, model_validator
from ragdapi.schemas.observability import TraceabilityArgs
from ragdapi.transform.chunkers.base import ChunkerBase

CHUNKERS_PACKAGE = "ragdapi.transform.chunkers"


TChunkerBase = TypeVar("TChunkerBase", bound=ChunkerBase)


def get_top_level_classes(package_name: str) -> Dict[str, Type]:
    package_dir = Path(importlib.import_module(package_name).__file__).parent
    modules = []

    for file in package_dir.glob("*.py"):
        if file.name not in ["base.py", "__init__.py"]:
            module_name = file.stem  # Use .stem to remove the .py extension
            modules.append(module_name)

    class_dict = {}
    for module_name in modules:
        full_module_name = f"{package_name}.{module_name}"
        module = importlib.import_module(full_module_name)
        for name, obj in inspect.getmembers(module, inspect.isclass):
            if obj.__module__ == full_module_name:
                class_dict[name] = obj

    return class_dict


class ChunkingStrategy(BaseModel):
    chunker_name: str
    parallelize: bool = True
    args: Dict[str, Any]


class TransformArgs(BaseModel):
    column_to_chunk: str = "content"
    code_file_extension: str = "file_extension"
    code_file: str = "file_path"
    save_intermediate: bool = False
    chunking_strategies: List[ChunkingStrategy]
    available_chunkers: Dict[str, Type[TChunkerBase]] = Field(default_factory=dict)
    observability: Optional[TraceabilityArgs] = None

    merge_framework_chunks: bool = False
    get_sqlite_format: bool = Field(
        default=False, description="If we want to save the chunks in DB instead of JSON"
    )
    # TODO: exclude binaries
    skip_binaries: bool = Field(
        default=False, description="If we want to skip the binary "
    )
    cached_locally: bool = Field(
        default=True,
        description="If the model is already present in the local i.e., cache folder",
    )
    format_json: bool = Field(
        default=False,
        description="If we want to format the json(Eg: No accepting NULL values)",
    )

    @model_validator(mode="before")
    @classmethod
    def validate_chunker_names(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        available_chunkers = get_top_level_classes(CHUNKERS_PACKAGE)
        chunking_strategies = values.get("chunking_strategies", [])

        for strategy in chunking_strategies:
            chunker_name = strategy.get("chunker_name")
            if chunker_name not in available_chunkers:
                raise ValueError(
                    f"Chunker '{chunker_name}' does not exist in {CHUNKERS_PACKAGE}"
                )

        values["available_chunkers"] = available_chunkers

        return values
