import json
import logging
import uuid
import hashlib
from tqdm import tqdm
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional

from ragdapi.schemas.config import Config

logger = logging.getLogger(__name__)


class Mapper:
    def __init__(self, config: Config):
        self.config = config
        self.map_output = config.paths.map_output
        self.schema_template = config.map.schema_template
        self.files_to_process = []

        # Check if the transform output path is a directory
        transform_output_path = (
            self.config.paths.root / self.config.paths.transform_output
        ).resolve()
        if transform_output_path.is_dir():
            logger.debug(
                f"Transform output path is a directory: {transform_output_path}"
            )
            self.files_to_process = sorted(transform_output_path.glob("*.json"))
            if not self.files_to_process:
                raise FileNotFoundError(
                    f"No JSON files found in directory: {transform_output_path}"
                )
        else:
            logger.debug(
                f"Transform output path is a single file: {transform_output_path}"
            )
            self.files_to_process = [transform_output_path]

        logger.info(f"Mapper initialized with config: {self.config.name}")

    @classmethod
    def from_config(cls, config: Config) -> "Mapper":
        return cls(config)

    def convert_to_epoch_ms(self, date_str: str) -> int:
        dt = datetime.strptime(date_str, "%m/%d/%Y %H:%M:%S")
        return int(dt.timestamp() * 1000)

    def generate_short_uuid_from_url(self, url: str) -> str:
        return uuid.uuid5(uuid.NAMESPACE_URL, url).hex[:16]

    def hash_value(self, value: str) -> str:
        return hashlib.sha256(value.encode("utf-8")).hexdigest()

    def get_value(self, chunk: Dict[str, Any], field: str) -> Optional[str]:
        return chunk.get("metadata", {}).get(field)

    def clean_content(self, content: str) -> str:
        return content.replace("\n", "\\n").replace('"', '\\"')

    def generate_event_id(
        self,
        data: Dict[str, Any],
        content_id: str,
        content__version: str,
        chunk_identifier: int,
    ) -> str:
        return (
            f"{content_id}_{chunk_identifier}_{data['release__id']}_{content__version}"
        )

    def map(self, chunk: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError("Subclasses must implement this method")

    def map_and_save_files(self) -> "Mapper":
        """Iterate over files and map their contents."""
        for file_path in tqdm(
            self.files_to_process, desc=f"Mapping into {self.map_output}"
        ):
            mapped_file = (
                self.config.paths.root
                / self.map_output
                / f"{file_path.stem}_mapped.json"
            )
            if mapped_file.exists():
                logger.info(f"File {mapped_file} already exists. Continuing...")
                continue
            logger.info(f"Processing file: {file_path}")
            chunks = self._load_chunks_from_file(file_path)
            mapped_chunks = [self.map(chunk) for chunk in chunks]
            self._save_mapped_chunks_as_json(
                mapped_chunks,
                (
                    f"{file_path.stem}_mapped.json"
                    if len(self.files_to_process) > 1
                    else None
                ),
            )
            logger.debug(f"Mapped and saved chunks for {file_path}")
        return self

    def _load_chunks_from_file(self, file_path: Path) -> List[Dict[str, Any]]:
        """Load chunks from a single JSON file."""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                chunks = json.load(f)
                logger.debug(f"Loaded {len(chunks)} chunks from {file_path}")
                return chunks
        except (FileNotFoundError, json.JSONDecodeError) as e:
            logger.error(f"Could not load chunks from {file_path}: {e}")
            raise

    def _save_mapped_chunks_as_json(
        self, mapped_chunks: List[Dict[str, Any]], file_name: Path
    ):
        """Save the mapped chunks to an output JSON file."""
        if file_name:
            output_path = self.config.paths.root / self.map_output / file_name
        else:
            output_path = self.config.paths.root / self.map_output

        try:
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(mapped_chunks, f, ensure_ascii=False, indent=4)
            logger.info(
                f"Successfully saved {len(mapped_chunks)} mapped chunks to {output_path}"
            )
        except Exception as e:
            logger.error(f"Error saving mapped chunks to '{output_path}': {e}")
            raise
        
    def run_pipeline(self) -> "Mapper":
        """
        Orchestrate full mapping pipeline (remplace map_and_save_files).
        """
        return self.map_and_save_files()
