from typing import Dict, Any
import logging
import time
import pandas as pd

from ragdapi.map.mapper import Mapper

logger = logging.getLogger(__name__)


class DocMapper(Mapper):
    def __init__(self, schema_template: Dict[str, Any]):
        super().__init__(schema_template)

    def map(self, chunk: Dict[str, Any]) -> Dict[str, Any]:
        if not any(key in chunk.keys() for key in ("page_content", "metadata")):
            logger.warning(
                f"ERROR: Neither 'page_content' nor 'metadata' keys are present in the chunk: {chunk.keys()}"
            )
            return {}

        data = {
            key: self.get_value(chunk, field)
            for key, field in self.schema_template.items()
        }
        content__version = self.schema_template.get("content__version")
        content_id = self.generate_short_uuid_from_url(data["content__path"])
        data.update(
            {
                "r_schemaName": self.schema_template.get("r_schemaName"),
                "event__schema_version": self.schema_template.get(
                    "event__schema_version"
                ),
                "r_service": self.schema_template.get("r_service"),
                "content__version": content__version,
                # "content__body": self.clean_content(chunk.get("page_content", "")),
                "content__body": chunk.get("page_content", ""),
                "last__modified_date": self.convert_to_epoch_ms(
                    data["last__modified_date"]
                ),
                "content__id": content_id,
                "event__id": self.generate_event_id(
                    data, content_id, content__version, data["chunk_number"]
                ),
                "event__start": int(time.time() * 1000),
                "r_timestamp": int(time.time() * 1000),
            }
        )
        # Remove chunk_number from json
        data.pop("chunk_number", None)
        return {
            k: v
            for k, v in data.items()
            if v is not None and v != "" and not pd.isna(v)
        }
