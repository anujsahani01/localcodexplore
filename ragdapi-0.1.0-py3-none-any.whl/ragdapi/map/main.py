import os

# To deactivate transformers warnings
os.environ["TRANSFORMERS_VERBOSITY"] = "error"

import sys
import logging
from ragdapi.map.doc import DocMapper
from ragdapi.map.srccode import CodeMapper
from ragdapi.utils.logger import setup_logging
from ragdapi.utils.udf import parse_args
from ragdapi.utils.config_utils import (
    list_config_files,
    load_config,
    get_config_selection,
    validate_config_selection,
)

logger = logging.getLogger(__name__)


def main():
    args = parse_args()
    setup_logging(args.debug, args.redirect)

    try:
        config_files = list_config_files()
    except FileNotFoundError as e:
        logger.error(e)
        sys.exit(1)

    if args.config:
        config_name = args.config
        try:
            validate_config_selection(config_name, config_files)
        except ValueError as e:
            logger.error(e)
            sys.exit(1)
    else:
        config_name = get_config_selection(config_files)

    config = load_config(config_name)

    # TODO fin a prettier way to do that
    if "code" in config.map.schema_template_path:
        CodeMapper.from_config(config).run_pipeline()
    elif "doc" in config.map.schema_template_path:
        DocMapper.from_config(config).run_pipeline()
    else:
        raise ValueError(
            "The name of the schema must conatain explicit 'doc' or 'code' name in oder to know which stategy use for mapping"
        )


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
        logger.info("Program interrupted by user. Exiting gracefully. ✨")
