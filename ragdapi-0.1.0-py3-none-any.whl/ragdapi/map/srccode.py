from typing import Dict, Any
import logging
import time
import csv
import ast
from pathlib import Path
import pandas as pd

from ragdapi.map.mapper import Mapper

logger = logging.getLogger(__name__)


class CodeMapper(Mapper):
    def __init__(self, schema_template: Dict[str, Any]):
        super().__init__(schema_template)
        self.extension_to_languages = self._load_extension_language_mapping()

    def _load_extension_language_mapping(self):
        extension_to_languages = {}

        ext_lang_mapping_csv_file_path = (
            Path(__file__).parent / "cloc_extensions_languages.csv"
        )
        if not ext_lang_mapping_csv_file_path.exists():
            raise FileNotFoundError(
                f"The file '{ext_lang_mapping_csv_file_path}' containing the extensions-languages mapping does not exist in {Path(__file__).parent}."
            )

        with ext_lang_mapping_csv_file_path.open(mode="r") as file:
            reader = csv.DictReader(file)
            for row in reader:
                # Extract the extension and the language(s)
                extension = row["extension"]

                # Convert the string representation of list into an actual list using ast.literal_eval
                languages = ast.literal_eval(row["language"])

                # Concatenate the languages into a single string
                concatenated_languages = ", ".join(languages)

                # Assign the extension to the corresponding concatenated languages in the dictionary
                extension_to_languages[extension] = concatenated_languages

        return extension_to_languages

    def map(self, chunk: Dict[str, Any]) -> Dict[str, Any]:
        if not any(key in chunk.keys() for key in ("page_content", "metadata")):
            logger.warning(
                f"ERROR: Neither 'page_content' nor 'metadata' keys are present in the chunk: {chunk.keys()}"
            )
            return {}

        data = {
            key: self.get_value(chunk, field)
            for key, field in self.schema_template.items()
        }
        content__version = self.schema_template.get("content__version")
        if content__language := self.extension_to_languages.get(
            data["file__extension"]
        ):
            pass
        elif content__language := self.extension_to_languages.get(
            "".join(Path(data["file__path"]).suffixes)[1:]
        ):
            pass
        else:
            content__language = data["file__extension"]
        content_id = self.generate_short_uuid_from_url(data["content__path"])
        data.update(
            {
                "r_schemaName": self.schema_template.get("r_schemaName"),
                "event__schema_version": self.schema_template.get(
                    "event__schema_version"
                ),
                "r_service": self.schema_template.get("r_service"),
                "content__version": content__version,
                # "content__body": self.clean_content(chunk.get("page_content", "")),
                "content__body": chunk.get("page_content", ""),
                "last__modified_date": self.convert_to_epoch_ms(
                    data["last__modified_date"]
                ),
                "content__id": content_id,
                "event__id": self.generate_event_id(
                    data, content_id, content__version, data["content__chunk_id"]
                ),
                "event__start": int(time.time() * 1000),
                "content__url": f"https://dsxplore.dsone.3ds.com/mashup-ui{data['content__path']}",
                "framework__owner_hash": self.hash_value(data["framework__owner_hash"]),
                "file__owner_hash": self.hash_value(data["file__owner_hash"]),
                "content__language": content__language,
                "r_timestamp": int(time.time() * 1000),
                "content__chunk_id": str(data["content__chunk_id"]),
            }
        )
        # Remove content__path from json
        data.pop("content__path", None)
        return {
            k: v
            for k, v in data.items()
            if v is not None and v != "" and not pd.isna(v)
        }
