import sqlite3
import logging
from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime


@dataclass
class FileMapEntry:
    """Structural metadata for a single source file."""
    filepath: str
    imports: List[str] = field(default_factory=list)
    classes: List[dict] = field(default_factory=list)
    functions: List[str] = field(default_factory=list)
    top_level_variables: List[str] = field(default_factory=list)

    def to_compact_string(self) -> str:
        lines = [self.filepath]
        if self.imports:
            lines.append(f"  imports: {', '.join(self.imports)}")
        for var in self.top_level_variables:
            lines.append(f"  {var}")
        for cls in self.classes:
            lines.append(f"  {cls['signature']}")
            for method in cls.get("methods", []):
                lines.append(f"    {method}")
        for func in self.functions:
            lines.append(f"  {func}")
        return "\n".join(lines)


class RepoMapStore:
    """
    Master table: one row per workspace, one concatenated repo map.
    
    | workspace_path | version | repo_map |
    """

    TABLE = "master_code_repo"

    def __init__(self, db_path: str):
        self.conn = sqlite3.connect(db_path)
        self.conn.execute(f"""
            CREATE TABLE IF NOT EXISTS {self.TABLE} (
                workspace_name  TEXT NOT NULL,
                version         TEXT NOT NULL,
                repo_map        TEXT NOT NULL,
                updated_at      TEXT NOT NULL,
                PRIMARY KEY (workspace_name, version)
            );
        """)
        self.conn.commit()

    def save(self, workspace_name: str, version: str, repo_map: str):
        """Insert or replace the full repo map for a workspace + version"""
        self.conn.execute(
            f"""
            INSERT INTO {self.TABLE} (workspace_name, version, repo_map, updated_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(workspace_name, version) DO UPDATE SET
                repo_map   = excluded.repo_map,
                updated_at = excluded.updated_at
            """,
            (workspace_name, version, repo_map, datetime.utcnow().isoformat()),
        )
        self.conn.commit()
        logging.info(f"Repo map saved for workspace: {workspace_name}, version: {version}")

    def get(self, workspace_name: str, version: str) -> Optional[str]:
        row = self.conn.execute(
            f"SELECT repo_map FROM {self.TABLE} WHERE workspace_name = ? AND version = ?",
            (workspace_name, version),
        ).fetchone()
        return row[0] if row else None


    def get_latest(self, workspace_name: str) -> Optional[str]:
        row = self.conn.execute(
            f"SELECT repo_map FROM {self.TABLE} WHERE workspace_name = ? ORDER BY updated_at DESC LIMIT 1",
            (workspace_name,),
        ).fetchone()
        return row[0] if row else None


    def delete(self, workspace_name: str, version: str):
        self.conn.execute(
            f"DELETE FROM {self.TABLE} WHERE workspace_name = ? AND version = ?",
            (workspace_name, version),
        )
        self.conn.commit()

    def close(self):
        self.conn.close()