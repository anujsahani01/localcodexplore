import json
import logging
import warnings
import pandas as pd
from tqdm import tqdm
from typing import List, Optional, Tuple, Any, Union
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from langchain_core.documents.base import Document
from ragdapi.observability.in_process.decorators import Observability
from ragdapi.schemas.config import Config
from ragdapi.schemas.transform import ChunkingStrategy, TChunkerBase
from ragdapi.utils.udf import versions_to_rank
import filetype
import os
import re
import asyncio
import re
import sqlite3
import platform
import hashlib
from pathlib import Path
from ragdapi.transform.repo_map import RepoMapStore
from ragdapi.transform.repo_map_builder import RepoMapBuilder



logger = logging.getLogger(__name__)
stats_logger = logging.getLogger("Stats")


class Transformer:
    def __init__(self, config: Config):
        self.config = config
        self.transform_output = config.paths.transform_output
        self.available_chunkers = config.transform.available_chunkers
        self.files_to_process = []
        extract_output_path = self.config.paths.root / self.config.paths.extract_output

        if self.config.transform.get_sqlite_format:
            "In this case files to process will be basically the table name to process"
            # regardless of if extract_output_path is csv or dir is will take the initials i.e., "extract"
            self.files_to_process = [
                str(extract_output_path).split("/")[-1].split(".")[0]
            ]
        else:
            if extract_output_path.is_dir():
                logger.debug(
                    f"Extract output path is a directory: {extract_output_path}"
                )
                self.files_to_process = sorted(extract_output_path.glob("*.csv"))
                if not self.files_to_process:
                    raise FileNotFoundError(
                        f"No CSV files found in directory: {extract_output_path}"
                    )
            else:
                logger.debug(
                    f"Extract output path is a single file: {extract_output_path}"
                )
                self.files_to_process = [extract_output_path]

        # taking first n files only for testing
        # self.files_to_process = self.files_to_process[:50]
        logger.info(f"Transformer initialized with config: {self.config.name}")

    @classmethod
    def from_config(cls, config: Config) -> "Transformer":
        return cls(config)

    def clean_dict(self, obj):
        """
        Recursively clean NaN/None in dictionaries/lists inside a DataFrame row
        """
        if isinstance(obj, dict):
            return {k: self.clean_dict(v) for k, v in obj.items()}
        elif pd.isna(obj) or obj is None or str(obj).strip() == "Nan":
            return "null"  # removing Nan Values
        else:
            return str(obj)  # force everything to string

    def chunk_content_and_save(
        self, workspace_path, modified_filepaths, version
    ) -> "Transformer":
        """Process each CSV file and apply chunking strategies in sequence."""

        # ── CHANGE 1: Initialize repo map builder BEFORE the loop ──
        home_dir = Path.home()
        my_lib_path = os.path.join(home_dir, ".LocalXplore")
        if not os.path.exists(my_lib_path):
            os.mkdir(my_lib_path)

        repo_map_store = RepoMapStore(db_path=os.path.join(my_lib_path, "DS3.db"))
            
        # Derive workspace_name from path (same logic used for table names)
        workspace_info = str(os.path.normpath(Path(workspace_path))).split(os.sep)[-1]
        workspace_name = f"{workspace_info}_{version}"
        repo_map_builder = RepoMapBuilder(repo_map_store, workspace_name, version)

        for file_path in tqdm(self.files_to_process, desc="Chunking files"):
            logger.info(f"Processing file: {file_path}")
            if self.config.transform.get_sqlite_format:
                logger.info(f"Loading the extracted table form sqlite DB")
                output_path = self.config.paths.root / self.config.paths.extract_output
                output_path = os.path.normpath(Path(output_path))
                workspace_path = os.path.normpath(Path(workspace_path))
                workspace_info = str(workspace_path).split("\\")[-1]
                workspace_name = f"{workspace_info}_{version}"
                table_info = str(output_path).split("\\")[-1].split(".")[0]
                table_name = f"{workspace_name}_{table_info}"
                extract_table_name = f"{workspace_name}_{table_info}"
                logger.info(f"The table containing the extracted chunks is: {table_name}")
                # setting up path where DB will sit
                home_dir = Path.home()  # works on Windows, Linux, macOS
                my_lib_path = os.path.join(home_dir, ".LocalXplore")
                # if not is
                # my_lib_path.mkdir(exist_ok=True)
                if not os.path.exists(my_lib_path):
                    os.mkdir(my_lib_path)
                # setting up connection to db
                con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
                # creating curson for traversal
                cur = con.cursor()
                """
                sqlite_master: is SQLite's internal catalog of tables, indexes, triggers, etc.
                """
                cur.execute(
                    "SELECT name from sqlite_master WHERE type = 'table'AND name =?;",
                    (table_name,),
                )

                tables = cur.fetchall()
                if tables:
                    dataframe = pd.read_sql_query(
                        f"SELECT * FROM '{table_name}' WHERE is_chunked = 0", con
                    )
                else:
                    raise Exception("The table dosen't exists in the DB")
            else:
                logger.info(f"Loading the extracted files DB")
                dataframe = self._load_dataframe(file_path)
                logger.info(f"Number of Extrcated files are: {len(dataframe)}")

            logger.info(f"Dropped the files with no extensions")
            initial_size = len(dataframe)
            dataframe.dropna(subset=["file_extension"], inplace=True)
            dataframe = dataframe[dataframe["file_extension"] != ""]
            logger.info(
                f"The number of files with no extension is: {initial_size - len(dataframe)}"
            )
            # Removing Nan values form dataframe
            if self.config.transform.format_json:
                logger.info(f"Formatting the JSON")
                for col in list(dataframe.columns):
                    dataframe[col] = dataframe[col].apply(self.clean_dict)
            else:
                logger.info(f"The JSON is not formatted may have NULL values in it")

            chunks: List[Document] = []
            versions: List[str] = []
            for chunking_strategy in self.config.transform.chunking_strategies:
                chunker = self._get_chunker(chunking_strategy)
                logger.debug(
                    f"Using chunker: {chunker.__class__.__name__} for file: {file_path}"
                )

                # ── CHANGE 2: Attach builder to AST chunker ──
                # If the file format is not supported by 
                if hasattr(chunker, 'repo_map_builder'):
                    chunker.repo_map_builder = repo_map_builder

                logger.debug(
                    f"Using chunker: {chunker.__class__.__name__} for file: {file_path}"
                )

                if chunking_strategy.parallelize:
                    logger.info(
                        f"Applying chunking strategy (in parallel): {chunking_strategy.chunker_name}"
                    )
                    chunks, versions = self._apply_chunking_parallel(
                        dataframe, chunker, chunks
                    )
                else:
                    logger.info(
                        f"Applying chunking strategy: {chunking_strategy.chunker_name}"
                    )
                    chunks, versions = self._apply_chunking(dataframe, chunker, chunks)

                # If there are more chunking strategies and save_intermediate is True, save intermediate chunks
                if (
                    len(self.config.transform.chunking_strategies) > 1
                    and self.config.transform.save_intermediate
                ):
                    intermediate_name = (
                        f"{file_path.stem}_{chunker.__class__.__name__}.json"
                    )
                    logger.info(f"Saving intermediate chunks as {intermediate_name}")
                    # TODO
                    # Directly save the intermediate chunks without applying version ranking
                    self.save_chunks_as_json(
                        chunks, chunking_strategy, intermediate_name
                    )

            # After all chunking strategies, update the versions for final chunks
            logger.debug("Updating chunk versions after all chunking strategies.")
            chunks = self._update_chunk_versions(chunks, versions)

            if self.config.transform.get_sqlite_format:
                logger.info(f"Saving the final chunks in the sqlite table.")
                output_path = self.config.paths.transform_output
                output_path = os.path.normpath(output_path)
                table_info = str(output_path).split("\\")[-1].split(".")[0]
                table_name = f"{workspace_name}_{table_info}"
                home_dir = Path.home()  # works on Windows, Linux, macOS
                my_lib_path = os.path.join(home_dir, ".LocalXplore")
                # my_lib_path.mkdir(exist_ok=True)
                if not os.path.exists(my_lib_path):
                    os.mkdir(my_lib_path)

                con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
                cur = con.cursor()
                """
                sqlite_master : is SQLite's internal catalog for tables
                """
                # will check if transform table is already present in the DB
                cur.execute(
                    "SELECT name from sqlite_master WHERE type = 'table' AND name =?;",
                    (table_name,),
                )
                tables = cur.fetchall()

                if platform.system().lower() == "linux":
                    path_key = "unixfullpath"
                elif platform.system().lower() == "windows":
                    path_key = "windowsfullpath"
                if not tables:
                    self._create_and_save_chunks_as_sqlite_db(
                        chunks,
                        chunking_strategy,
                        table_name,
                        extract_table_name,
                        con,
                        cur,
                        False,
                        path_key,
                    )
                else:
                    self._create_and_save_chunks_as_sqlite_db(
                        chunks,
                        chunking_strategy,
                        table_name,
                        extract_table_name,
                        con,
                        cur,
                        True,
                        path_key,
                    )

            else:
                logger.info(f"Saving final chunks for file: {file_path}")
                self.save_chunks_as_json(
                    chunks,
                    chunking_strategy,
                    (
                        f"{file_path.stem}.json"
                        if len(self.files_to_process) > 1
                        else None
                    ),
                )

        # ── CHANGE 3: Flush the concatenated repo map AFTER all files ──
        repo_map_builder.flush()
        repo_map_store.close()
        logger.info(f"Repo map saved for workspace: {workspace_name}")

        return self

    # Helpers
    def digit_heavy(self, decoded: str, numeric_threshold: float = 0.7) -> bool:
        cleaned = re.sub(r"[^\d\s\.,\-eE+]", "", decoded)
        total_chars = len(decoded)
        num_chars = len(cleaned)
        if total_chars == 0:
            return False
        return (num_chars / total_chars) > numeric_threshold

    def token_numeric_ratio(self, decoded: str, threshold=0.7) -> bool:
        tokens = re.split(r"\s+|,|;|\||\t", decoded)
        tokens = [t.strip() for t in tokens if t.strip()]
        if not tokens:
            return False
        numeric_tokens = [
            t
            for t in tokens
            if re.fullmatch(r"[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?", t)
        ]
        return (len(numeric_tokens) / len(tokens)) > threshold

    # Define byte-based binary detection
    def is_binary_string(
        self,
        content: Union[bytes, str],
        extension: str,
        df,
        extention_list: list,
        binary_threshold=0.3,
        numeric_threshold=0.8,
        encodings=["utf-8", "latin-1", "windows-1252"],
    ) -> bool:
        """
        This method is used to filter out the binary files or the files which has 80% of numerical chars in it.

        content: The original conten to of the file extracted
        binary_threshold: Means if the code file has more than 30% of non-asciii chars then if will be considered as binary
        numeric_threishold: Tf the file has more tha 70%  of numbers
        """
        if not content or str(content).lower in ["nan", "null", "none"]:
            return False  # Empty is not binary or numeric-heavy

        if extension in extention_list:
            return True
        # Convert string to bytes
        if isinstance(content, str):
            for encoding in encodings:
                try:
                    content = content.encode("utf-8", errors="ignore")
                    decode_success = True
                    break
                except FileNotFoundError:
                    logger.error(f"File not found: {df['filepath']}")
                    file_not_found = True
                    break
                except (UnicodeDecodeError, LookupError):
                    logger.warning(
                        f"Failed to read {df['filepath']} with encoding: {encoding}"
                    )

                if file_not_found:
                    continue
        else:
            return True

        # filtering large files into 8k chars
        sample = content[:8000]

        # Define valid text characters (ASCII)
        text_characters = bytearray({7, 8, 9, 10, 12, 13, 27} | set(range(0x20, 0x7F)))

        # Removing ASCII characters prsent in binary files.
        nontext = sample.translate(None, text_characters)
        binary_ratio = len(nontext) / len(sample)
        if binary_ratio > binary_threshold:
            return True

        # Filtering only number files
        try:
            decoded = sample.decode("utf-8", errors="ignore")
            printable_chars = [c for c in decoded if c.isprintable()]
            if not printable_chars:
                try:
                    decoded = sample.decode("utf-8", errors="ignore")
                    if not decoded.strip():
                        return False

                    # Enhanced digit-heavy heuristics
                    if self.digit_heavy(
                        decoded, numeric_threshold
                    ) or self.token_numeric_ratio(decoded, numeric_threshold):
                        return True
                except Exception:
                    pass

                return False  # Not enough data to decide

            num_digits = sum(c.isdigit() for c in printable_chars)
            digit_ratio = num_digits / len(printable_chars)
            if digit_ratio > numeric_threshold:
                return True  # Numeric-heavy file → classify as binary-like
        except Exception:
            pass

        return False  # Not binary, not numeric-heavy → text

    async def is_binary_async(self, content, extension, executor, df, exts_list):
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            executor, self.is_binary_string, content, extension, df, exts_list
        )

    async def detect_binary_rows_async(
        self,
        df: pd.DataFrame,
        exts_list: List,
        content_col: str = "content",
        extension_col: str = "file_extension",
        max_workers: int = 10,
    ) -> pd.Series:
        executor = ThreadPoolExecutor(max_workers=max_workers)

        tasks = [
            self.is_binary_async(content, extension, executor, df, exts_list)
            for content, extension in zip(df[content_col], df[extension_col])
        ]

        results = await asyncio.gather(*tasks)
        return pd.Series(results, index=df.index)

    def _load_dataframe(self, file_path: Any) -> pd.DataFrame:
        """
        Helper function to load a CSV file into a dataframe.
        Filetype.guess will help us in guessing the filetye
        None is returned if file is non-binary
        """
        try:
            logger.debug(f"Loading CSV file: {file_path}")
            df = pd.read_csv(file_path)
            df.dropna(subset=["file_extension"], inplace=True)
            df.dropna(subset=[self.config.transform.column_to_chunk], inplace=True)
            # Inefficient Method to filter binary files
            # for idx, rows in df.iterrows():
            #     if filetype.guess(str(rows['content']).encode("utf-8")) is not None:
            #         df.drop(idx, inplace = True)
            if self.config.transform.skip_binaries:
                with open("./binary_exts.json", "r", encoding="utf-8") as f:
                    data = json.load(f)

                exts_list = list(set(data.get("BINARY_EXTENSIONS")))
                binary_flags = asyncio.run(
                    self.detect_binary_rows_async(
                        df, exts_list, content_col=self.config.transform.column_to_chunk
                    )
                )
                df1 = df[binary_flags == True]
                binary_exts = df1["file_extension"].tolist()
                diff = set(binary_exts) - set(exts_list)
                # diff = list(diff)
                # Step 4: If new extensions found, update and write file
                if diff:
                    updated_exts = list(set(exts_list).union(diff))
                    data["BINARY_EXTENSIONS"] = updated_exts
                    # with open("./binary_exts.json", "r", encoding = 'utf-8') as f:
                    #     data = json.load(f)
                    # exts = data.get('BINARY_EXTENSIONS')
                    # exts.extend(binary_exts)
                    # updated_set = list(set(exts))
                    # data['BINARY_EXTENSIONS'] = updated_set

                    with open("./binary_exts.json", "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=4)

                # removing binary files
                pre = len(df)
                df = df[binary_flags == False]
                post = len(df)
                logging.info(f"The number of binary files removed are: {int(pre-post)}")
            df.reset_index(inplace=True)
            return df
        except FileNotFoundError:
            logger.error(f"File not found: {file_path}")
            raise
        except Exception as e:
            logger.error(f"Error reading CSV file '{file_path}': {e}")
            raise

    def _get_chunker(self, chunking_strategy: ChunkingStrategy) -> TChunkerBase:
        """Helper function to retrieve a chunker based on strategy configuration."""
        chunker_name = chunking_strategy.chunker_name
        chunker_args = chunking_strategy.args
        logger.debug(f"Retrieving chunker {chunker_name} with args {chunker_args}")
        return self.available_chunkers[chunker_name](**chunker_args)

    def _apply_chunking(
        self,
        dataframe: pd.DataFrame,
        chunker: TChunkerBase,
        previous_chunks: Optional[List[Document]],
    ) -> Tuple[List[Document], List[str]]:
        """Apply chunking strategy to a dataframe or a list of previous chunks."""
        logger.debug(
            f"Applying chunking to dataframe with chunker: {chunker.__class__.__name__}"
        )

        # removing the rows which do not have any code inside of it
        logger.info(f"Removing the empty extracted files")
        initial_len = len(dataframe)
        empty_df = dataframe[
            dataframe[self.config.transform.column_to_chunk].isna()
            | dataframe[self.config.transform.column_to_chunk]
            == ""
        ]
        dataframe.dropna(subset=[self.config.transform.column_to_chunk], inplace=True)
        dataframe.reset_index(inplace=True, drop=True)
        diff = int(initial_len - len(dataframe))
        logger.info(f"The extracted dataframe had {diff} empty files.")
        if diff:
            logger.info(
                f"The list of files with no content are:{empty_df['windowsfullpath']}"
            )

        return self._process_chunks(dataframe, chunker, previous_chunks)

    def _apply_chunking_parallel(
        self,
        dataframe: pd.DataFrame,
        chunker: TChunkerBase,
        previous_chunks: Optional[List[Document]],
    ) -> Tuple[List[Document], List[str]]:
        """Apply chunking strategy in parallel using ProcessPoolExecutor."""

        # removing the rows which do not have any code inside of it
        dataframe.dropna(subset=[self.config.transform.column_to_chunk], inplace=True)
        dataframe.reset_index(inplace=True, drop=True)

        if not previous_chunks:
            logger.debug("Starting parallel chunking on raw dataframe.")
            data_to_chunk = [(row, chunker) for _, row in dataframe.iterrows()]
            chunk_function = self._chunk_row
        else:
            logger.debug("Starting parallel chunking on previous chunks.")
            data_to_chunk = [(chunk, chunker) for chunk in previous_chunks]
            chunk_function = self._chunk_existing_chunk

        with ProcessPoolExecutor() as executor:
            results = executor.map(chunk_function, data_to_chunk)

        chunks = [chunk for result in results for chunk in result]  # Flatten results
        versions = [chunk.metadata["chunk_number"] for chunk in chunks]
        logger.debug(f"Parallel chunking completed. {len(chunks)} chunks created.")
        return chunks, versions

    def _process_chunks(
        self,
        dataframe: pd.DataFrame,
        chunker: TChunkerBase,
        previous_chunks: Optional[List[Document]],
    ) -> Tuple[List[Document], List[str]]:
        """Processes chunks, handling both initial and subsequent chunking strategies."""
        chunks: List[Document] = []
        versions: List[str] = []

        if not previous_chunks:  # First chunking strategy
            logger.debug("Processing first chunking strategy.")
            for index_doc, row in dataframe.iterrows():
                # logger.info(f'Chunking path: {row["file_path"]} - {index_doc}')
                chunked_texts = self._chunk_text(row, chunker)
                if chunked_texts is not None:
                    new_chunks, new_versions = self._create_new_chunks(
                        row.drop(self.config.transform.column_to_chunk).to_dict(),
                        chunked_texts,
                        index_doc,
                    )
                    chunks.extend(new_chunks)
                    versions.extend(new_versions)

        else:  # Subsequent chunking strategies
            logger.debug("Processing subsequent chunking strategy.")
            for chunk in previous_chunks:
                chunked_texts = self._chunk_text(chunk.page_content, chunker)
                if chunked_texts is not None:
                    new_chunks, new_versions = self._create_new_chunks(
                        chunk.metadata, chunked_texts, chunk.metadata["chunk_number"]
                    )
                    chunks.extend(new_chunks)
                    versions.extend(new_versions)

        logger.debug(f"{len(chunks)} chunks created in this step")

        return chunks, versions

    def _create_new_chunks(
        self, base_metadata: dict, chunked_texts: List[Document], base_version: Any
    ) -> Tuple[List[Document], List[str]]:
        """Helper function to create new chunks and update metadata."""
        chunks: List[Document] = []
        versions: List[str] = []

        for index_chunk, chunk in enumerate(chunked_texts):
            version = f"{base_version}.{index_chunk}"
            # updating that the file in chunked
            base_metadata["is_chunked"] = "1"
            chunk.metadata = {
                **base_metadata,
                **chunk.metadata,
                "chunk_number": version,
            }
            versions.append(version)
            chunks.append(chunk)

        return chunks, versions

    def _chunk_text(self, row, chunker: TChunkerBase) -> List[Document]:
        """
        Helper function to chunk text using a given chunker.
        Do not return any chunks for binary files.
        """
        # return chunker.chunk_text(text=text)

        if self.config.transform.skip_binaries:
            kind = filetype.guess(
                row[self.config.transform.column_to_chunk].encode("utf-8")
            )
            # Prevents from chunking binary files
            if kind is None:
                # TODO:verify this logic with zakaria
                for strategies in self.config.transform.chunking_strategies:
                    if strategies.chunker_name == "ASTCollapsingCodeChunker":
                        return chunker.chunk_text(
                            text=row[self.config.transform.column_to_chunk],
                            chunks=[],
                            extension=row[self.config.transform.code_file_extension],
                            filepath=row[self.config.transform.code_file],
                        )
                    else:
                        return chunker.chunk_text(
                            text=row[self.config.transform.column_to_chunk],
                        )
            else:
                return
        else:
            for strategies in self.config.transform.chunking_strategies:
                if strategies.chunker_name == "ASTCollapsingCodeChunker":
                    return chunker.chunk_text(
                        text=row[self.config.transform.column_to_chunk],
                        chunks=[],
                        extension=row[self.config.transform.code_file_extension],
                        filepath=row[self.config.transform.code_file],
                    )
                else:
                    return chunker.chunk_text(
                        text=row[self.config.transform.column_to_chunk],
                    )

    def _chunk_row(self, args: Tuple[pd.Series, TChunkerBase]) -> List[Document]:
        """Helper function to chunk a dataframe row."""
        row, chunker = args
        return self._create_new_chunks(
            row.drop(self.config.transform.column_to_chunk).to_dict(),
            self._chunk_text(row[self.config.transform.column_to_chunk], chunker),
            row.name,
        )[0]

    def _chunk_existing_chunk(
        self, args: Tuple[Document, TChunkerBase]
    ) -> List[Document]:
        """Helper function to chunk existing chunks in parallel."""
        chunk, chunker = args
        return self._create_new_chunks(
            chunk.metadata,
            self._chunk_text(chunk.page_content, chunker),
            chunk.metadata["chunk_number"],
        )[0]

    def _update_chunk_versions(
        self, chunks: List[Document], versions: List[str]
    ) -> List[Document]:
        """Helper function to update chunk numbers based on version ranking."""
        version2index = versions_to_rank(versions)
        for chunk in chunks:
            chunk.metadata["chunk_number"] = version2index[
                chunk.metadata["chunk_number"]
            ]
            chunk.metadata["is_chunked"] = 1
        return chunks

    # def _append_chunks_to_json(self, chunks: List[Document], file_name: str):
    #     """Append chunks to an existing JSON file or create it if it doesn't exist."""
    #     if not chunks:
    #         return

    #     # Chemin du fichier final
    #     if (self.config.paths.root / self.transform_output).is_dir():
    #         json_path = self.config.paths.root / self.transform_output / file_name
    #     else:
    #         json_path = self.config.paths.root / (file_name or self.transform_output)

    #     all_chunks = [chunk.dict() for chunk in chunks]

    #     if json_path.exists():
    #         with open(json_path, "r") as f:
    #             existing_data = json.load(f)
    #         existing_data.extend(all_chunks)
    #         with open(json_path, "w") as f:
    #             json.dump(existing_data, f, indent=4)
    #     else:
    #         with open(json_path, "w") as f:
    #             json.dump(all_chunks, f, indent=4)

    def save_chunks_as_json(
        self,
        chunks: List[Document],
        chunking_strategy: ChunkingStrategy,
        file_name: Optional[str] = None,
    ):
        """Save chunks to a JSON file."""
        if not chunks:
            warnings.warn("No chunks to save.")
            logger.warning("No chunks to save.")
            return

        all_chunks = [chunk.dict() for chunk in chunks]
        all_good_chunks = []
        all_bad_chunks = []
        for chunks_dict in all_chunks:
            # keeping a 100 tokens window
            if (
                chunks_dict["metadata"]["num_tokens"]
                > chunking_strategy.args.get("max_chunk_size") + 100
            ):
                all_bad_chunks.append(chunks_dict)
            else:
                all_good_chunks.append(chunks_dict)

        if os.path.isdir(f"{self.config.paths.root}/{self.transform_output}"):
            json_path = f"{self.config.paths.root}/{self.transform_output}/{file_name}"
        else:
            json_path = (
                f"{self.config.paths.root}/{(file_name or self.transform_output)}"
            )

        if os.path.exists(json_path):
            logger.warning(
                f"File '{json_path}' already exists and will be overwritten."
            )

        try:
            with open(json_path, "w") as f:
                json.dump(all_good_chunks, f, indent=4)
            logger.info(
                f"{len(all_good_chunks)} chunks successfully saved to '{json_path}'"
            )

            # Temporary
            if all_bad_chunks != []:
                with open(
                    os.path.join(
                        self.config.paths.root,
                        f"bad_{self.transform_output}",
                        file_name,
                    ),
                    "w",
                ) as f:
                    json.dump(all_bad_chunks, f, indent=4)
                logger.info(
                    f"""{len(all_bad_chunks)} chunks successfully saved to '{os.path.join(self.config.paths.root, f"bad_{self.transform_output}", file_name)}'"""
                )

        except Exception as e:
            logger.error(f"Error saving chunks to '{json_path}': {e}")
            raise

    def generate_hash(self, filehash, chunk_content):
        # combine filehash + chunk content (so even same chunk content in diff file has diff hash)
        data = (str(filehash) + str(chunk_content)).encode("utf-8")
        return hashlib.sha256(data).hexdigest()

    def _create_and_save_chunks_as_sqlite_db(
        self,
        chunks: List[Document],
        chunking_strategy: ChunkingStrategy,
        table_name: Optional[str],
        extract_table_name,
        con,
        cur,
        table_exists,
        path_key,
    ):

        if not table_exists:
            """Create sqlite table for transform if not exists"""
            cur.execute(
                f"""
            CREATE TABLE IF NOT EXISTS "{table_name}"(
            chunk_hash TEXT PRIMARY KEY,
            file_hash TEXT NOT NULL,
            id TEXT,
            windowsfullpath TEXT NOT NULL DEFAULT "",
            unixfullpath TEXT NOT NULL DEFAULT "",
            file_path TEXT,
            lastmodifieddate TEXT,
            file_extension TEXT,
            start_line INTEGER,
            end_line INTEGER,
            num_tokens INTEGER,
            chunk_number INTEGER,
            type TEXT,
            page_content TEXT,
            is_chunked INTEGER DEFAULT 0,
            FOREIGN KEY (file_hash) REFERENCES "{extract_table_name}"(file_hash) ON DELETE CASCADE ON UPDATE CASCADE,
            FOREIGN KEY (windowsfullpath) REFERENCES "{extract_table_name}"(windowsfullpath) ON UPDATE CASCADE,
            FOREIGN KEY (unixfullpath) REFERENCES "{extract_table_name}"(unixfullpath) ON UPDATE CASCADE,
            FOREIGN KEY (file_path) REFERENCES "{extract_table_name}"(file_path) ON UPDATE CASCADE
            )
            """
            )

        if not chunks:
            warnings.warn("No chunks to save.")
            logger.warning("No chunks to save.")
            return

        all_chunks = [chunk.dict() for chunk in chunks]
        all_good_chunks = []
        all_bad_chunks = []
        for chunks_dict in all_chunks:
            # keeping a 100 tokens window
            if (
                chunks_dict["metadata"]["num_tokens"]
                > chunking_strategy.args.get("max_chunk_size") + 100
            ):
                all_bad_chunks.append(chunks_dict)
            else:
                all_good_chunks.append(chunks_dict)

        try:
            logger.info(
                f"{len(all_good_chunks)} chunks successfully saved to sqlite db's table:'{table_name}'"
            )
            for chunk in all_good_chunks:
                chunk_hash = self.generate_hash(
                    str(chunk["metadata"]["file_hash"]), chunk["page_content"]
                )
                # instering chunks into the table
                cur.execute(
                    f"""
                    INSERT OR IGNORE INTO  "{table_name}"
                    (chunk_hash, file_hash, id, {path_key}, file_path, lastmodifieddate, file_extension, start_line, end_line, num_tokens, chunk_number, type, page_content, is_chunked)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                    (
                        chunk_hash,
                        chunk["metadata"]["file_hash"],
                        chunk["id"],
                        chunk["metadata"][path_key],
                        chunk["metadata"]["file_path"],
                        chunk["metadata"]["lastmodifieddate"],
                        chunk["metadata"]["file_extension"],
                        chunk["metadata"]["start_line"],
                        chunk["metadata"]["end_line"],
                        chunk["metadata"]["num_tokens"],
                        chunk["metadata"]["chunk_number"],
                        chunk["type"],
                        chunk["page_content"],
                        1,
                    ),
                )

                # Update corresponding row in extract table
                cur.execute(
                    f"""
                    UPDATE "{extract_table_name}"
                    SET is_chunked = 1
                    WHERE file_hash = ?
                """,
                    (chunk["metadata"]["file_hash"],),
                )

                con.commit()
        except Exception as e:
            logger.error(f"Error saving chunks to sqlite db table'{table_name}': {e}")
            raise

    @Observability("transform")
    def run_pipeline(
        self, workspace_path, modified_filepaths, workspace_version
    ) -> "Transformer":
        """
        Orchestrate full transformation pipeline.
        """
        logger.info(f"Starting Transform Pipeline.....")
        return self.chunk_content_and_save(
            workspace_path, modified_filepaths, workspace_version
        )
