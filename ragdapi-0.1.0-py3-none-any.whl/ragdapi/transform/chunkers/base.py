from abc import ABC, abstractmethod
from langchain_core.documents import Document
from transformers import AutoTokenizer, PreTrainedTokenizerBase, PreTrainedTokenizer
from ragdapi.transform.remote_tokenizer import RemoteHFTokenizer
from typing import Any, Dict, Union, Callable, Literal, List, Optional
import warnings


class ChunkerBase(ABC):
    """Interface for splitting content into chunks."""

    def __init__(
        self,
        max_chunk_size: int = 512,
        chunk_overlap: int = 0,
        length_function: Callable[[str], int] = len,
        keep_separator: Union[bool, Literal["start", "end"]] = False,
        add_start_index: bool = False,
        strip_whitespace: bool = True,
        tokenizer_name: Optional[str] = None,
        tokenizer_cache_dir: Optional[str] = None,
        tokenizer: Optional[Union[PreTrainedTokenizerBase, PreTrainedTokenizer]] = None,
        tokenizer_remote_url: Optional[str] = None,
    ):
        """
        Initialize a Chunker with optional tokenizer support.

        :param max_chunk_size: Maximum size of chunks to return. Defaults to 512.
        :param chunk_overlap: Overlap in characters/tokens between chunks. Must be smaller than `max_chunk_size`.
                              Defaults to 0.
        :param length_function: Function that measures the length of given chunks.
                                This will be overridden if a tokenizer is provided. Defaults to `len`.
        :param keep_separator: Whether to keep the separator and where to place it in each chunk.
                               If `True`, the separator is placed at the start. Can also be "start" or "end".
                               Defaults to `False`.
        :param add_start_index: If `True`, includes the chunk's start index in the metadata. Defaults to `False`.
        :param strip_whitespace: If `True`, strips whitespace from the start and end of every chunk. Defaults to `True`.
        :param tokenizer_name: Name of the tokenizer model to use.
                               Either `tokenizer_name` or `tokenizer` must be provided, but not both.
        :param tokenizer_cache_dir: Directory to cache the tokenizer.
                                    This should only be provided if `tokenizer_name` is given.
        :param tokenizer: An instance of a pre-trained tokenizer.
                          Either `tokenizer` or `tokenizer_name` must be provided, but not both.

        :raises ValueError: If `chunk_overlap` is greater than `max_chunk_size`.
        :raises ValueError: If both `tokenizer_name` and `tokenizer` are provided.
        :raises ValueError: If `tokenizer_cache_dir` is provided without `tokenizer_name`.
        :raises TypeError: If `tokenizer` is provided but is not an instance of `PreTrainedTokenizerBase`.
        """
        if chunk_overlap > max_chunk_size:
            raise ValueError(
                f"Got a larger chunk overlap ({chunk_overlap}) than chunk size "
                f"({max_chunk_size}), should be smaller."
            )

        if tokenizer_name and tokenizer:
            raise ValueError(
                "Provide either `tokenizer_name` or `tokenizer`, not both."
            )

        if tokenizer_cache_dir and not tokenizer_name:
            raise ValueError(
                "`tokenizer_cache_dir` can only be used when `tokenizer_name` is provided."
            )

        self.max_chunk_size = max_chunk_size
        self.chunk_overlap = chunk_overlap
        self.length_function = length_function
        self.keep_separator = keep_separator
        self.add_start_index = add_start_index
        self.strip_whitespace = strip_whitespace

        if tokenizer_name:
            if tokenizer_remote_url:
                self.tokenizer = RemoteHFTokenizer(tokenizer_remote_url, tokenizer_name)
            else:
                self.tokenizer = AutoTokenizer.from_pretrained(
                    tokenizer_name, cache_dir=tokenizer_cache_dir, local_files_only=True
                )
        else:
            # if not isinstance(tokenizer, PreTrainedTokenizerBase):
            #     raise TypeError(
            #         "`tokenizer` must be an instance of `PreTrainedTokenizerBase`."
            #     )
            self.tokenizer = tokenizer

        if self.tokenizer:
            if self.length_function != len:
                warnings.warn(
                    "The provided `length_function` is overridden by the tokenizer's token count method."
                )
            # changed this from a lambda function to a named function to make it pickle-friendly and allow multiprocessing
            self.length_function = self._token_length_function

    def _token_length_function(self, text: str) -> int:
        return len(self.tokenizer.tokenize(text))

    @classmethod
    def from_huggingface_tokenizer(
        cls, tokenizer: PreTrainedTokenizerBase, **kwargs: Any
    ) -> "ChunkerBase":
        """
        Create a ChunkerBase instance from a HuggingFace tokenizer.

        :param tokenizer: A pre-trained tokenizer instance.
        :param kwargs: Additional arguments to pass to the ChunkerBase initializer.

        :raises ValueError: If `tokenizer` is passed in `kwargs`.
        """
        if "tokenizer" in kwargs:
            raise ValueError(
                "Do not pass `tokenizer` in `kwargs`. Provide it as a separate argument."
            )
        return cls(tokenizer=tokenizer, **kwargs)

    @abstractmethod
    def chunk_text(self, text: str, **kwargs: Dict[str, Any]) -> List[Document]:
        """Split text into multiple components."""
        pass
