import os
import sys
from os import path
import subprocess
from typing import Any, Callable, Dict, List, Optional, Union
from langchain_core.documents.base import Document
import pandas as pd
from transformers import PreTrainedTokenizerFast
from tree_sitter import Language, Parser, Node
import logging
from ragdapi.transform.chunkers.base import ChunkerBase
from ragdapi.transform.chunkers.text import TokenLineChunker
from ragdapi.transform.chunkers.utils import ast_parsers_nodes as astcst
from transformers import AutoTokenizer
import filetype

from ragdapi.transform.repo_map_builder import RepoMapBuilder

# using langchain splitters
from langchain_text_splitters import (
    Language,
    RecursiveCharacterTextSplitter,
)

# using pycapsule
from tree_sitter_language_pack import get_binding, get_language, get_parser
import re


class RecursiveSeparatorCodeChunker(ChunkerBase):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def chunk_text(self, text: str) -> List[Document]:
        """
        In this method the chunking will be performed using LangChain
        """
        code_splitter = RecursiveCharacterTextSplitter.from_language(
            language=Language.language, chunk_size=518, chunk_overlap=0
        )
        code_docs = code_splitter.create_documents([text])

        return code_docs


class ASTCodeChunker(ChunkerBase):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def chunk_text(self, text: str, **kwargs: Dict[str, Any]) -> List[Document]:
        # TODO: Implement the chunking logic for AST code
        pass


class ASTCollapsingCodeChunker(ChunkerBase):
    def __init__(
        self,
        tokenizer: Optional[PreTrainedTokenizerFast] = None,
        tokenizer_name: Optional[str] = None,
        tokenizer_cache_dir: Optional[str] = None,
        map_lang_extensions: Optional[Dict[str, List[str]]] = None,
        repo_map_builder: Optional[RepoMapBuilder] = None,
        **kwargs,
    ) -> None:
        """
        Initialize ASTCollapsingCodeChunker with a tokenizer or tokenizer name.
        :param tokenizer: An instance of a pre-trained tokenizer.
        :param tokenizer_name: Name of the tokenizer model to use.
        :param tokenizer_cache_dir: Directory to cache the tokenizer.
        :param map_lang_extensions: A dictionary mapping language names to their file extensions.
        :param max_chunk_size: The maximum number of tokens in a chunk.
        :param chunk_overlap: The number of tokens to overlap between chunks. (not implemented yet)
        :param kwargs: Additional arguments to pass to the base
        """
        super().__init__(
            tokenizer=tokenizer,
            tokenizer_name=tokenizer_name,
            tokenizer_cache_dir=tokenizer_cache_dir,
            **kwargs,
        )
        self.map_lang_extensions = map_lang_extensions or astcst.MAP_LANG_EXTENSIONS
        self.repo_map_builder = None
        self.parsers = {}

    def chunk_text(self, text: str, chunks, **kwargs: Dict[str, Any]) -> List[Document]:
        """
        Chunk the text into smaller pieces based on the AST of the code.

        :param text: The code snippet to chunk.
        :param extension: The file extension of the code snippet.
        """
        extension = kwargs.get("extension", None)
        filepath = kwargs.get("filepath", "unknown")
        if not extension:
            raise ValueError("The file extension is required to chunk the code.")
        extension = str(extension).lower()
        parser, language = self._get_parser_for_extension(extension)
        if parser is None:
            logging.warning("PARSER NOT FOUND!!!")
            logging.info(f"Using TokenLineChunker")
            print(f"THE EXTENSION WAS {extension}")
            line_chunker = TokenLineChunker(
                tokenizer=self.tokenizer,
                max_chunk_size=self.max_chunk_size,
                chunk_overlap=self.chunk_overlap,
            )
            chunk = line_chunker.chunk_text(text)
            logging.info(
                f"The code file {kwargs.get('filepath', None)} is chunked to : {len(chunk)} chunks"
            )
            return chunk

        tree = parser.parse(bytes(text, "utf8"))


        """
        Getting the Repo Map for the whole tree(code-file) at once
        """
        # Collect repo map entry (one line addition)
        if self.repo_map_builder is not None:
            self.repo_map_builder.collect_from_tree(tree.root_node, text, filepath)

        import_chunk = self._extract_imports(tree.root_node, text)
        chunk = []
        # try:
        code_len = self.length_function(tree.root_node.text.decode("utf-8"))
        # if code_len <= 8000:
        chunk = self._get_smart_collapsed_chunks(
            tree.root_node, text, import_chunk, chunks, language
        )
        if len(chunks) == 0:
            # logging.info(f"The code file with the content:\n")
            # logging.info(f"{tree.root_node.text.decode('utf-8')[:200]}\n was not chunked")
            logging.warning(
                f"AST FAILED TO CHUNK THE FILE PATH {kwargs.get('filepath', None)} WITH EXT {extension}"
            )
            logging.info(f"Probable reason - No class or methods")
            logging.info(f"Using TokenLineChunker")
            line_chunker = TokenLineChunker(
                tokenizer=self.tokenizer,
                max_chunk_size=self.max_chunk_size,
                chunk_overlap=self.chunk_overlap,
            )
            chunk = line_chunker.chunk_text(text)
            logging.info(
                f"The code file {kwargs.get('filepath', None)} is chunked to : {len(chunk)} chunks"
            )
        else:
            logging.info(
                f"The code file {kwargs.get('filepath', None)} is chunked to : {len(chunk)} chunks"
            )
        return chunk
        # else:
        #     return []

        # except Exception as e:
        #     logging.warning("The code exceeded the limit")

        # return chunk

    def _get_parser_for_extension(self, extension: str) -> Parser:
        """
        Get the parser for the given file extension.

        :param extension: The file extension.
        """
        language_name = ""
        if extension not in self.parsers:
            logging.info(f"Loading parser for extension: {extension}")
            for language, extensions in astcst.MAP_LANG_EXTENSIONS.items():
                if extension in extensions:
                    language_name = language
                    self.parsers[extension] = self._load_language(
                        extension, language_name
                    )
                    return self.parsers[extension], language_name
            print(f"NOT ABLE TO FIND A PARSER FOR {extension}.")
            return None, None
        else:
            for language, extensions in astcst.MAP_LANG_EXTENSIONS.items():
                if extension in extensions:
                    language_name = language
            return self.parsers[extension], language_name

    # TODO: Generalize the load_language to other languages repo of tree sitters
    # TODO: Need to try: tree sitter language pack
    def _load_language(self, extension, language_name: str):
        """
        Load the language parser for the given file language.

        :param extension: The file extension.
        :param language_name: The coding language
        """

        code_binding = get_binding(
            language_name
        )  # this is a pycapsule object pointing to the C binding
        code_lang = get_language(
            language_name
        )  # this is an instance of tree_sitter.Language
        code_parser = get_parser(
            language_name
        )  # this is an instance of tree_sitter.Parser

        # CODE_LANGUAGE = Language(java_language.language())
        # parser = Parser(CODE_LANGUAGE)
        return code_parser

    # TODO: Refactorize the token_counter
    def _get_smart_collapsed_chunks(
        self, node, code, import_chunk, chunks, language, root=True
    ) -> List[Document]:
        """
        Get the smart collapsed chunks based on the AST of the code.

        :param node: The node of the AST.
        :param code: The code snippet.
        :param root: A boolean indicating if the node is the root node.
        """
        chunk_number = 0
        chunks = []
        node_text = node.text.decode("utf-8")
        import_list = import_chunk["imported_libs"]

        # If the node is a root node (all the content), check if it can be a single chunk
        if root and self.length_function(node_text) < self.max_chunk_size:
            chunks.append(
                Document(
                    page_content=node.text.decode("utf-8"),
                    metadata={
                        "start_line": node.start_point[0],
                        "end_line": node.end_point[0],
                        "num_tokens": self.length_function(node.text.decode("utf-8")),
                        "chunk_number": chunk_number,
                    },
                )
            )
            logging.info(f"Entire chunk: {chunks[0].metadata}")
            return chunks

        # If the node is a class and exceed the max chunk size, extract the class signature with all the children method signatures of this class into one chunk
        import_dict = {}
        if node.type in astcst.CLASS_NODE_TYPES:
            print("Welcome to class node")
            # this will give me the class header
            class_definitions = self._construct_class_definition_chunk(node, code)
            class_chunk = self._construct_class_chunk(node, code)
            # logging.info(f"Getting class chunks: {class_chunk['content']}")
            class_declaration_list = self._get_field_declarations(
                node, node.text.decode("utf-8")
            )["declarations lib"]
            for chunk_index, chunk in enumerate(class_chunk):
                # extracting all the imports used in that class
                class_definition = class_definitions[chunk_index]
                # print(f"The Class Definition looks like : {class_definition}")
                chunk_specific_imports = ""
                chunk_specific_declarations = ""
                lines = chunk["content"].splitlines()

                for line in lines:
                    # removing extra spaces is distrubing the indentation
                    # clean_line = line.strip()  # Remove leading and trailing spaces
                    clean_line = line
                    if not clean_line:  # Skip empty lines
                        continue
                    # logging.info(f"Checking for imports that are present in the given class chunk")
                    if import_list != {}:
                        for libs in import_list:
                            # print(libs['lib_name'])
                            if libs["lib_name"] in line:
                                if import_dict.get(libs["import_statement"]) is None:
                                    import_dict[libs["import_statement"]] = 1
                                    # if libs['start_line'] != libs['end_line']:
                                    #     chunk_specific_imports= '\n'.join(code[libs['start_line']: libs['end_line']+1])
                                    # else:
                                    #     chunk_specific_imports = code[libs['start_line']: ]
                                    chunk_specific_imports += (
                                        libs["import_statement"] + "\n"
                                    )
                                else:
                                    import_dict[libs["import_statement"]] += 1

                # The whole class will be treated as chunk as a whole

                if (
                    self.length_function(chunk["content"])
                    + self.length_function(chunk_specific_imports)
                    <= self.max_chunk_size
                ):
                    logging.info("The whole class is chunked at once")
                    chunks.append(
                        Document(
                            page_content=chunk_specific_imports
                            + "\n"
                            + chunk["content"],
                            metadata={
                                "start_line": chunk["start_line"],
                                "end_line": chunk["end_line"],
                                "num_tokens": self.length_function(
                                    chunk_specific_imports + "\n" + chunk["content"]
                                ),
                                "chunk_number": chunk_number,
                            },
                        )
                    )
                    chunk_number += 1

                # splitting chunk based on the functions
                else:
                    for sub_child in node.children:
                        if (
                            sub_child.type in astcst.CLASS_BODY
                            and node.type in astcst.CLASS_NODE_TYPES
                        ):
                            print("Inside of class body (block)")
                            method_code = ""
                            import_set = ""
                            for child in sub_child.children:
                                if child.type in astcst.FUNCTION_NODE_TYPES:
                                    method_chunk = child.text.decode("utf-8")
                                    logging.info(
                                        f"Checking for imports that are present in the given method chunk"
                                    )
                                    method_lines = method_chunk.splitlines()
                                    chunk_specific_imports = ""
                                    chunk_specific_declarations = ""
                                    import_dict = {}
                                    declarations_dict = {}
                                    for line in method_lines:
                                        if import_list != {}:
                                            for libs in import_list:
                                                if libs["lib_name"] in line:
                                                    # chunk_specific_imports= '\n'.join(code[libs['start_line']: libs['end_line']])
                                                    if (
                                                        import_dict.get(
                                                            libs["import_statement"]
                                                        )
                                                        is None
                                                    ):
                                                        chunk_specific_imports += (
                                                            libs["import_statement"]
                                                            + "\n"
                                                        )
                                                        import_dict[
                                                            libs["import_statement"]
                                                        ] = 1
                                                    else:
                                                        import_dict[
                                                            libs["import_statement"]
                                                        ] += 1

                                        if class_declaration_list != []:
                                            for vars in class_declaration_list:
                                                if vars["variable_names"] in line:
                                                    if (
                                                        declarations_dict.get(
                                                            vars["declaration_code"]
                                                        )
                                                        is None
                                                    ):
                                                        chunk_specific_declarations += (
                                                            vars["declaration_code"]
                                                            + "\n"
                                                        )
                                                        declarations_dict[
                                                            vars["declaration_code"]
                                                        ] = 1
                                                    else:
                                                        declarations_dict[
                                                            vars["declaration_code"]
                                                        ] += 1

                                    # logging.info(f"\n The related imports are: {chunk_specific_imports}")

                                    # print(F"The imports present in the method chunks are: {chunk_specific_imports}")
                                    if (
                                        self.length_function(
                                            class_definition["content"]
                                        )
                                        + self.length_function("...\n")
                                        + self.length_function(method_chunk)
                                        + self.length_function(chunk_specific_imports)
                                        + self.length_function(
                                            chunk_specific_declarations
                                        )
                                        > self.max_chunk_size
                                    ):
                                        print("Performong splitting of the functions")
                                        print(
                                            f"The length of the method is {self.length_function(method_chunk)}"
                                        )
                                        print(
                                            self.length_function(
                                                class_definition["content"]
                                            )
                                            + self.length_function("...\n")
                                            + self.length_function(method_chunk)
                                            + self.length_function(
                                                chunk_specific_imports
                                            )
                                            + self.length_function(
                                                chunk_specific_declarations
                                            )
                                        )
                                        print(
                                            self.length_function(
                                                class_definition["content"]
                                            ),
                                            self.length_function("...\n"),
                                            self.length_function(method_chunk),
                                            self.length_function(
                                                chunk_specific_imports
                                            ),
                                            self.length_function(
                                                chunk_specific_declarations
                                            ),
                                        )

                                        method_chunks = self._split_function_or_method(
                                            child,
                                            code,
                                            class_definition["content"],
                                            import_chunk,
                                            class_declaration_list,
                                            language,
                                            chunk_specific_imports,
                                        )
                                        # method_code = class_definition
                                        for chunk in method_chunks:
                                            # if self.length_function(method_code) > self.max_chunk_size:
                                            # remove the last fucntion and make the chunk
                                            # method_code = method_code - chunk['content']
                                            chunks.append(
                                                Document(
                                                    # PROBLEMO
                                                    page_content=chunk["content"],
                                                    metadata={
                                                        "start_line": chunk[
                                                            "start_line"
                                                        ],
                                                        "end_line": chunk["end_line"],
                                                        "num_tokens": chunk[
                                                            "num_tokens"
                                                        ],
                                                        "chunk_number": chunk_number,
                                                    },
                                                )
                                            )
                                            chunk_number += 1
                                            # print(f"Chunk looks like : {chunks}")
                                            # flag = -1
                                            # else:
                                            # method_code += '...\n' + chunk['content']

                                    else:
                                        logging.info(
                                            f"Whole function is treated as chunk"
                                        )
                                        # print(class_definition['content'], type(class_definition['content']))
                                        # print("Hehe")
                                        # print(child.text, type(child.text.decode("utf-8")))

                                        print("Keep appending the whole methods")
                                        import_set += chunk_specific_imports
                                        method_code += method_chunk + "\n"
                                        if (
                                            self.length_function(import_set)
                                            + self.length_function(method_code)
                                            + self.length_function(
                                                class_definition["content"]
                                            )
                                            + self.length_function("...\n")
                                            + self.length_function(
                                                chunk_specific_declarations
                                            )
                                            >= self.max_chunk_size
                                        ):
                                            method_code = method_code.replace(
                                                child.text.decode("utf-8"), ""
                                            )
                                            import_set = import_set.replace(
                                                chunk_specific_imports, ""
                                            )
                                            chunks.append(
                                                Document(
                                                    page_content=import_set
                                                    + "\n\n"
                                                    + class_definition["content"]
                                                    + "...\n"
                                                    + chunk_specific_declarations
                                                    + method_code,  # child.text.decode("utf-8"),
                                                    metadata={
                                                        "start_line": child.start_point[
                                                            0
                                                        ],
                                                        "end_line": child.end_point[0],
                                                        "num_tokens": self.length_function(
                                                            import_set
                                                            + "\n\n"
                                                            + class_definition[
                                                                "content"
                                                            ]
                                                            + "...\n"
                                                            + method_code
                                                        ),
                                                        "chunk_number": chunk_number,
                                                    },
                                                )
                                            )
                                            logging.info(
                                                f"Entire function chunk: {chunks[0].metadata}"
                                            )
                                            chunk_number += 1
                                            method_code = child.text.decode("utf-8")
                                            import_set = chunk_specific_imports
                                        # else:
                                        #     print("Keep appending the whole methods")
                                        #     import_set += chunk_specific_imports
                                        #     method_code += method_chunk

                            # making a seperate chunk for left over methods/functions
                            if method_code != "":
                                print("The left over method was treated as a chunk")
                                chunks.append(
                                    Document(
                                        page_content=import_set
                                        + "\n\n"
                                        + class_definition["content"]
                                        + "...\n"
                                        + method_code,  # child.text.decode("utf-8"),
                                        metadata={
                                            "start_line": child.start_point[0],
                                            "end_line": child.end_point[0],
                                            "num_tokens": self.length_function(
                                                import_set
                                                + "\n\n"
                                                + class_definition["content"]
                                                + "...\n"
                                                + method_code
                                            ),
                                            "chunk_number": chunk_number,
                                        },
                                    )
                                )
                                logging.info(
                                    f"Entire function chunk: {chunks[0].metadata}"
                                )
                                chunk_number += 1
                                method_code = ""
                                import_set = ""

        # If there is no class node in the code
        # If the node is a function and exceed the max chunk size, split it into smaller chunks with ellipsis to indicate continuation
        # import_list = import_chunk['imported_libs']
        # print(f"The import lis debug: {import_list}") DELETE
        elif (
            node.type in astcst.FUNCTION_NODE_TYPES
        ):  # and node.type not in astcst.CLASS_NODE_TYPES:
            class_definition = ""
            method_chunk = node.text.decode("utf-8")
            logging.info(
                f"Checking for imports that are present in the given method chunk"
            )
            method_lines = method_chunk.splitlines()
            chunk_specific_imports = ""
            chunk_specific_declarations = ""
            import_dict = {}
            for line in method_lines:
                if import_list != {}:
                    for libs in import_list:
                        if libs["lib_name"] in line:
                            # chunk_specific_imports= '\n'.join(code[libs['start_line']: libs['end_line']])
                            if import_dict.get(libs["import_statement"]) is None:
                                chunk_specific_imports += (
                                    libs["import_statement"] + "\n"
                                )
                                import_dict[libs["import_statement"]] = 1
                            else:
                                import_dict[libs["import_statement"]] += 1

            if (
                self.length_function(method_chunk)
                + self.length_function(chunk_specific_imports)
                + self.length_function("\n...\n")
                > self.max_chunk_size
            ):
                method_chunks = self._split_function_or_method(
                    node,
                    code,
                    class_definition,
                    import_chunk,
                    [],
                    language,
                    chunk_specific_imports,
                )
                logging.info(f"Getting method chunks: {method_chunks}")
                for chunk in method_chunks:
                    chunks.append(
                        Document(
                            page_content=chunk["content"],
                            metadata={
                                "start_line": chunk["start_line"],
                                "end_line": chunk["end_line"],
                                "num_tokens": chunk["num_tokens"],
                                "chunk_number": chunk_number,
                            },
                        )
                    )
                    chunk_number += 1

            else:
                # The whole function will be treated as chunk as a whole
                if self.length_function(chunk_specific_imports) != 0:
                    content = chunk_specific_imports + "\n...\n" + method_chunk
                else:
                    content = method_chunk

                chunks.append(
                    Document(
                        page_content=content,
                        metadata={
                            "start_line": node.start_point[0],
                            "end_line": node.end_point[0],
                            "num_tokens": self.length_function(content),
                            "chunk_number": chunk_number,
                        },
                    )
                )
                chunk_number += 1

        # If the node has children, recursively apply the same strategy to the children
        # if node.type not in astcst.CLASS_NODE_TYPES:
        if node.children:
            for child in node.children:
                if (
                    child.type in astcst.CLASS_NODE_TYPES
                    or child.type in astcst.FUNCTION_NODE_TYPES
                ):
                    # this if will prevent the child of class node ot be chunked again.
                    if node.type not in astcst.CLASS_NODE_TYPES:
                        print(f"We are into node type: {child.type}")
                        child_chunks = self._get_smart_collapsed_chunks(
                            child, code, import_chunk, chunks, language, root=False
                        )
                        for child_chunk in child_chunks:
                            child_chunk.metadata["chunk_number"] = chunk_number
                            chunks.append(child_chunk)
                            chunk_number += 1
                else:
                    continue

        # # making a seperate chunk for left over methods/functions
        # if method_code != '':
        #     chunks.append(
        #         Document(
        #             page_content=import_set + '\n\n' + class_definition['content'] + "...\n" +  method_code, #child.text.decode("utf-8"),
        #             metadata={
        #                 "start_line": child.start_point[0],
        #                 "end_line": child.end_point[0],
        #                 "num_tokens": self.length_function(import_set + '\n\n' + class_definition['content'] + "...\n" +  method_code),
        #                 "chunk_number": chunk_number,
        #             },
        #         )
        #     )
        #     logging.info(f"Entire function chunk: {chunks[0].metadata}")
        #     chunk_number += 1
        #     method_code = ''
        #     import_set = ''

        return chunks

    def _extract_imports(self, node, code) -> Dict[str, any]:
        """
        Extract all the imports of code based on the types of predefined nodes.

        :param node: The node of the AST.
        :param code: The code snippet.
        """
        content = []
        start_line = node.start_point[0]
        end_line = node.end_point[0]
        import_path = []
        import_lib = []
        # TODO: This logic has to be language agnostic (Java Specific as of now)
        for child in node.children:
            if child.type in astcst.IMPORT_NODE_TYPES:
                snippet = code[child.start_byte : child.end_byte]
                # print(f"The import code snippet is : {snippet}")
                content.append(snippet)
                end_line = child.end_point[0]
                for subchild in child.children:
                    if subchild.type in astcst.IMPORT_PATH:
                        import_path.append(
                            code[subchild.start_byte : subchild.end_byte]
                        )
                    for import_subchild in subchild.children:
                        if import_subchild.type in astcst.IMPORT_NAME:
                            lib_name = code[
                                import_subchild.start_byte : import_subchild.end_byte
                            ]
                            lib_start = re.findall('^"', lib_name)
                            lib_end = re.findall('"$', lib_name)
                            if lib_start and lib_end:
                                lib_name = lib_name.replace('"', "")
                            print(f"The lib name is : {lib_name}")
                            import_lib.append(
                                {
                                    "lib_name": lib_name,
                                    "import_statement": snippet,
                                    "start_line": import_subchild.start_point[0],
                                    "end_line": import_subchild.end_point[0],
                                }
                            )

        return {"imported_libs": import_lib}

    # get the local variables
    def _get_local_variables(self, node, code):
        """
        Extract all the local variables inside of the function node.

        :param node: The node of the AST.
        :param code: The code snippet.
        """

    # for me: this has to be called inside of class node
    # get field delarations inside of a class
    def _get_field_declarations(self, node, code):
        # this node is a class node
        declaration_lib = []
        codelines = code.splitlines()
        for sub_root_node in node.children:
            if sub_root_node.type in astcst.CLASS_BODY:
                for child in sub_root_node.children:
                    if child.type in astcst.CLASS_VARIABLES_DECLARATIONS:
                        for sub_child in child.children:
                            if sub_child.type in astcst.CLASS_VARIABLE_NAMES:
                                for leaf_node in sub_child.children:
                                    if leaf_node.type == "identifier":
                                        declaration_lib.append(
                                            {
                                                "variable_names": leaf_node.text.decode(
                                                    "utf-8"
                                                ),
                                                "declaration_code": child.text.decode(
                                                    "utf-8"
                                                ),
                                            }
                                        )
        return {"declarations lib": declaration_lib}

    def _get_langchain_language(self, language_str: str) -> Language:
        """
        Check if or not the programming language is supported by Langchain splitter

        Returns:
            Bool Value
        """

        # Convert language string to Language enum
        lang_map = {
            "python": Language.PYTHON,
            "java": Language.JAVA,
            "cpp": Language.CPP,
            "c++": Language.CPP,
            "c": Language.CPP,  # fallback, since no separate Language.C
            "go": Language.GO,
            "js": Language.JS,
            "javascript": Language.JS,
            "ts": Language.TS,
            "typescript": Language.TS,
            "csharp": Language.CSHARP,
            "c#": Language.CSHARP,
            "php": Language.PHP,
            "rust": Language.RUST,
            "sol": Language.SOL,
            "solidity": Language.SOL,
            "scala": Language.SCALA,
        }

        language = lang_map.get(language_str.lower())
        if not language:
            return

        return language

    # chunk_overlap is mot 50 it wll be custom
    def chunk_code_with_langchain(
        self, code: str, language: Language, chunk_size: int, chunk_overlap: int = 50
    ):
        """
        Chunk code using LangChain's built-in code-aware splitter.

        Args:
            code (str): The code to split.
            language_str (str): Language as a string ('python', 'java', 'c++', etc.).
            chunk_size (int): Max chunk size.
            chunk_overlap (int): Chunk overlap size.

        Returns:
            List[str]: Chunked code snippets.
        """

        # language = self._get_langchain_language(language_str)
        # Use LangChain's code-aware splitter
        splitter = RecursiveCharacterTextSplitter.from_language(
            language=language,
            chunk_size=chunk_size,
            chunk_overlap=int(chunk_size * 0.07),
        )

        return splitter.split_text(code)

    def _compressing_declarations(self, declaration: "str", extra_tokens: "int") -> str:
        dummy = ""
        first = ""
        second = ""
        # keeping a window of 5 tokens so that chunk never exceesd the specified limit
        extra_tokens = extra_tokens + 5
        for chars in declaration:
            dummy += chars
            if self.length_function(dummy) >= int(
                (self.length_function(declaration) - int(extra_tokens)) / 2
            ):
                first = dummy
                dummy = ""
                break

        for chars in reversed(declaration):
            dummy += chars
            if self.length_function(dummy) >= int(
                (self.length_function(declaration) - int(extra_tokens)) / 2
            ):
                second = dummy
                dummy = ""
                break

        updated_declaration = first + "..." + second
        return updated_declaration

    def _split_function_or_method(
        self,
        node,
        code,
        class_definition,
        import_chunk,
        class_declaration_list,
        language,
        method_specific_imports,
    ) -> List[Dict[str, any]]:
        """
        Split a function or method into smaller chunks, adding ellipsis to indicate continuation.
        Example : chunk 1 : "def add(a, b): c= a + b\n..."
                  chunk 2 : "def add(a,b): ...\nreturn c

        :param node: the node
        :param code: the code snippet
        """
        # body_node = node.children[-1]  # Assume last child is the body
        # body_node = node.children if node.children in astcst.FUNCTION_BODY else None
        body_node = None
        for nodes in node.children:
            if nodes.type in astcst.FUNCTION_BODY:
                body_node = nodes

        if body_node is not None:
            signature = code[node.start_byte : body_node.start_byte].strip()
            logging.info(
                f"Splitting function or method: {signature} - Tokens: {self.length_function(signature)}"
            )
            body_text = code[body_node.start_byte : body_node.end_byte]
            mchunks = []
            # reference_chunk = '\n' + class_definition + '...\n' + signature
            # reference_tokens = self.length_function(reference_chunk)
            # current_chunk = reference_chunk
            # current_tokens = reference_tokens
            signature_token = self.length_function(signature)
            class_definition_token = self.length_function(class_definition)
            method_specific_import_tokens = self.length_function(
                method_specific_imports
            )

            current_chunk = ""
            current_tokens = 0
            start_line = node.start_point[0]
            curr_line = start_line
            lines = body_text.split("\n")
            first_chunk = True
            chunk_specific_imports = ""
            chunk_specific_declarations = ""
            import_dict = {}  # maintaining imports record
            import_list = import_chunk["imported_libs"]
            declaration_dict = {}
            updated_signature = ""
            updated_class_definition = ""
            # there must be a window for atleast 100 tokens for code logic to fit in
            #  keeping only 100 tokens for class_definiton + signature while compressiing
            # while signature_token + class_definition_token > self.max_chunk_size - 100:
            #     logging.info(f"Reducing the size of the signature and class definition for {language} code")
            #     logging.info(f"Reduced size of signature token is {signature_token}")
            #     logging.info(f"Reduced size of class definiton token is {class_definition_token}")
            #     # if conditions will prevent penalizing the declaration which is already small
            #     if signature_token > 50:
            #         signature = self._compressing_declarations(signature, int(signature_token/2))
            #         signature_token = self.length_function(signature)
            #     if class_definition_token > 50:
            #         class_definition = self._compressing_declarations(class_definition, int(class_definition_token/2))
            #         class_definition_token = self.length_function(class_definition)
            # Using LangChain Splitter is supported else using TokenLine Chunker
            if self._get_langchain_language(language.lower().strip()) is not None:
                # keeping 80 tokens serserved for chunk specific imports and class definition
                chunks = self.chunk_code_with_langchain(
                    body_text,
                    self._get_langchain_language(language.lower().strip()),
                    200,
                )
                logging.info(
                    f"Total {len(chunks)} chunks were returned by langchain splitter"
                )

                for ind, chunk in enumerate(chunks):

                    # checking if the code line has any imports used in corresponding code file
                    if import_list != {}:
                        for libs in import_list:
                            if libs["lib_name"] in chunk:
                                # if import_dict.get(code[libs['start_line']: libs['end_line']]) is None:
                                if import_dict.get(libs["import_statement"]) is None:
                                    # chunk_specific_imports= '\n'.join(code[libs['start_line']: libs['end_line']])
                                    chunk_specific_imports += (
                                        libs["import_statement"] + "\n"
                                    )
                                    # import_dict[code[libs['start_line']: libs['end_line']]] = 1
                                    import_dict[libs["import_statement"]] = 1
                                else:
                                    # import_dict[code[libs['start_line']: libs['end_line']]] += 1
                                    import_dict[libs["import_statement"]] += 1

                    if class_declaration_list != []:
                        for vars in class_declaration_list:
                            if vars["variable_names"] in chunk:
                                if (
                                    declaration_dict.get(vars["declaration_code"])
                                    is None
                                ):
                                    declaration_dict[vars["declaration_code"]] = 1
                                    chunk_specific_declarations += (
                                        vars["declaration_code"] + "\n"
                                    )
                                else:
                                    declaration_dict[vars["declaration_code"]] += 1

                    chunk_specific_imports_tokens = self.length_function(
                        chunk_specific_imports
                    )
                    chunk_specific_declarations_tokens = self.length_function(
                        chunk_specific_declarations
                    )
                    if class_definition_token != 0 and signature_token != 0:
                        content = (
                            chunk_specific_imports
                            + "\n"
                            + class_definition
                            + "\n"
                            + chunk_specific_declarations
                            + "\n...\n"
                            + signature
                            + "\n...\n"
                            + chunk
                        )
                    else:
                        # elif class_definition_token == 0 and signature_token == 0:
                        # content = chunk_specific_imports + '\n' + updated_chunk
                        # elif class_definition_token == 0 and signature_token != 0:
                        content = (
                            chunk_specific_imports
                            + "\n"
                            + signature
                            + "\n...\n"
                            + chunk
                        )
                    # elif class_definition_token != 0 and signature_token == 0:

                    if self.length_function(content) <= self.max_chunk_size:
                        mchunks.append(
                            {
                                "content": content,
                                "start_line": start_line,
                                "end_line": "N/A",
                                # "num_tokens": self.length_function(signature) + self.length_function(" ...") + middle + 1,
                                "num_tokens": self.length_function(content),
                            }
                        )
                    else:
                        # there must be a window for atleast 100 tokens for code logic to fit in
                        while (
                            signature_token
                            + class_definition_token
                            + chunk_specific_imports_tokens
                            + chunk_specific_declarations_tokens
                            > self.max_chunk_size - 200
                        ):
                            logging.info(
                                f"Reducing the size of the signature and class definition for {language} code"
                            )
                            logging.info(
                                f"Reduced size of signature token is {signature_token}"
                            )
                            logging.info(
                                f"Reduced size of class definiton token is {class_definition_token}"
                            )
                            # if conditions will prevent penalizing the declaration which is already small
                            if signature_token > 50:
                                signature = self._compressing_declarations(
                                    signature, int(signature_token / 2)
                                )
                                signature_token = self.length_function(signature)
                            if class_definition_token > 50:
                                class_definition = self._compressing_declarations(
                                    class_definition, int(class_definition_token / 2)
                                )
                                class_definition_token = self.length_function(
                                    class_definition
                                )
                            if chunk_specific_declarations_tokens > 50:
                                chunk_specific_declarations = (
                                    self._compressing_declarations(
                                        chunk_specific_declarations,
                                        int(chunk_specific_declarations_tokens / 2),
                                    )
                                )
                                chunk_specific_declarations_tokens = (
                                    self.length_function(chunk_specific_declarations)
                                )
                            if chunk_specific_imports_tokens > 50:
                                chunk_specific_imports = self._compressing_declarations(
                                    chunk_specific_imports,
                                    int(chunk_specific_imports_tokens / 2),
                                )
                                chunk_specific_imports_tokens = self.length_function(
                                    chunk_specific_imports
                                )

                        content = (
                            chunk_specific_imports
                            + "\n"
                            + class_definition
                            + "\n"
                            + chunk_specific_declarations
                            + "\n...\n"
                            + signature
                            + "\n...\n"
                            + chunk
                        )
                        mchunks.append(
                            {
                                "content": content,
                                "start_line": start_line,
                                "end_line": "N/A",
                                # "num_tokens": self.length_function(signature) + self.length_function(" ...") + middle + 1,
                                "num_tokens": self.length_function(content),
                            }
                        )

                logging.info("Chunks formed using lngachain")
                return mchunks

            # using the TokenLine Chunker with improvised logic
            else:
                for line in lines:
                    # clean_line = line.strip()  # Remove leading and trailing spaces
                    clean_line = line
                    if not clean_line:  # Skip empty lines
                        continue
                    line_tokens = self.length_function(clean_line)

                    # checking if the code line has any imports used in corresponding code file
                    if import_list != {}:
                        for libs in import_list:
                            if libs["lib_name"] in line:
                                if import_dict.get(libs["import_statement"]) is None:
                                    chunk_specific_imports += (
                                        libs["import_statement"] + "\n"
                                    )
                                    import_dict[libs["import_statement"]] = 1
                                else:
                                    import_dict[libs["import_statement"]] += 1
                    if class_declaration_list != []:
                        for vars in class_declaration_list:
                            if vars["variable_names"] in line:
                                if (
                                    declaration_dict.get(vars["declaration_code"])
                                    is None
                                ):
                                    declaration_dict[vars["declaration_code"]] = 1
                                    chunk_specific_declarations += (
                                        vars["declaration_code"] + "\n"
                                    )
                                else:
                                    declaration_dict[vars["declaration_code"]] += 1

                    current_chunk += clean_line + "\n"
                    current_tokens += self.length_function(clean_line)
                    import_tokens_len = self.length_function(chunk_specific_imports)
                    class_declarations_tokens_len = self.length_function(
                        chunk_specific_declarations
                    )
                    # signature token and class definition token maximum lnth will be around 400 tokens
                    while (
                        signature_token
                        + class_definition_token
                        + import_tokens_len
                        + class_declarations_tokens_len
                        > self.max_chunk_size - 100
                    ):
                        logging.info(
                            f"Reducing the size of the signature and class definition for {language} code"
                        )
                        logging.info(
                            f"Reduced size of signature token is {signature_token}"
                        )
                        logging.info(
                            f"Reduced size of class definiton token is {class_definition_token}"
                        )
                        # if conditions will prevent penalizing the declaration which is already small
                        if signature_token > 50:
                            signature = self._compressing_declarations(
                                signature, int(signature_token / 2)
                            )
                            signature_token = self.length_function(signature)

                        if class_definition_token > 50:
                            class_definition = self._compressing_declarations(
                                class_definition, int(class_definition_token / 2)
                            )
                            class_definition_token = self.length_function(
                                class_definition
                            )

                        if import_tokens_len > 50:
                            chunk_specific_imports = self._compressing_declarations(
                                chunk_specific_imports, int(import_tokens_len / 2)
                            )
                            import_tokens_len = self.length_function(
                                chunk_specific_imports
                            )

                        if class_declarations_tokens_len > 50:
                            chunk_specific_declarations = (
                                self._compressing_declarations(
                                    chunk_specific_declarations,
                                    int(class_declarations_tokens_len / 2),
                                )
                            )
                            class_declarations_tokens_len = self.length_function(
                                chunk_specific_declarations
                            )

                    if (
                        current_tokens
                        + import_tokens_len
                        + signature_token
                        + self.length_function("...\n")
                        + class_definition_token
                        + class_declarations_tokens_len
                        > self.max_chunk_size - 1
                    ):

                        # removing the last line which resulted in the token size get out of range
                        updated_chunk = current_chunk.replace(clean_line, "")
                        # removing the imports that were used in that line of code
                        import_removed = ""
                        declaration_removed = ""
                        if import_list != {}:
                            for libs in import_list:
                                if libs["lib_name"] in clean_line:
                                    # ignoring repetitive imports
                                    if import_dict[libs["import_statement"]] == 1:
                                        # removing that import
                                        chunk_specific_imports.replace(
                                            libs["import_statement"], ""
                                        )
                                        import_removed = libs["import_statement"]
                                    else:
                                        pass

                        declarations_removed = ""
                        if class_declaration_list != []:
                            for vars in class_declaration_list:
                                if vars["variable_names"] in clean_line:
                                    if declaration_dict[vars["declaration_code"]] == 1:
                                        chunk_specific_declarations.replace(
                                            vars["declaration_code"], ""
                                        )
                                        declaration_removed = vars["declaration_code"]
                                    else:
                                        pass

                        if class_definition_token != 0 and signature_token != 0:
                            content = (
                                chunk_specific_imports
                                + "\n"
                                + class_definition
                                + "\n"
                                + chunk_specific_declarations
                                + "\n...\n"
                                + signature
                                + "\n...\n"
                                + updated_chunk
                            )
                        else:
                            # elif class_definition_token == 0 and signature_token == 0:
                            # content = chunk_specific_imports + '\n' + updated_chunk
                            # elif class_definition_token == 0 and signature_token != 0:
                            content = (
                                chunk_specific_imports
                                + "\n"
                                + signature
                                + "\n...\n"
                                + updated_chunk
                            )
                        # elif class_definition_token != 0 and signature_token == 0:

                        mchunks.append(
                            {
                                "content": content,
                                "start_line": start_line,
                                "end_line": curr_line,
                                # "num_tokens": self.length_function(signature) + self.length_function(" ...") + middle + 1,
                                "num_tokens": self.length_function(content),
                            }
                        )

                        # extracting the imports if used in last line (Chunk updation)

                        current_chunk = clean_line
                        current_tokens = self.length_function(clean_line)
                        chunk_specific_imports = import_removed
                        import_tokens_len = self.length_function(chunk_specific_imports)
                        chunk_specific_declarations = declaration_removed
                        class_declarations_tokens_len = self.length_function(
                            chunk_specific_declarations
                        )

                    start_line = curr_line + 1
                curr_line += 1

                # Ensure the last chunk is added, with ellipsis at the end if it's not the first chunk
                # \t is used as the fucntion is inside of class

                if class_definition_token != 0:
                    content = (
                        chunk_specific_imports
                        + "\n"
                        + class_definition
                        + "\n"
                        + chunk_specific_declarations
                        + "\n...\n"
                        + signature
                        + "\n...\n"
                        + current_chunk
                    )
                else:
                    content = (
                        chunk_specific_imports
                        + "\n"
                        + signature
                        + "\n...\n"
                        + current_chunk
                    )

                if current_chunk != "":
                    mchunks.append(
                        {
                            "content": content,
                            "start_line": start_line,
                            "end_line": curr_line,
                            "num_tokens": self.length_function(content),
                        }
                    )

                logging.info("Chunks formed:")
                return mchunks

        else:
            logging.warning("The methods seems empty i.e., without a body")
            return []

    def _construct_class_definition_chunk(self, node, code):
        """
        Construct class definition chunks by extracting class signatures from class nodes,
        appending ellipsis
        Example: "class A :{...} Class B: {...}"

        :param node: the node representing the class definition in the AST
        :param code: the full source code snippet containing the class
        :param max_chunk_size: the maximum number of tokens per chunk
        :param token_counter: a function to count tokens in a given string
        :return: a list of dictionaries containing chunk content and metadata
        """

        chunks = []
        start_line = node.start_point[0]

        class_body_node = self._first_child(node, astcst.CLASS_BODY)
        if class_body_node:
            class_header_end = class_body_node.start_byte
            class_header_end_line = class_body_node.start_point[0]  # row (0-indexed)
        else:
            class_header_end = node.end_byte
            class_header_end_line = node.end_point[
                0
            ]  # fallback if class_body is missing

        class_header = code[node.start_byte : class_header_end].strip()

        chunks.append(
            {
                "content": class_header + "\n",
                "start_line": start_line,
                "end_line": class_header_end_line,
                "num_tokens": self.length_function(class_header + "\n"),
            }
        )

        return chunks

    def _construct_class_chunk(self, node, code):
        """
        Construct class chunks  from class nodes,
        appending ellipsis
        Example: "class A :def _init__(self): c= a+ b def fucn2(a, b)...."

        :param node: the node representing the class definition in the AST
        :param code: the full source code snippet containing the class
        :param max_chunk_size: the maximum number of tokens per chunk
        :param token_counter: a function to count tokens in a given string
        :return: a list of dictionaries containing chunk content and metadata
        """

        chunks = []
        class_chunk = code[node.start_byte : node.end_byte + 1]
        start_line = node.start_point[0]
        end_line = node.end_point[0]
        chunks.append(
            {
                "content": class_chunk,
                "start_line": start_line,
                "end_line": end_line,
                "num_tokens": self.length_function(class_chunk),
            }
        )

        return chunks

    def _first_child(
        self, node: Node, grammar_name: Union[Any, List[Any]]
    ) -> Optional[Node]:
        """
        Return the first child of a node with a given grammar name.

        :param node: the node
        :param grammar_name: the grammar name of the child

        :return: the first child with the given grammar name
        """

        if isinstance(grammar_name, list):
            return next(
                (child for child in node.children if child.type in grammar_name), None
            )
        return next(
            (child for child in node.children if child.type == grammar_name), None
        )
