import openai
from typing import Tuple


class CodeDescriptionGenerator:
    def __init__(
        self,
        code_description_model_name: str,
        api_url: str = None,
        api_key: str = None,
    ):
        self.model = code_description_model_name
        # TODO: check if api_url and api_key are given or use a local model
        self.api_url = api_url
        self.api_key = api_key
        self.client = openai.OpenAI(base_url=self.api_url, api_key=self.api_key)

    def generate_description(self, code, context, no_context=False) -> str:
        """Generate a description for a given code snippet.
        :param code: The code snippet to describe.
        :param context: The context in which the code snippet appears.
        :param no_context: If True, generate descriptions without context.
        :return: The generated description.
        :rtype: str
        """
        system_prompt, user_prompt = self.prepare_payload(code, context, no_context)
        return self.make_api_request(self.model, system_prompt, user_prompt)

    def prepare_payload(
        self, code: str, context: str, no_context: bool
    ) -> Tuple[str, str]:
        """Prepare the user and system content for the API request.

        :param code: The code snippet to describe.
        :param context: The context for the code snippet.
        :param no_context: Flag to indicate if context should be used.
        :return: The user content and system content strings.
        :rtype: Tuple[str, str]
        """
        # TODO: make these prompts customizable
        user_prompt: str = f"Here is the code:\n\n {code}"
        system_prompt: str = (
            "You are an expert software developer. Your task is to generate a comprehensive, precise, short, and concise textual description of the code provided. Your description must be a few sentences without any code in it!"
        )

        if not no_context:
            user_prompt += f"\n\n Here is the context:\n\n [CONTEXT]{context}[/CONTEXT]"
            system_prompt += " Use the context provided between [CONTEXT] and [/CONTEXT] separators, but avoid adding too much detail from the context."

        return system_prompt, user_prompt

    def make_api_request(self, model: str, system_prompt: str, user_prompt: str) -> str:
        """Make the API request to generate the code description.

        :param model: The model to use for generating the description.
        :param system_content: The system prompt for the API request.
        :param user_content: The user prompt for the API request.
        :return: The generated description.
        :rtype: str
        """
        response = self.client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            # TODO: make these arguments customizable
            max_tokens=1024,
            temperature=0.4,
            top_p=1,
            stream=False,
        )
        return response.choices[0].message.content
