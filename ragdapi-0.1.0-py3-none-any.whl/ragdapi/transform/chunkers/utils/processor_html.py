from bs4 import BeautifulSoup
from typing import Dict, List, Optional
from dataclasses import dataclass, field
import ragdapi.transform.chunkers.utils.utils_html as utils


@dataclass
class Section:
    level: str = ""
    level_content: str = ""
    context: str = ""
    context_soup: Optional[BeautifulSoup] = None
    codes: List[str] = field(default_factory=list)
    descriptions_dict: Dict[str, str] = field(default_factory=dict)
    updated_html: Optional[str] = ""
    updated_text: Optional[str] = ""


@dataclass
class DocMetas:
    level: str
    status: str = "Pass"
    number_of_code: int = 0
    number_of_code_repeted: int = 0
    number_of_describe_code: int = 0
    number_of_describe_code_failed: int = 0
    is_a_swagger: bool = False
    finished: bool = False
    issues_with_section: bool = False


class HTMLProcessor:
    def __init__(self, html_string: str, level: str):
        """Class to process the HTML with code and extract it.

        :param row: row of information
        :param level: level to chunk the html
        """
        self.html_string = html_string
        self.soup = BeautifulSoup(self.html_string, "lxml")
        self.desired_level = level
        self.current_level = level
        self.doc_metas = DocMetas(level=self.desired_level)
        self.global_code2desc = {}

        if not utils.is_swagger(self.soup):
            (
                self.content_between_h,
                self.current_level,
                self.doc_metas.issues_with_section,
            ) = utils.extract_content_between_h(self.soup, self.desired_level)
            self.sections = []

            for section in self.content_between_h:
                self.sections.append(self.populate_section_info(section))

        else:
            self.doc_metas.is_a_swagger = True
            self.sections = [Section()]

    def populate_section_info(self, section: Section) -> Section:
        """Initialise the section object by extracting all the nesseray information
        from the raw html  - context text - level text - codes if present (else empty list)
        update the document metas as well

        :param section: section to initialise
        :return: section updated will all the nessary info
        :rtype: Section
        """
        context_soup = BeautifulSoup(section["html_text"], "lxml")
        level_content = utils.get_text(section["h_n"])
        context = utils.get_text(section["html_text"])
        codes = utils.extract_and_clean_code(context_soup)

        self.doc_metas.number_of_code += len(codes)

        return Section(
            level=self.current_level,
            level_content=level_content,
            context=context,
            context_soup=context_soup,
            codes=codes,
        )
