import json
import os
import yaml


def generate_markdown(openapi_spec: str) -> str:
    """ Convert the swagger into a usable markdwon where the information is processed at the right place and ready for chunking
    :param  openapi_spec: json of the swagger"""
    md = []

    # Info Section
    info = openapi_spec.get("info", {})
    title = info.get("title", "API Documentation")
    description = info.get("description", "")
    version = info.get("version", "")

    md.append(f"# {title}\n")
    md.append(f"{description}\n")
    md.append(f"Version: {version}\n")

    # Servers Section
    servers = openapi_spec.get("servers", [])
    if servers:
        md.append("## Servers\n")
        for server in servers:
            md.append(f"- {server.get('url')}\n")
            variables = server.get("variables", {})
            for var_name, var_info in variables.items():
                default = var_info.get("default", "")
                var_description = var_info.get("description", "")
                md.append(f"  - `{var_name}`: {default} ({var_description})\n")

    # Tags Section
    tags = openapi_spec.get("tags", [])
    if tags:
        md.append("## Tags\n")
        for tag in tags:
            tag_name = tag.get("name", "")
            tag_description = tag.get("description", "")
            md.append(f"- `{tag_name}`: {tag_description}\n")

    # Paths Section
    paths = openapi_spec.get("paths", {})
    for path, path_info in paths.items():
        md.append(f"## {path}\n")

        for method, method_info in path_info.items():
            if type(method_info) != type([]):
                tags = method_info.get("tags", [])
                summary = method_info.get("summary", "")
                description = method_info.get("description", "")
                parameters = method_info.get("parameters", [])
                requestBody = method_info.get("requestBody", {})
                responses = method_info.get("responses", {})

                md.append(f"### {method.upper()} {path}\n")
                if tags:
                    md.append(f"**Tags:** {', '.join(tags)}\n")
                md.append(f"**Summary:** {summary}\n")
                if description:
                    md.append(f"**Description:** {description}\n")

                # Parameters Section
                if parameters:
                    md.append("### Parameters\n")
                    for param in parameters:
                        name = param.get("name", "")
                        param_in = param.get("in", "")
                        required = param.get("required", False)
                        schema = param.get("schema", {})
                        param_type = schema.get("type", "string")
                        param_description = param.get("description", "")

                        md.append(
                            f"- `{name}` ({param_in}, {param_type}, {'required' if required else 'optional'}): {param_description}\n"
                        )

                # Request Body Section
                if requestBody:
                    md.append("### Request Body\n")
                    req_description = requestBody.get("description", "")
                    if req_description:
                        md.append(f"**Description:** {req_description}\n")
                    req_content = requestBody.get("content", {})
                    for content_type, content_info in req_content.items():
                        schema = content_info.get("schema", {})
                        md.append(f"**Content-Type:** {content_type}\n")
                        md.append("**Schema:**\n")
                        md.append("```json\n")
                        md.append(f"{yaml.dump(schema, default_flow_style=False)}")
                        md.append("```\n")

                # Responses Section
                if responses:
                    md.append("### Responses\n")
                    for status_code, response_info in responses.items():
                        description = response_info.get("description", "")
                        content = response_info.get("content", {})

                        md.append(f"#### {status_code}\n")
                        md.append(f"**Description:** {description}\n")
                        for content_type, content_info in content.items():
                            schema = content_info.get("schema", {})
                            md.append(f"**Content-Type:** {content_type}\n")
                            md.append("**Schema:**\n")
                            md.append("```json\n")
                            md.append(f"{yaml.dump(schema, default_flow_style=False)}")
                            md.append("```\n")

    return "\n".join(md)
