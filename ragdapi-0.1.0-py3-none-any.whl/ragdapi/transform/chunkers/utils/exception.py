
class FinishedProcessing(Exception):
    pass


class ContextSizeExceeded(Exception):
    pass

class PrcessingError(Exception):
    pass


class UnknownException(Exception): 
    pass


class NotDesiredLevelException(Exception):
    pass