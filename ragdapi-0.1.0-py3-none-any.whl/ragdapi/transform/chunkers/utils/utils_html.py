import re
from bs4 import BeautifulSoup
from typing import Dict, List, Optional, Union


LEVELS: List[str] = ["head", "h1", "h2", "h3", "h4"]
USELESS_SECTIONS: List[str] = ["History"]


def extract_content_between_h(
    soup: BeautifulSoup, level: Optional[str] = None
) -> Union[List[Dict[str, str]], str, bool]:
    """Gets all the content between two tags of a given level and also before the first header.

    :param level (Optional[str]): The HTML tag level to search for. Defaults to the instance's level attribute.
    :param soup (BeautifulSoup): soup content of all html page to chunk
    :return: The list of dict linked the chunked section and their header - the level used - and the section status
    """

    content_between_h = []

    assert level is not None, "You must initialise the level"
    assert (level in LEVELS), "You must initialise the level in [h1, h2, h3, h4,  head]"

    current_level = level

    # Find the tags corresponding to the level
    h_tags, current_level = find_headers_by_level(soup, current_level)
    # if current_level != level :
    #   raise NotDesiredLevelException(f"The disired level {level} was not achieved, instead {current_level} ")

    # Handle content before the first header
    if h_tags:
        content_between_h.append(
            {
                "h_n": "before_first_header",
                "html_text": str(soup).split(f"<{current_level}")[0],
            }  # only one < cause sometines there were <h2 and other times <h2>
        )

    # Handle content between headers
    for i in range(len(h_tags) - 1):
        current_h = h_tags[i]
        next_h = h_tags[i + 1]
        content = get_content_between_tags(current_level, current_h, next_h)
        content_between_h.append({"h_n": str(current_h), "html_text": "".join(content)})

    # Handle content after the last header
    if h_tags:
        last_h = h_tags[-1]
        if "History" not in last_h:
            content_after_last_h = []
            seen_sibling = []
            for sibling in last_h.find_all_next():
                if sibling.name != "script" and not (
                    is_in(sibling, seen_sibling)
                ):  # remove javascript
                    seen_sibling.append(sibling)
                    content_after_last_h.append(str(sibling))

            content_between_h.append(
                {"h_n": str(last_h), "html_text": "".join(content_after_last_h)}
            )

    # End
    return (
        content_between_h,
        current_level,
        issue_with_section_detector(soup, content_between_h),
    )


def find_headers_by_level(
    soup: BeautifulSoup, disired_level: str
) -> Union[List[BeautifulSoup], str]:
    """Find all the headers tags of a curent level

    :param soup: the main soup from wich you want to extract the header tags
    :param current_level: the desired level from wich ou want the tags
    :return: a list of tags to an existing level"""
    h_tags = soup.find_all(disired_level)
    if not h_tags:
        index = LEVELS.index(disired_level)
        for tag in LEVELS[index::-1]:
            h_tags = soup.find_all(tag)
            if h_tags:
                return h_tags, tag
        raise Exception(f"Issue with the HTML no levels within {LEVELS}")
    return h_tags, disired_level


def get_content_between_tags(
    current_level, start_tag: BeautifulSoup, end_tag: BeautifulSoup
) -> List[str]:
    """Find all the content between two tags

    :param current_level: use to try to avoid parsing isues
    :param start_tag: tag Beatifulsoup where we start
    :param end_tag: tag beautifulsoup when we stop the section
    :return: a list of tags to an existing level"""
    content = []
    for sibling in start_tag.find_next_siblings():
        if sibling == end_tag:
            break
        if sibling.name != "script":
            if f"<{current_level}" in str(sibling):
                content.append(str(sibling).split(f"<{current_level}")[0])
            else:
                content.append(str(sibling))
    return content


def issue_with_section_detector(
    soup: BeautifulSoup, content_between_h: List[Dict[str, str]]
) -> bool:
    """Check if the parser failed to parse the html correclty

    :param soup: main soup of the page
    :param content_between_h: The dict with all the section chunks and their relative headers
    """
    len_soup = len(get_text(soup))
    len_sections = 0
    for section in content_between_h:
        len_sections += len(get_text(section["html_text"]))
    return len_sections > len_soup + 200


def is_swagger(soup: BeautifulSoup) -> bool:
    """Check is the html is a swagger"""
    return len(soup.find_all(id="swagger-ui")) > 0


def is_in(elt: str, list_elt: str):
    # doesn't work 100% of the time but is still a good way to reduce repetitions
    for string in list_elt:
        if elt in string:
            return True
    return False


def remove_repeated_patterns(tags: BeautifulSoup):
    seen = set()
    result = []
    number_of_code_repeted = 0
    for tag in tags:
        if tag not in seen:
            seen.add(tag)
            result.append(tag)
        else:
            number_of_code_repeted += 1
    return result


def extract_and_clean_code(soup: BeautifulSoup) -> List[str]:
    """Extract all the codes of a HTML and remove the repeated ones"""
    pre_tags = remove_repeated_patterns(list(soup.find_all("pre", class_="code")))
    return [
        re.sub(r"\s+", " ", pre_tag.get_text()).replace("\n", " ")
        for pre_tag in pre_tags
    ]


def get_text(raw_html: Union[str, BeautifulSoup]) -> str:
    """Extract the text from a HTML and clean it it can also take directly the string of HTML
    :param raw_html: either a soup from which to extract the text or the string of html
    """
    if type(raw_html) == type(""):
        soup = BeautifulSoup(raw_html, "lxml")
    else:
        soup = raw_html

    return re.sub(r"\s+", " ", soup.get_text()).replace("\n", " ")


def correct_chunk(
    first_balise: str = "[CODE_DESCRIPTION]", last_balise: str = "[/CODE_DESCRIPTION]"
) -> str:
    """Correct the chunk with artificial content after their naif chunking to ensure they
    are no missing special balise

    :param first_balise: opening balise to check
    :param last_balise: closing balise to check
    """
    first = first_tag(chunk, first_balise, last_balise)
    last = last_tag(chunk, first_balise, last_balise)
    if first == last_balise:
        chunk = first_balise + " " + chunk
    if last == first_balise:
        chunk = chunk + " " + last_balise
    return chunk


def first_tag(text: str, first_balise: str, last_balise: str):
    """
    Returns the last special token of the chunk

    :param text: the string of the chunk
    :output: fist Special token
    """
    if text.find(first_balise) < text.find(last_balise):
        return first_balise

    if text.find(first_balise) > text.find(last_balise):
        return last_balise

    else:
        return None


def last_tag(text: str, first_balise: str, last_balise: str):
    """
    Returns the last special token of the chunk

    :param text: the string of the chunk
    :output : last Special token
    """
    if text.rfind(first_balise) > text.rfind(last_balise):
        return first_balise

    if text.rfind(first_balise) < text.rfind(last_balise):
        return last_balise

    else:
        return None
