import re
import sys
import time
import traceback
import logging
from bs4 import BeautifulSoup
import openai
from typing import Any, Dict, Optional, List
from langchain_core.documents import Document
import ragdapi.transform.chunkers.utils.utils_html as utils
from ragdapi.transform.chunkers.utils.exception import *
from ragdapi.transform.chunkers.base import ChunkerBase
from .utils.processor_html import HTMLProcessor, Section
from .utils.generator_code_description import CodeDescriptionGenerator

logger = logging.getLogger(__name__)


class HTMLSectionChunker(ChunkerBase):
    def __init__(
        self,
        desired_level: str,
        describe_codes: bool = False,
        describe_images: bool = False,
        fuse: bool = False,
        code_description_model_name: str = None,
        image_description_model_name: str = None,
        api_url: str = None,
        api_key: str = None,
        **kwargs: Dict[str, str],
    ):
        super().__init__(**kwargs)
        self.desired_level = desired_level
        self.describe_codes = describe_codes
        self.describe_images = describe_images
        self.fuse = fuse
        self.code_description_model_name = code_description_model_name
        self.image_description_model_name = image_description_model_name
        self.api_url = api_url
        self.api_key = api_key
        # TODO: check if api_url and api_key are given
        assert (
            not describe_codes or code_description_model_name
        ), "If 'describe_codes' is True, then give a model name."
        assert (
            not describe_images or image_description_model_name
        ), "If 'a' is True, then 'b' must be 'model'."

    def chunk_text(self, text: str, **kwargs: Dict[str, Any]) -> List[Document]:
        chunks: List[Document] = []

        htmlproc = HTMLProcessor(text, self.desired_level)

        if self.describe_codes:
            level_index = utils.LEVELS.index(htmlproc.current_level)

            try:
                logging.debug(
                    f"CASE 0 : Initial try with level {utils.LEVELS[level_index]}"
                )
                htmlproc = self.generate_description_all_code_html(htmlproc)
            except ContextSizeExceeded as e:
                while not (level_index + 1 == len(utils.LEVELS)):
                    # next level
                    level_index = level_index + 1
                    htmlproc = HTMLProcessor(text, utils.LEVELS[level_index])

                    if htmlproc.current_level == htmlproc.desired_level:
                        try:
                            logging.debug(
                                f"CASE 1: Current level's context is too large, reducing level to: {utils.LEVELS[level_index]}"
                            )
                            htmlproc = self.generate_description_all_code_html(htmlproc)
                        except:
                            logger.debug(
                                f"CASE 1 ERROR: tried to reduce to {utils.LEVELS[level_index]} - does not exist"
                            )
                            continue
                try:
                    logger.debug(
                        "CASE 2: No section small enough was found, only the code is given for description."
                    )
                    htmlproc = self.generate_description_all_code_html(
                        htmlproc, no_context=True
                    )
                except:
                    logger.debug(
                        "FAIL: No description could be generated for some of the codes"
                    )
                    htmlproc = self.generate_description_all_code_html(
                        htmlproc, no_context=True, no_description=True
                    )
            except Exception as e:
                raise UnknownException(e)

        if self.describe_images:
            # TODO: Add images description
            pass

        for section in htmlproc.sections:
            chunk: Section = None
            metadata = {k: v for k, v in vars(htmlproc.doc_metas).items()}
            if section.context_soup:
                if (
                    htmlproc.doc_metas.issues_with_section
                    or htmlproc.doc_metas.status == "Fail"
                ):
                    chunk = self.process_section(section, htmlproc.global_code2desc)
                else:
                    chunk = self.process_section(section)

                # TODO: add HTML page reconstruction to add to metadata if necessary
                content = chunk.updated_text
                # TODO: check if we add description_dict to metadata
                # metadata["descriptions_dict"] = chunk.descriptions_dict
            else:
                # swagger
                content = ""
            chunks.append(Document(page_content=content, metadata=metadata))

        if self.fuse:
            if (
                htmlproc.doc_metas.issues_with_section
                or htmlproc.doc_metas.status == "Fail"
            ):
                # replace in the source html
                chunk = self.process_html(text, htmlproc.global_code2desc)
            else:
                # all the updated sections will be fuse together
                chunk = self.fuse_sections(htmlproc.sections)

            content = chunk.updated_text

            # overwrite the final fused output
            chunks = [Document(page_content=content, metadata=metadata)]

        return chunks

    def generate_description_all_code_html(
        self,
        htmlproc: HTMLProcessor,
        no_context: bool = False,
        no_description: bool = False,
    ) -> HTMLProcessor:
        if htmlproc.doc_metas.finished:
            raise FinishedProcessing("Processing is already finished.")
        generator = CodeDescriptionGenerator(
            self.code_description_model_name, self.api_url, self.api_key
        )
        try:
            for section in htmlproc.sections:
                for index, code in enumerate(section.codes):
                    try:
                        description = generator.generate_description(
                            code, section.context, no_context
                        )
                        section.descriptions_dict[code] = description
                        htmlproc.global_code2desc[code] = description
                        htmlproc.doc_metas.number_of_describe_code += 1
                        logger.debug(
                            f"SUCCESS FOR CODE n°: {index+1}/{len(section.codes)}"
                        )
                    except openai.NotFoundError as e:
                        if no_description:
                            logger.exception(
                                f"NO DESCRIPTION FOR CODE n°: {index + 1}/{len(section.codes)}"
                            )
                            section.descriptions_dict[code] = code
                            htmlproc.global_code2desc[code] = code
                            htmlproc.doc_metas.status = "Fail"
                            htmlproc.doc_metas.number_of_describe_code_failed += 1
                        else:
                            self.handle_error(e, htmlproc, no_context, no_description)

                    except openai.BadRequestError as e:
                        logger.exception("Unhandled Exception", exc_info=e)

            htmlproc.doc_metas.finished = True

        except Exception as e:
            htmlproc.doc_metas.status = "Fail"
            raise PrcessingError("")
        return htmlproc

    def handle_error(
        self,
        e: openai.NotFoundError,
        htmlproc: HTMLProcessor,
        no_context: bool = False,
        no_description: bool = False,
    ) -> None:
        """Handle the NotFoundError during the HTTP request for generating code descriptions.

        :param e: The exception raised during the HTTP request.
        :rtype: None
        :raises ContextSizeExceeded: If the context is too big for the model
        :raises Exception: If their is an error without a define handeling
        """
        if e.response.status_code == 404:
            logger.error(
                f"Error 404: Model {self.code_description_model_name} is offline."
            )
            sys.exit(1)

        if e.response.status_code == 429:
            logger.error(f"Error 429: Model is overloaded.")
            time.sleep(30)  # Sleep for 30 seconds before retrying
            self.generate_description_all_code_html(
                htmlproc, no_context, no_description
            )

        if e.response.status_code == 422:
            raise ContextSizeExceeded("The prompt is too large for the model")

        else:
            logger.error("ERROR: %s", traceback.format_exc())
            raise Exception

    def process_section(
        self,
        section: Section,
        global_code2desc: Optional[Dict[str, str]] = None,
    ) -> Section:
        """
        Class to process the Section and generate the final chunk. global_code2desc
        is used in case there is an issue with the section parsing

            :param row: row of information
            :param global_code2desc: global dict mapping a
        """
        soup = section.context_soup
        pre_tags = soup.find_all("pre", class_="code")
        for pre_tag in pre_tags:
            code = utils.get_text(pre_tag)

            if self.describe_codes:
                if global_code2desc is None:
                    global_code2desc = section.descriptions_dict
                description = global_code2desc.get(code)
                pre_tag.string = (
                    f" [CODE_DESCRIPTION] {description} [/CODE_DESCRIPTION] "
                )

            if "class" in pre_tag.attrs:
                # reset the tag, no longer class=code
                del pre_tag["class"]

        # updated soup
        section.updated_html = str(soup.prettify())
        section.updated_text = utils.get_text(soup)
        return section

    def process_html(
        self,
        text: Section,
        global_code2desc: Optional[Dict[str, str]] = None,
    ) -> Section:
        """Change the codes buy their description at the scale of the html directly"""
        soup = BeautifulSoup(text, "lxml")
        pre_tags = list(soup.find_all("pre", class_="code"))

        for pre_tag in pre_tags:
            # get the description of the code
            code = re.sub(r"\s+", " ", pre_tag.get_text()).replace("\n", " ")

            if self.describe_codes:
                description = global_code2desc.get(code)
                # update html
                pre_tag.string = (
                    " [CODE_DESCRIPTION] " + description + " [/CODE_DESCRIPTION] "
                )
            # remove the code class as now its a description
            if "class" in pre_tag.attrs:
                del pre_tag["class"]

        updated_html = str(soup.prettify())
        updated_text = utils.get_text(soup)
        return Section(updated_html=updated_html, updated_text=updated_text)

    def fuse_sections(
        self,
        sections: List[Section],
    ):
        updated_text = ""
        updated_html = ""
        for section in sections:
            if section.level_content not in utils.USELESS_SECTIONS:

                if section.updated_html and len(section.updated_html) > 0:
                    soup = BeautifulSoup(section.updated_html, "lxml")
                    body = soup.body
                    if body:
                        contents = body.contents
                    else:
                        contents = soup.contents

                    updated_html = section.level + "".join(str(tag) for tag in contents)

                    updated_text += (
                        f"<{section.level}> {str(section.level_content)} </{section.level}>"
                        + section.updated_text
                    )

        return Section(
            updated_html=f"<html><body>{updated_html}</body></html>",
            updated_text=updated_text,
        )
