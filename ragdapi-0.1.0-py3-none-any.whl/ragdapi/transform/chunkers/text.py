from typing import Any, Dict, List, Optional, Union
from langchain_core.documents import Document
from .base import ChunkerBase
from transformers import PreTrainedTokenizerBase


class TokenChunker(ChunkerBase):
    def __init__(
        self,
        tokenizer: Optional[PreTrainedTokenizerBase] = None,
        tokenizer_name: Optional[str] = None,
        tokenizer_cache_dir: Optional[str] = None,
        **kwargs,
    ):
        """
        Initialize TokenChunker with a tokenizer or tokenizer name.

        :param tokenizer: An instance of a pre-trained tokenizer.
                          Either `tokenizer` or `tokenizer_name` must be provided, but not both.
        :param tokenizer_name: Name of the tokenizer model to use.
                               Either `tokenizer_name` or `tokenizer` must be provided, but not both.
        :param tokenizer_cache_dir: Directory to cache the tokenizer.
                                    This should only be provided if `tokenizer_name` is given.
        :param kwargs: Additional arguments to pass to the base class.

        :raises ValueError: If both `tokenizer` and `tokenizer_name` are provided,
                            or if neither is provided.
        :raises ValueError: If `tokenizer_cache_dir` is provided without `tokenizer_name`.
        :raises ValueError: If `tokenizer` or `length_function` is included in `kwargs`.
        """
        if "tokenizer" in kwargs:
            raise ValueError(
                "Tokenizer should not be provided in kwargs. Pass it explicitly."
            )
        if "length_function" in kwargs:
            raise ValueError(
                "length_function should not be provided in kwargs when a tokenizer is used, "
                "as it will be overridden by the tokenizer's length function."
            )

        if not tokenizer_name and not tokenizer:
            raise ValueError("You must provide either `tokenizer_name` or `tokenizer`.")

        super().__init__(
            tokenizer=tokenizer,
            tokenizer_name=tokenizer_name,
            tokenizer_cache_dir=tokenizer_cache_dir,
            **kwargs,
        )

    def chunk_text(self, text: str) -> List[Document]:
        """Split text into chunks based on tokens."""
        chunks: List[Document] = []

        if not (isinstance(text, str) and text.strip()):
            return chunks

        tokens = self.tokenizer.tokenize(text)
        start_idx = 0
        cur_idx = min(start_idx + self.max_chunk_size, len(tokens))
        chunk_tokens = tokens[start_idx:cur_idx]

        while start_idx < len(tokens):
            chunk_str = self.tokenizer.convert_tokens_to_string(chunk_tokens)
            num_tokens = len(chunk_tokens)

            # Assuming Document has a metadata field
            chunks.append(
                Document(page_content=chunk_str, metadata={"num_tokens": num_tokens})
            )
            if cur_idx == len(tokens):
                break
            start_idx += self.max_chunk_size - self.chunk_overlap
            cur_idx = min(start_idx + self.max_chunk_size, len(tokens))
            chunk_tokens = tokens[start_idx:cur_idx]

        return chunks


class TokenLineChunker(ChunkerBase):
    def __init__(
        self,
        tokenizer: Optional[PreTrainedTokenizerBase] = None,
        tokenizer_name: Optional[str] = None,
        tokenizer_cache_dir: Optional[str] = None,
        **kwargs,
    ):
        """
        Initialize TokenLineChunker with a tokenizer or tokenizer name.

        :param tokenizer: An instance of a pre-trained tokenizer.
                          Either `tokenizer` or `tokenizer_name` must be provided, but not both.
        :param tokenizer_name: Name of the tokenizer model to use.
                               Either `tokenizer_name` or `tokenizer` must be provided, but not both.
        :param tokenizer_cache_dir: Directory to cache the tokenizer.
                                    This should only be provided if `tokenizer_name` is given.
        :param kwargs: Additional arguments to pass to the base class.

        :raises ValueError: If both `tokenizer` and `tokenizer_name` are provided,
                            or if neither is provided.
        :raises ValueError: If `tokenizer_cache_dir` is provided without `tokenizer_name`.
        :raises ValueError: If `tokenizer` or `length_function` is included in `kwargs`.
        """
        if "tokenizer" in kwargs:
            raise ValueError(
                "Tokenizer should not be provided in kwargs. Pass it explicitly."
            )
        if "length_function" in kwargs:
            raise ValueError(
                "length_function should not be provided in kwargs when a tokenizer is used, "
                "as it will be overridden by the tokenizer's length function."
            )

        if not tokenizer_name and not tokenizer:
            raise ValueError("You must provide either `tokenizer_name` or `tokenizer`.")

        super().__init__(
            tokenizer=tokenizer,
            tokenizer_name=tokenizer_name,
            tokenizer_cache_dir=tokenizer_cache_dir,
            **kwargs,
        )

    def chunk_text(self, text: str) -> List[Document]:
        chunks: List[Document] = []

        if not (isinstance(text, str) and text.strip()):
            return chunks

        chunk_content = []
        chunk_tokens = 0
        start_line = 1
        curr_line = 1

        for line in text.split("\n"):
            line_tokens = self.length_function(line)

            if chunk_tokens + line_tokens > self.max_chunk_size and chunk_content:
                chunks.append(
                    Document(
                        page_content="".join(chunk_content),
                        metadata={
                            "start_line": start_line,
                            "end_line": curr_line - 1,
                            "num_tokens": chunk_tokens,
                        },
                    )
                )
                chunk_content = []
                chunk_tokens = 0
                start_line = curr_line

            if line_tokens >= self.max_chunk_size:
                current_chunk_tokens = []
                tokens = self.tokenizer.tokenize(line)
                for token in tokens:
                    if chunk_tokens + 1 > self.max_chunk_size:
                        chunks.append(
                            Document(
                                page_content=self.tokenizer.convert_tokens_to_string(
                                    current_chunk_tokens
                                ),
                                metadata={
                                    "start_line": start_line,
                                    "end_line": curr_line,
                                    "num_tokens": chunk_tokens,
                                },
                            )
                        )
                        current_chunk_tokens = []
                        chunk_tokens = 0
                    current_chunk_tokens.append(token)
                    chunk_tokens += 1
                if current_chunk_tokens:
                    chunks.append(
                        Document(
                            page_content="\n".join(
                                [
                                    self.tokenizer.convert_tokens_to_string(
                                        current_chunk_tokens
                                    ),
                                    "",
                                ]
                            ),
                            metadata={
                                "start_line": start_line,
                                "end_line": curr_line,
                                "num_tokens": chunk_tokens,
                            },
                        )
                    )
                chunk_content = []
                chunk_tokens = 0
                start_line = curr_line + 1
            else:
                chunk_content.append("\n".join([line, ""]))
                chunk_tokens += line_tokens + 1

            curr_line += 1

        if chunk_content:
            chunks.append(
                Document(
                    page_content="".join(chunk_content),
                    metadata={
                        "start_line": start_line,
                        "end_line": curr_line - 1,
                        "num_tokens": chunk_tokens,
                    },
                )
            )

        return chunks
