import logging
import re
from typing import Dict, List
from ragdapi.transform.chunkers.base import ChunkerBase
from langchain_core.documents.base import Document

LEVELS_MARKDOWN = {"h1": "#", "h2": "##", "h3": "###", "h4": "####", "h5": "#####"}
LEVELS_MAP = {"#": "h1", "##": "h2", "###": "h3", "####": "h4", "#####": "h5"}


class MarkdownSectionChunker(ChunkerBase):
    def __init__(
        self, desired_level: str, **kwargs: Dict[str, str],
    ):
        super().__init__(**kwargs)

        # Validate the input level
        if not isinstance(desired_level, str) or not (
            desired_level.startswith("#")
            or desired_level in ["h1", "h2", "h3", "h4", "h5"]
        ):
            raise ValueError(
                "The level must be a string starting with '#' of in  ['h1', 'h2', 'h3', 'h4', 'h5'] ."
            )

        if desired_level.startswith("#"):
            self.desired_level = LEVELS_MAP[desired_level]
        else:
            self.desired_level = desired_level

        self.current_level = desired_level

    def chunk_text(self, text: str) -> List[Document]:
        """Chunker sor markdown will chunk the markdown based on the level given in input"""

        # check if the level exist
        try : 
            self.current_level = self.find_valid_level(
                markdown=text, requested_level=self.desired_level
            )
            mark_down_level = LEVELS_MARKDOWN[self.desired_level]

            # Escape the level for use in regex
            escaped_level = re.escape(mark_down_level)
            # Find all headings at the specified level
            headings = [
                match.start()
                for match in re.finditer(rf"^{escaped_level} .+", text, flags=re.MULTILINE)
            ]

            if not headings:
                raise ValueError(
                    f"No headings found for the specified level: {mark_down_level}, corresponding to {self.current_level}"
                )

            # Initialize chunks list
            chunks = []

            # Handle the text before the first heading and merge it with the first section
            if headings[0] != 0:
                first_chunk = (
                    text[: headings[1]].strip() if len(headings) > 1 else text.strip()
                )
                chunks.append(first_chunk)
                start_index = 1  # Start from the second heading
            else:
                start_index = 0

            # Iterate over the remaining headings and slice the content
            for i in range(start_index, len(headings)):
                start = headings[i]
                end = headings[i + 1] if i + 1 < len(headings) else len(text)
                chunks.append(text[start:end].strip())

            chunks = [
                Document(
                    page_content=self.clean_markdown(chunk),
                    metadata={"level": self.current_level},
                )
                for chunk in chunks
            ]
            return chunks
        except ValueError: 
            logging.warning("The markdown don't have any header consider using another chunker for this type of data")
            return []

    def find_valid_level(self, markdown: str, requested_level: str) -> str:
        """ Find if the level requested is present, if not find the closest level above present

        :param markdown: markdown string in which find a level
        :param requested_level: the level to check the present must be a ['h1', 'h2', 'h3', 'h4', 'h5'] level """
        # Get the list of levels starting from the requested one
        levels = list(LEVELS_MARKDOWN.keys())
        if requested_level not in levels:
            raise ValueError(
                f"Invalid level '{requested_level}' requested must be in {levels}."
            )

        start_index = levels.index(requested_level)

        # Check if any headings are present, fallback to higher levels
        for i in range(start_index, -1, -1):
            level = levels[i]
            level_marker = LEVELS_MARKDOWN[level]
            if re.search(
                rf"^{re.escape(level_marker)} .+", markdown, flags=re.MULTILINE
            ):
                return level  # Return the first valid level found

        # If no valid levels found, raise an error
        raise ValueError("No valid headings found from the specified level or higher.")

    def clean_markdown(self, text: str) -> str:
        """Clean the text - remove markdown markers 
        
        :param text: markdown to clean"""

        cleaned_text = text.strip()
        cleaned_text = re.sub(r"\*\*", "", cleaned_text)
        cleaned_text = re.sub(r"# | ## | ### |#### |#|##|###|####", "", cleaned_text)
        # cleaned_text = re.sub(r'Tags:|Summary:|Description:', '', cleaned_text)
        cleaned_text = re.sub(r"\n+", "\n", cleaned_text)
        return cleaned_text.strip()
