import logging
from typing import List, Optional, Dict, Any
from tree_sitter import Node
from ragdapi.transform.repo_map import FileMapEntry, RepoMapStore
from ragdapi.transform.chunkers.utils import ast_parsers_nodes as astcst

logger = logging.getLogger(__name__)

class RepoMapBuilder:
    """
    Accumulates FileMapEntry objects during chunking,
    then flushes one concatenated repo map string to the store.
    """

    def __init__(self, store: RepoMapStore, workspace_name: str, version: str):
        self.store = store
        self.workspace_name = workspace_name
        self.version = version
        self._entries: List[FileMapEntry] = []

    def collect_from_tree(self, root_node: Node, code: str, filepath: str):
        """
        Walk top-level AST children and extract structural metadata.
        Call this once per file, right after parsing.
        """
        entry = FileMapEntry(filepath=filepath)

        for child in root_node.children:
            # ── Imports ──
            if child.type in astcst.IMPORT_NODE_TYPES:
                self._collect_imports(child, code, entry)

            # ── Classes ──
            elif child.type in astcst.CLASS_NODE_TYPES:
                self._collect_class(child, code, entry)

            # ── Top-level functions ──
            elif child.type in astcst.FUNCTION_NODE_TYPES:
                sig = self._get_signature(child, code)
                entry.functions.append(sig)

            # ── Top-level variables / assignments ──
            elif child.type in astcst.CLASS_VARIABLES_DECLARATIONS:
                var_line = child.text.decode("utf-8").split("\n")[0].strip()
                if var_line and not var_line.startswith(("#", "//", "/*")):
                    entry.top_level_variables.append(var_line)

        self._entries.append(entry)
        logger.debug(f"Repo map: collected structure for {filepath}")


    def collect_filepath_only(self, filepath: str):
        """
        Fallback for files where no AST parser is available.
        Still records the filepath in the repo map.
        """
        entry = FileMapEntry(filepath=filepath)
        self._entries.append(entry)
        logger.debug(f"Repo map: recorded filepath (no parser) for {filepath}")


    def flush(self):
        """Merge new entries into existing repo map, then save."""
        if not self._entries:
            logging.warning("No file entries collected, nothing to flush.")
            return
        
        # ── Load existing map and parse back into per-file blocks ──
        existing_map = self.store.get(self.workspace_name, self.version)

        # parsing it into a dictionary
        existing_entries = {}
        if existing_map:
            existing_entries = self._parse_existing_map(existing_map)
            logger.info(
                f"Loaded existing repo map with {len(existing_entries)} file entries"
            )
        else:
            logger.info("No existing repo map found — creating fresh")


        # ── Overwrite only the files that were re-indexed ──
        for entry in self._entries:
            existing_entries[entry.filepath] = entry.to_compact_string()

        # ── Sort by filepath and concatenate ──
        sorted_paths = sorted(existing_entries.keys())
        full_map = "\n\n".join(existing_entries[p] for p in sorted_paths)


        # Sort by filepath for a clean tree-like output
        # self._entries.sort(key=lambda e: e.filepath)
        # full_map = "\n\n".join(e.to_compact_string() for e in self._entries)

        self.store.save(self.workspace_name, self.version, full_map)
        logging.info(
            f"Repo map flushed: {len(self._entries)} files → workspace '{self.workspace_name}'"
        )
        self._entries.clear()

    # ── Private helpers ────────────────────────────────────

    def _parse_existing_map(self, repo_map: str) -> dict:
        """
        Parse the stored repo map string back into {filepath: block} dict.

        The format is:
            src/main.py
            imports: fastapi
            def main() -> None

            src/api/handlers.py
            imports: models
            class UserHandler:
                def get(id: int) -> User

        Blocks are separated by '\\n\\n', first line of each block = filepath.
        """
        entries = {}
        blocks = repo_map.split("\n\n")
        for block in blocks:
            block = block.strip()
            if not block:
                continue
            # First line is always the filepath
            filepath = block.split("\n")[0].strip()
            if filepath:
                entries[filepath] = block
        return entries

    def _collect_imports(self, node: Node, code: str, entry: FileMapEntry):
        """Extract unique import names from an import node."""
        for child in node.children:
            for sub in child.children:
                if sub.type in astcst.IMPORT_NAME:
                    name = sub.text.decode("utf-8").strip('"').strip("'")
                    if name and name not in entry.imports:
                        entry.imports.append(name)
            # Also check direct children (some languages have flat import nodes)
            if child.type in astcst.IMPORT_NAME:
                name = child.text.decode("utf-8").strip('"').strip("'")
                if name and name not in entry.imports:
                    entry.imports.append(name)


    def _collect_class(self, node: Node, code: str, entry: FileMapEntry):
        """Extract class signature + method signatures (no bodies)."""
        # Header = everything before the body block
        body = None
        for child in node.children:
            if child.type in astcst.CLASS_BODY:
                body = child
                break

        if body:
            header = code[node.start_byte : body.start_byte].strip()
        else:
            header = code[node.start_byte : node.end_byte].strip()

        methods = []
        if body:
            for child in body.children:
                if child.type in astcst.FUNCTION_NODE_TYPES:
                    methods.append(self._get_signature(child, code))

        entry.classes.append({
            "signature": header,
            "methods": methods,
        })

    def _get_signature(self, node: Node, code: str) -> str:
        """Return just the function/method signature, no body."""

        body = self._find_child(node, astcst.FUNCTION_BODY)

        if body:
            return code[node.start_byte : body.start_byte].strip()
        return code[node.start_byte : node.end_byte].strip()
    
    
    def _find_child(self, node: Node, type_list) -> Optional[Node]:
        """Find first child whose type is in the given list."""
        for child in node.children:
            if child.type in type_list:
                return child
        return None
