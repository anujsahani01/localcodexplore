import os

# To deactivate transformers warnings
os.environ["TRANSFORMERS_VERBOSITY"] = "error"

import sys
import logging
from ragdapi.transform.transformer import Transformer
from ragdapi.utils.logger import setup_logging
from ragdapi.utils.udf import parse_args
from ragdapi.schemas.config import Config
from pydantic import ValidationError
from ragdapi.utils.config_utils import (
    list_config_files,
    load_config,
    get_config_selection,
    validate_config_selection,
    get_default_config_dir,
)
import json
from pathlib import Path
import pandas as pd

logger = logging.getLogger(__name__)


def clean_nans(obj):
    if isinstance(obj, dict):
        return {k: clean_nans(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [clean_nans(i) for i in obj]
    elif pd.isna(obj) or obj is None or str(obj).strip() == "Nan":
        return "null"
    else:
        return str(obj)


def main(argv=None):
    args = parse_args(argv)
    setup_logging(args.debug, args.redirect)

    try:
        config_files = list_config_files()
    except FileNotFoundError as e:
        logger.error(e)
        sys.exit(1)

    if args.config:
        config_name = args.config
        try:
            validate_config_selection(config_name, config_files)
        except ValueError as e:
            logger.error(e)
            sys.exit(1)
    else:
        config_name = get_config_selection(config_files)

    config = load_config(config_name)

    if config.extract.dsxplore:
        config_dir = get_default_config_dir()
        config_file = config_dir / (config_name + ".json")
        if not config_file.exists():
            raise FileNotFoundError(f"The config file '{config_file}' does not exist.")

        with config_file.open("r") as f:
            config_dict = json.load(f)

        if config_dict.get("extract").get("dsxplore"):
            if args.workspace is not None:
                if config_dict.get("paths").get("root"):
                    config_dict["paths"]["root"] = str(
                        os.path.normpath(Path(args.workspace))
                    )

        try:
            config = Config(name=config_name, **config_dict)
        except ValidationError as e:
            logging.error(e)
            sys.exit(1)

    elif config.extract.localxplore:
        # # Laoding the patterns
        # spec = _read_indexignore(config)

        # # extracting requirements
        # folders, extension, patterns = _index_ignore_extraction(spec)

        # print(f"Folders to Ignore: \n{folders}")
        # print(f"Extensions to Ignore: \n{extension}")
        # print(f"Patterns to Ignore: \n{patterns}")

        # extracting metadata from DSSLM
        # response = SLMClient.from_config(config).run_query()

        config_dir = get_default_config_dir()
        config_file = config_dir / (config_name + ".json")
        if not config_file.exists():
            raise FileNotFoundError(f"The config file '{config_file}' does not exist.")

        with config_file.open("r") as f:
            config_dict = json.load(f)

        if config_dict.get("extract").get("localxplore"):
            if args.workspace is not None:
                if config_dict.get("paths").get("root"):
                    config_dict["paths"]["root"] = str(
                        os.path.normpath(Path(args.workspace))
                    )

        try:
            config = Config(name=config_name, **config_dict)
        except ValidationError as e:
            logging.error(e)
            sys.exit(1)

    Transformer.from_config(config=config).run_pipeline(
        args.workspace, args.filepaths, args.version
    )

    if config.transform.merge_framework_chunks and config.extract.frameworks:
        # concatenating all json chunks into a single json
        merged_data = []
        output_path = os.path.join(
            config.paths.root, config.paths.transform_output, "final_transform.json"
        )
        for filename in os.listdir(
            os.path.join(config.paths.root, config.paths.transform_output)
        ):
            if filename.endswith(".json"):
                file_path = os.path.join(
                    config.paths.root, config.paths.transform_output, filename
                )
                with open(file_path, "r", encoding="utf-8") as f:
                    try:
                        data = json.load(f)
                        if isinstance(data, list):
                            merged_data.extend(data)
                        else:
                            logging.info(
                                f"Skipping '{filename}' — does not contain a list."
                            )
                    except json.JSONDecodeError as e:
                        logging.info(f"Error decoding '{filename}': {e}")

        # Write the final merged list
        with open(output_path, "w", encoding="utf-8") as out_f:
            json.dump(clean_nans(merged_data), out_f, indent=2)
        logging.info(f"The extracted chunks are merged and same to {output_path}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
        logger.info("Program interrupted by user. Exiting gracefully. ✨")
