from transformers import PreTrainedTokenizer
import requests


class RemoteHFTokenizer(PreTrainedTokenizer):
    def __init__(self, api_url: str, **kwargs):
        self.api_url = api_url

        # Minimal vocab so HF doesn't crash
        self._vocab = {"[PAD]": 0, "[UNK]": 1, "[CLS]": 2, "[SEP]": 3}

        super().__init__(
            pad_token="[PAD]",
            unk_token="[UNK]",
            cls_token="[CLS]",
            sep_token="[SEP]",
            **kwargs,
        )

    def get_vocab(self):
        return self._vocab

    @property
    def vocab_size(self):
        return len(self._vocab)

    # ---- required ----
    def _tokenize(self, text):
        data = self._call_api(text)
        return data.get("tokens", [])

    def _convert_token_to_id(self, token):
        return self._vocab.get(token, self._vocab["[UNK]"])

    def _convert_id_to_token(self, idx):
        for tok, tokid in self._vocab.items():
            if tokid == idx:
                return tok
        return "[UNK]"

    # ---- optional (override encode/call for convenience) ----
    def encode(self, text, **kwargs):
        data = self._call_api(text)
        return data.get("ids", [])

    def __call__(self, text, **kwargs):
        data = self._call_api(text)
        ids = data.get("ids", [])
        mask = data.get("attention_mask", [1] * len(ids))
        return {"input_ids": ids, "attention_mask": mask}

    def _call_api(self, text):
        try:
            r = requests.post(self.api_url, json={"input": text}, timeout=8)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            raise RuntimeError(f"Remote tokenizer failed: {e}")
