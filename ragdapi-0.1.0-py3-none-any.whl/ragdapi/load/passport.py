import requests
import httpx
from urllib.parse import quote_plus
from requests.cookies import cookiejar_from_dict
import logging
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


class SSOPassport:
    def __init__(self) -> None:
        """Class to interact with 3DS passport

        Args:
            cipher (AESCipherCBC, optional): a cipher to decrypt the password. You can completely ignore this argument. Defaults to None.
        """
        self.init_client()

    def set_cookies(self, cookies: dict):
        self.client.cookies = cookiejar_from_dict(cookies)

    def get_cookies(self) -> dict:
        return self.client.cookies

    def get_first_cookie(self, cookies: httpx.Cookies, name: str):
        for cookie in cookies.jar:
            if cookie.name == name:
                return cookie.value
        return None

    def get_first_cookie_by_prefix(self, cookies: httpx.Cookies, name: str):
        for cookie in cookies.jar:
            if cookie.name.startswith(name):
                return cookie.value
        return None

    def init_client(self, request_cookies: dict = {}):
        self.client = httpx.Client(follow_redirects=False, cookies=request_cookies)

    def set_passport_url(self, service_url: str) -> str:
        r = self.client.get(service_url)
        if r.status_code == requests.codes["ok"]:
            # Already authenticated
            raise Exception("You're not supposed to be authenticated at this point")
        elif r.status_code != requests.codes["found"]:
            raise Exception(
                f"HTTP redirection is not the correct status, it is {r.status_code}"
            )

        redirect = r.headers["Location"]
        self.passport_url = str(redirect.split("/login?")[0])
        self.passport_domain = urlparse(self.passport_url).netloc.split(":")[0]

    def get_service_ticket(self, service_url: str):
        url = f"{self.passport_url}/login?service={quote_plus(service_url)}&xrequestedwith=xmlhttprequest"
        r = self.client.get(url, headers={"Accept": "application/json"})
        if r.status_code == requests.codes["unauthorized"]:
            return None
        if r.status_code != requests.codes["ok"]:
            raise Exception(
                f"HTTP Get Service Ticket is not the correct status, it is {r.status_code}"
            )
        content = r.json()
        if "access_token" in content:
            return content["access_token"]
        else:
            return None

    def authenticate(
        self, service_url: str, ds_tenant: str, username: str, password: str
    ) -> str:
        r = self.client.get(
            f"{self.passport_url}/login?action=get_auth_params",
            headers={"Accept": "application/json"},
        )
        if r.status_code != requests.codes["ok"]:
            raise Exception(
                f"HTTP Get Login Ticket is not the correct status, it is {r.status_code}"
            )
        lt_tmp = r.json()["lt"]
        logger.debug(f"HTTP Login Ticket is {lt_tmp}")

        data = {
            "lt": lt_tmp,
            "username": username,
            "password": password,
            "rememberMe": "On",
        }

        url = f"{self.passport_url}/login"
        r = self.client.post(
            url,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=10,
        )
        if r.status_code != requests.codes["found"]:
            raise Exception(
                f"Login status is not the correct status, it is {r.status_code}"
            )
        castgc_cookie_name = "CASTGC_" + ds_tenant.lower()
        castgc = self.get_first_cookie(r.cookies, castgc_cookie_name)
        if castgc is None:
            castgc_cookie_name = "CASTGC"
            castgc = self.get_first_cookie_by_prefix(r.cookies, castgc_cookie_name)
            if castgc is None:
                raise Exception(
                    f"No CASTGC Ticket found in response, Authentication failed for username {username} on {self.passport_url}"
                )

        st = self.get_service_ticket(service_url)
        if st is None:
            return None
        logger.debug(
            f"Got CASTGC {castgc} and Service Ticket {st} for username {username} on {self.passport_url}"
        )

        r = self.client.get(service_url, params={"ticket": st})
        return st

    def run(
        self,
        service_url: str,
        ds_tenant: str,
        username: str,
        password: str,
        asynchronous: bool = False,
    ) -> httpx.Client:
        """Creates a httpx client with passport authentication cookies

        :param service_url (str): the url of the service you want to connect to. This is only used to get the corresping passport url.
        :param username (str): username
        :param password (str): password
        :return: httpx.Client: httpx client with passport authentication cookies
        """
        self.init_client()
        self.set_passport_url(service_url)
        self.authenticate(service_url, ds_tenant, username, password)
        if asynchronous:
            client = httpx.AsyncClient(
                cookies=self.client.cookies,
                follow_redirects=True,
                transport=httpx.AsyncHTTPTransport(retries=3),
            )
        else:
            client = httpx.Client(
                cookies=self.client.cookies,
                follow_redirects=True,
                transport=httpx.HTTPTransport(retries=3),
            )
        return client
