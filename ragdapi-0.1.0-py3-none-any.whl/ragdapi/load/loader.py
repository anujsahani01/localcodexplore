import re
import json
import ijson
import time
import logging
from tqdm import tqdm
from pathlib import Path
from typing import List, Dict, Any, Union, Generator

from httpx import (
    Response,
    RequestError,
    RemoteProtocolError,
    ReadTimeout,
    HTTPStatusError,
)

from ragdapi.load.endpoint import Endpoint
from ragdapi.load.passport import SSOPassport
from ragdapi.schemas.config import Config

logger = logging.getLogger(__name__)


class Loader:
    """Loads pre-mapped JSON chunks into a RAG datasource via authenticated REST calls.

    The loader supports:
    * **Checkpointing** - progress is persisted after each successful batch so
      that interrupted runs can resume where they left off.
    * **Rate control** - an adaptive rate-limiter reduces throughput on 507
      (Insufficient Storage) and gradually recovers after successful batches.
    * **Large-file streaming** - files exceeding ``streaming_file_size_limit_mb``
      are streamed with ``ijson`` instead of being loaded fully into memory.

    All tunable parameters (batch sizes, retry budgets, rate-control knobs)
    are read from :pyclass:`~ragdapi.schemas.load.LoadArgs` via the
    ``Config`` object, allowing per-run overrides through config files.
    """

    _INGEST_ENDPOINT = (
        "/api/v1/datasources/{datasource}/ingest?xrequestedwith=xmlhttprequest"
    )
    _DATASOURCE_ENDPOINT = "/api/v1/datasources/{datasource}"
    _MONITOR_ENDPOINT = "/api/v1/datasources/{datasource}/monitor"
    _MODELS_ENDPOINT = "/api/v1/datasources/models"
    _COUNT_ENDPOINT = (
        "/widgetserver/endpoint_consumption/count_all?SCHEMANAME={datasource}_data_1"
    )

    def __init__(self, config: Config) -> None:
        if config.load is None:
            raise ValueError(
                "LoadArgs (config.load) must be provided to use the Loader."
            )
        if config.paths is None:
            raise ValueError(
                "Paths (config.paths) must be provided to use the Loader."
            )

        self.config = config
        self._load_args = config.load

        self.service_url = self._load_args.rag_service_url
        self.ds_tenant = self._load_args.ds_tenant
        self.username = self._load_args.username
        self.password = self._load_args.password
        self.datasourcename = self._load_args.datasourcename

        self.checkpoint_file = config.paths.root / self._build_checkpoint_filename()
        self.files_to_process = self._discover_files()

        # Rate control
        self.max_chunks_per_second = self._load_args.chunks_per_second
        self.current_chunks_per_second = self.max_chunks_per_second

        logger.info(f"Loader initialized with config: {self.config.name}")
        logger.info(
            f"Rate control initialized: {self.current_chunks_per_second} chunks/sec "
            f"(max: {self.max_chunks_per_second})"
        )

        # Authenticate and build reusable endpoint
        self.client = self._authenticate()
        self._endpoint = self._create_endpoint()

        # Load checkpoint (if any)
        checkpoint = self._load_checkpoint()
        self.current_file_path: str | None = checkpoint.get("current_file_path")
        self.current_chunk_offset: int = checkpoint.get("current_chunk_offset", 0)

    def close(self) -> None:
        """Close the underlying HTTP client and release its connection pool."""
        if self.client:
            self.client.close()

    def __enter__(self) -> "Loader":
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()

    @classmethod
    def from_config(cls, config: Config) -> "Loader":
        return cls(config)

    def load(self) -> None:
        """Load chunks in batches across all files."""
        self._monitor()
        start_idx = self._get_file_start_index()
        file_path: Path | None = None

        try:
            for file_idx in tqdm(
                range(start_idx, len(self.files_to_process)),
                desc="Loading documents",
            ):
                file_path = self.files_to_process[file_idx]
                logger.info(f"Processing file: {file_path}")

                # Only apply checkpoint offset for the first file being resumed
                resume_from_chunk = (
                    self.current_chunk_offset if file_idx == start_idx else 0
                )

                chunks_or_generator = self._load_chunks_from_file(file_path)

                if isinstance(chunks_or_generator, list):
                    self._process_small_file(
                        chunks_or_generator, file_path, resume_from_chunk
                    )
                else:
                    self._process_streaming_file(
                        chunks_or_generator, file_path, resume_from_chunk
                    )

                self.current_chunk_offset = 0

            self._clear_checkpoint()

        except Exception as exc:
            logger.error(
                f"Critical error in the load process"
                f"{f' for {file_path}' if file_path else ''}: {exc}",
                exc_info=True,
            )
            raise

    def _process_small_file(
        self,
        chunks: List[Dict[str, Any]],
        file_path: Path,
        resume_from_chunk: int,
    ) -> None:
        """Process a file whose chunks fit in memory."""
        batch_size = self._load_args.loading_batch_size
        logger.info(
            f"Resuming from chunk {resume_from_chunk}/{len(chunks)} "
            f"for small file: {file_path}"
        )

        for i in range(resume_from_chunk, len(chunks), batch_size):
            batch = chunks[i : i + batch_size]
            chunk_offset = i + len(batch)
            elapsed = self._timed_ingest(batch, file_path, chunk_offset)
            self._rate_limit_sleep(len(batch), elapsed)

    def _process_streaming_file(
        self,
        chunks_generator: Generator[List[Dict[str, Any]], None, None],
        file_path: Path,
        resume_from_chunk: int,
    ) -> None:
        """Process a large file that is being streamed in batches."""
        batch_size = self._load_args.loading_batch_size
        global_chunk_offset = 0

        logger.info(
            f"Resuming from chunk {resume_from_chunk} for large file: {file_path}"
        )

        for chunk_batch in chunks_generator:
            # Skip batches already processed
            if global_chunk_offset + len(chunk_batch) <= resume_from_chunk:
                global_chunk_offset += len(chunk_batch)
                continue

            start_position = max(0, resume_from_chunk - global_chunk_offset)

            for i in range(start_position, len(chunk_batch), batch_size):
                batch = chunk_batch[i : i + batch_size]
                chunk_offset = global_chunk_offset + i + len(batch)
                elapsed = self._timed_ingest(batch, file_path, chunk_offset)
                self._rate_limit_sleep(len(batch), elapsed)

            global_chunk_offset += len(chunk_batch)
            resume_from_chunk = 0  # Only skip on first iteration

    def _timed_ingest(
        self,
        batch: List[Dict[str, Any]],
        file_path: Path,
        chunk_offset: int,
    ) -> float:
        """Ingest a batch and return the elapsed wall-clock time in seconds."""
        start = time.monotonic()
        self._retry_ingest_request(batch, file_path, chunk_offset)
        return time.monotonic() - start

    def _rate_limit_sleep(self, chunk_count: int, elapsed: float) -> None:
        """Sleep only the remaining time needed to maintain the target rate.

        Args:
            chunk_count: Number of chunks that were just sent.
            elapsed: Wall-clock time (seconds) the request already consumed.
        """
        if self.current_chunks_per_second <= 0:
            return
        expected_duration = chunk_count / self.current_chunks_per_second
        remaining = expected_duration - elapsed
        if remaining > 0:
            logger.debug(
                f"Rate limiting: sleeping {remaining:.3f}s "
                f"(request took {elapsed:.3f}s) for {chunk_count} chunks "
                f"(rate: {self.current_chunks_per_second:.1f} chunks/sec)"
            )
            time.sleep(remaining)

    def _reduce_rate(self) -> None:
        """Reduce the ingestion rate after a 507 Insufficient Storage error."""
        previous_rate = self.current_chunks_per_second
        self.current_chunks_per_second = max(
            self._load_args.min_chunks_per_second,
            self.current_chunks_per_second * self._load_args.rate_reduction_factor,
        )
        logger.warning(
            f"Rate reduced from {previous_rate:.1f} to "
            f"{self.current_chunks_per_second:.1f} chunks/sec"
        )

    def _recover_rate(self) -> None:
        """Gradually recover the ingestion rate after a successful request."""
        if self.current_chunks_per_second < self.max_chunks_per_second:
            previous_rate = self.current_chunks_per_second
            self.current_chunks_per_second = min(
                self.max_chunks_per_second,
                self.current_chunks_per_second * self._load_args.rate_recovery_factor,
            )
            if self.current_chunks_per_second != previous_rate:
                logger.info(
                    f"Rate recovered from {previous_rate:.1f} to "
                    f"{self.current_chunks_per_second:.1f} chunks/sec"
                )

    def _authenticate(self):
        """Create a new SSO-authenticated HTTP client."""
        return SSOPassport().run(
            service_url=self.service_url,
            ds_tenant=self.ds_tenant,
            username=self.username,
            password=self.password,
            asynchronous=False,
        )

    def _reauthenticate(self) -> None:
        """Close the current SSO client and create a fresh one."""
        logger.info("Reauthenticating SSO session...")
        old_client = self.client
        self.client = self._authenticate()
        self._endpoint = self._create_endpoint()
        old_client.close()

    def _is_auth_error(self, response: Response) -> bool:
        """Return True if the response indicates an authentication failure."""
        if "login" in response.url.path:
            return True
        if response.status_code == 400 and "invalid_grant" in response.text:
            return True
        return False

    def _retry_ingest_request(
        self, batch: List[Dict[str, Any]], file_path: Path, chunk_offset: int
    ) -> bool:
        """Send a single batch to the ingest endpoint with retry logic.

        All transient failures are retried with exponential backoff.  If
        retries are exhausted the failure is logged and the method returns
        ``False`` so the pipeline can continue with the next batch.

        Categories of failure handled:

        * **Auth errors** (login redirect / ``invalid_grant``) -
          reauthenticate and retry.
        * **507 Insufficient Storage** - reduce rate, wait with its own
          exponential backoff, and retry on a dedicated retry budget that
          does not consume general retries.
        * **Transient errors** (``HTTPStatusError``, ``RemoteProtocolError``,
          ``ReadTimeout``, ``RequestError``) - retry with exponential backoff.

        Args:
            batch: The list of chunk dicts to ingest.
            file_path: Path to the source file (for logging / checkpoint).
            chunk_offset: Absolute chunk position *after* this batch succeeds,
                          used to persist a batch-size-agnostic checkpoint.

        Returns:
            ``True`` if the batch was ingested successfully, ``False`` if all
            retries were exhausted.
        """
        retries = self._load_args.max_retries
        backoff_time = self._load_args.initial_backoff_seconds
        insufficient_storage_retries = self._load_args.max_507_retries
        insufficient_storage_wait = self._load_args.insufficient_storage_wait

        ingest_url = self._INGEST_ENDPOINT.format(datasource=self.datasourcename)

        while retries > 0:
            try:
                response = self._endpoint.make_post_request(ingest_url, batch)

                # --- Auth errors: reauthenticate and retry ---------------
                if self._is_auth_error(response):
                    self._reauthenticate()
                    retries -= 1
                    if retries == 0:
                        logger.error(
                            f"Max retries reached for {file_path}, "
                            f"chunk_offset {chunk_offset}. "
                            f"Still redirected to login."
                        )
                        break
                    logger.warning(
                        f"Auth error for {file_path}, chunk_offset {chunk_offset}. "
                        f"Retries left: {retries}. Retrying in {backoff_time}s."
                    )
                    time.sleep(backoff_time)
                    backoff_time *= 2
                    continue

                # --- 507 Insufficient Storage: dedicated retry budget ----
                if response.status_code == 507:
                    insufficient_storage_retries -= 1
                    self._reduce_rate()
                    if insufficient_storage_retries <= 0:
                        logger.error(
                            f"Max 507 retries reached for {file_path}, "
                            f"chunk_offset {chunk_offset}. "
                            f"Server storage still insufficient."
                        )
                        break
                    logger.warning(
                        f"507 Insufficient Storage for {file_path}, "
                        f"chunk_offset {chunk_offset}. "
                        f"Waiting {insufficient_storage_wait}s for space to free up. "
                        f"Retries left: {insufficient_storage_retries}. "
                        f"Rate: {self.current_chunks_per_second:.1f} chunks/sec."
                    )
                    time.sleep(insufficient_storage_wait)
                    insufficient_storage_wait *= 2
                    continue

                # --- Any other non-2xx: raise so it is not silently lost -
                response.raise_for_status()

                # --- Success --------------------------------------------
                self._log_response(response)
                self._save_checkpoint(file_path, chunk_offset)
                self._recover_rate()
                return True

            except (HTTPStatusError, RemoteProtocolError, ReadTimeout, RequestError) as exc:
                retries, backoff_time = self._handle_retryable_error(
                    exc, file_path, chunk_offset, retries, backoff_time
                )

        # All retries exhausted - log clearly and continue the pipeline.
        logger.error(
            f"FAILED TO INGEST batch for {file_path}, "
            f"chunk_offset {chunk_offset} (batch size: {len(batch)}). "
            f"These chunks were skipped after exhausting all retries."
        )
        return False

    def _handle_retryable_error(
        self,
        exc: Exception,
        file_path: Path,
        chunk_offset: int,
        retries: int,
        backoff_time: float,
    ) -> tuple[int, float]:
        """Log a retryable error, sleep, and return updated retry state."""
        retries -= 1
        label = type(exc).__name__
        logger.warning(
            f"{label} while processing {file_path}, "
            f"chunk_offset {chunk_offset}: {exc}. "
            f"Retries left: {retries}."
        )
        if retries == 0:
            logger.error(
                f"Max retries reached for {file_path}, "
                f"chunk_offset {chunk_offset}. Last error: {exc}."
            )
        else:
            logger.info(f"Retrying in {backoff_time}s.")
            time.sleep(backoff_time)
        return retries, backoff_time * 2

    def _discover_files(self) -> List[Path]:
        """Resolve the list of JSON files to process from the map output path."""
        map_output_path = self.config.paths.root / self.config.paths.map_output
        if map_output_path.is_dir():
            logger.debug(f"Map output path is a directory: {map_output_path}")
            files = sorted(map_output_path.glob("*.json"))
            if not files:
                raise FileNotFoundError(
                    f"No JSON files found in directory: {map_output_path}"
                )
            return files

        logger.debug(f"Map output path is a single file: {map_output_path}")
        return [map_output_path]

    def _load_chunks_from_file(
        self, file_path: Path
    ) -> Union[List[Dict[str, Any]], Generator[List[Dict[str, Any]], None, None]]:
        """Load chunks from a file, streaming if the file exceeds the size threshold."""
        file_size = file_path.stat().st_size
        max_memory_bytes = self._load_args.streaming_file_size_limit_mb * 1024**2

        if file_size < max_memory_bytes:
            return self._load_all_chunks(file_path)
        return self._stream_chunks_from_file(file_path)

    def _load_all_chunks(self, file_path: Path) -> List[Dict[str, Any]]:
        """Load all chunks from the file if it fits into memory."""
        try:
            with file_path.open("r", encoding="utf-8") as f:
                chunks = json.load(f)
                logger.debug(f"Loaded {len(chunks)} chunks from {file_path}")
                return chunks
        except (FileNotFoundError, json.JSONDecodeError) as e:
            logger.error(f"Could not load chunks from {file_path}: {e}")
            raise

    def _stream_chunks_from_file(
        self, file_path: Path
    ) -> Generator[List[Dict[str, Any]], None, None]:
        """Stream chunks from a large JSON file in batches."""
        batch_size = self._load_args.reading_batch_size
        chunks: List[Dict[str, Any]] = []
        try:
            with file_path.open("r", encoding="utf-8") as f:
                for item in ijson.items(f, "item"):
                    chunks.append(item)
                    if len(chunks) >= batch_size:
                        logger.debug(
                            f"Streaming {len(chunks)} chunks from {file_path}"
                        )
                        yield chunks
                        chunks = []
                if chunks:
                    yield chunks
        except (FileNotFoundError, ValueError) as e:
            logger.error(f"Could not load chunks from {file_path}: {e}")
            raise

    def _build_checkpoint_filename(self) -> str:
        """Build a unique, deterministic checkpoint filename.

        If the user provided an explicit ``checkpoint_file_name`` in config it
        is returned as-is.  Otherwise the name is derived from
        ``config.name`` and ``datasourcename`` so that parallel runs with
        different configs never collide.

        All filesystem-unsafe characters are replaced with underscores and
        consecutive underscores are collapsed.
        """
        explicit = self._load_args.checkpoint_file_name
        if explicit is not None:
            return explicit

        raw = f"loader_checkpoint_{self.config.name}_{self.datasourcename}"
        sanitized = re.sub(r"[^\w\-]+", "_", raw).strip("_")
        return f"{sanitized}.json"

    def _save_checkpoint(self, file_path: Path, chunk_offset: int | None = None) -> None:
        """Save the current file path and the absolute chunk offset to the checkpoint.

        Args:
            file_path: Path to the file currently being processed.
            chunk_offset: The number of chunks successfully ingested so far in
                          this file.  Resuming starts from this position,
                          regardless of the batch size in use.
        """
        checkpoint_data: Dict[str, Any] = {
            "current_file_path": str(file_path),
        }
        if chunk_offset is not None:
            checkpoint_data["current_chunk_offset"] = chunk_offset
        with self.checkpoint_file.open("w", encoding="utf-8") as f:
            json.dump(checkpoint_data, f)
        logger.debug(f"Checkpoint saved: {checkpoint_data}")

    def _load_checkpoint(self) -> Dict[str, Any]:
        """Load the last checkpoint if it exists."""
        if self.checkpoint_file.exists():
            with self.checkpoint_file.open("r", encoding="utf-8") as f:
                checkpoint_data = json.load(f)
            logger.info(f"Checkpoint loaded: {checkpoint_data}")
            return checkpoint_data
        return {"current_file_path": None, "current_chunk_offset": 0}

    def _get_file_start_index(self) -> int:
        """Find the index of the file to start from based on the checkpoint."""
        if self.current_file_path:
            checkpoint_path = Path(self.current_file_path)
            for idx, file_path in enumerate(self.files_to_process):
                if file_path == checkpoint_path:
                    return idx
        return 0

    def _clear_checkpoint(self) -> None:
        """Clear the checkpoint after all files are processed."""
        if self.checkpoint_file.exists():
            self.checkpoint_file.unlink()
        logger.info("Checkpoint cleared")

    def _create_endpoint(self) -> Endpoint:
        """Create a reusable Endpoint bound to the current client."""
        return Endpoint(service_url=self.service_url, client=self.client)

    def _log_response(self, response: Response) -> None:
        """Log a successful API response."""
        try:
            body = json.dumps(response.json(), indent=4)
        except (json.JSONDecodeError, ValueError):
            body = response.text
        logger.info(
            f"Call with status_code={response.status_code} "
            f"and body response:\n{body}"
        )

    def _check_models(self) -> None:
        """Log the list of available models from the RAG service."""
        response = self._endpoint.make_get_request(self._MODELS_ENDPOINT)
        self._log_response(response)

    def _check_datasource(self) -> None:
        """Log the current datasource configuration."""
        url = self._DATASOURCE_ENDPOINT.format(datasource=self.datasourcename)
        response = self._endpoint.make_get_request(url)
        self._log_response(response)

    def _count_doc(self) -> None:
        """Log the total document count for the datasource."""
        url = self._COUNT_ENDPOINT.format(datasource=self.datasourcename)
        response = self._endpoint.make_get_request(url)
        self._log_response(response)

    def _monitor(self) -> None:
        """Log the datasource monitor status."""
        url = self._MONITOR_ENDPOINT.format(datasource=self.datasourcename)
        response = self._endpoint.make_get_request(url)
        self._log_response(response)
