import httpx
from ragdapi.load.passport import SSOPassport


class Endpoint:
    def __init__(self, service_url: str, client: httpx.Client):
        """Initializes the Endpoint with a service URL.

        :param service_url (str): The base URL of the service.
        :client (httpx.Client): httpx client with authentication cookies
        """
        self.service_url = service_url
        self.client = client

    def make_get_request(self, url: str) -> httpx.Response:
        """Makes a GET request using the provided httpx client

        :param url (str): URL to make the request to
        :return: httpx.Response: The response object from the GET request
        """
        response = self.client.get(self.service_url + url)
        return response

    def make_post_request(self, url: str, body: dict) -> httpx.Response:
        """Makes a POST request using the provided httpx client

        :param client (httpx.Client): httpx client with authentication cookies
        :param url (str): URL to make the request to
        :param body (dict): Body of the POST request
        :return: httpx.Response: The response object from the POST request
        """
        response = self.client.post(
            self.service_url + url, json=body, follow_redirects=True
        )
        return response
