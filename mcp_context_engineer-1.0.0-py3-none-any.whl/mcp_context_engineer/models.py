# mcp_package/mcp_context_engineer/models.py
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any

class ProcessRequest(BaseModel):
    """Payload sent by the UI when a user asks a question."""
    workspace: str = Field(..., description="Workspace identifier")
    version: str = Field(..., description="Version of the workspace")
    query: str = Field(..., description="Raw user query")


class ClarifyRequest(BaseModel):
    """Payload sent after the UI receives a clarification question."""
    workspace: str = Field(..., description="Workspace identifier")
    version: str = Field(..., description="Version of the workspace")
    original_query: str = Field(..., description="The query that triggered clarification")
    clarification_answer: str = Field(..., description="User's answer to the clarification question")
    # the orchestrator will re‑run from the scoring step, so we keep the
    # intermediate data that was already produced
    intermediate_state: Optional[Dict[str, Any]] = Field(
        None,
        description="Optional cached data from previous run (populated by the server)."
    )


class ClarifyResponse(BaseModel):
    clarification_needed: bool = Field(True, description="Always true for this response")
    question: str = Field(..., description="Question that should be shown to the user")
    original_query: str
    workspace: str
    version: str

    # The whole intermediate context (everything up to the Scorer) is
    # serialized as JSON so the client can send it back without recomputing.
    intermediate_state: Optional[Dict[str, Any]] = Field(
        None,
        description="Cached pipeline state send back to /clarify to avoid re-running previous tools"
    )


class ProcessResponse(BaseModel):
    """Returned when the pipeline finishes successfully."""
    enriched_query: str = Field(..., description="Final enriched query that will be sent to the retrieval service")
    confidence: float = Field(..., description="Confidence score (0-1)")



class ClarifyResponse(BaseModel):
    """Returned when the pipeline needs more information from the user."""
    clarification_needed: bool = Field(True, description="Always true for this response")
    question: str = Field(..., description="Question that should be shown to the user")
    # we echo back the original request so the UI can keep context
    original_query: str
    workspace: str
    version: str