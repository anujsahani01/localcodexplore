# mcp_package/mcp_context_engineer/server.py
from fastapi import APIRouter, HTTPException
from .models import ProcessRequest, ProcessResponse, ClarifyRequest, ClarifyResponse
from .orchestrator import ContextEngineer
import asyncio

router = APIRouter(prefix="/contextengineer", tags=["ContextEngineer"])

# ----------------------------------------------------------------------
# Main processing endpoint – runs the whole chain
# ----------------------------------------------------------------------
@router.post("/process", response_model=ProcessResponse | ClarifyResponse)
async def process(request: ProcessRequest):
    """
    Expected JSON:
    {
        "workspace": "...",
        "version": "...",
        "query": "user question"
    }
    """
    engineer = ContextEngineer()
    result = engineer.run(
        raw_query=request.query,
        workspace=request.workspace,
        version=request.version,
    )

    # --------------------------------------------------------------
    # If the Scorer decided we need clarification, return that payload
    # --------------------------------------------------------------
    if result.get("clarification", {}).get("needed"):
        return ClarifyResponse(
            clarification_needed=True,
            question=result["clarification"]["question"],
            original_query=request.query,
            workspace=request.workspace,
            version=request.version,
            intermediate_state=result,          # <-- send cached state

        )

    # --------------------------------------------------------------
    # Otherwise we have a confident enriched query – return it
    # --------------------------------------------------------------
    return ProcessResponse(
        enriched_query=result["final_story"],
        confidence=result["confidence"],
    )


# ----------------------------------------------------------------------
# /clarify – receives the user’s answer and re‑scores
# ----------------------------------------------------------------------
@router.post("/clarify", response_model=ProcessResponse | ClarifyResponse)
async def clarify(request: dict):
    """
    Expected JSON:
    {
        "workspace": "...",
        "version": "...",
        "original_query": "...",
        "clarification_answer": "...",
        "intermediate_state": { … }   # the dict we sent back in /process
    }
    """
    if not request.intermediate_state:
        raise HTTPException(
            status_code=400,
            detail="Missing intermediate_state – cannot continue without cached data."
        )
    engineer = ContextEngineer()
    result = engineer.continue_from_score(
        original_query=request["original_query"],
        workspace=request["workspace"],
        version=request["version"],
        clarification_answer=request["clarification_answer"],
        cached_state=request["intermediate_state"],
    )

    if result.get("clarification", {}).get("needed"):
        return ClarifyResponse(
            clarification_needed=True,
            question=result["clarification"]["question"],
            original_query=request["original_query"],
            workspace=request["workspace"],
            version=request["version"],
            intermediate_state=result,
        )

    return ProcessResponse(
        enriched_query=result["final_story"],
        confidence=result["confidence"],
    )


# Defining some triggers
# ----------------------------------------------------------------------
#  /start – fire‑and‑forget trigger for the indexing endpoint
# ----------------------------------------------------------------------

@router.post("/start")
async def start_indexing(payload: dict):
    """
    Payload:
    {
        "workspacepath": "...",   # absolute or relative path on the server
        "version": "1"           # optional - defaults to 100 in the existing endpoint
    }
    """
    from codebase_context_provider.routes.routes import startIndexing  # import the existing handler

    # The original `startIndexing` expects query‑params, so we call it
    # directly with the same signature.  FastAPI will handle the async
    # nature for us.
    # We do NOT await the result – we want to return immediately.
    asyncio.create_task(
        startIndexing(
            workspacepath=payload.get("workspacepath"),
            version=payload.get("version")
        )
    )

    # Return immediately – the indexing will run in the background.
    return {"response": "Indexing started"}


# ----------------------------------------------------------------------
# /status – one‑shot JSON status (non‑SSE) for the UI
# ----------------------------------------------------------------------
@router.get("/status")
async def indexing_status(workspacepath: str | None = None, version: str | None = None):
    """
    Returns the latest indexing status as a simple JSON object.
    If `workspacepath`/`version` are omitted we fall back to the global
    status (same logic as the SSE endpoint).
    """
    
    from codebase_context_provider.routes.routes import get_global_indexing_status, EventStore

    if not workspacepath or not version:
        # Global status – just a string like "indexing running"
        return {"status": get_global_indexing_status()}

    # Try to fetch the latest event for this workspace/version
    latest = EventStore.getLatestEvent(workspacepath, version)
    if latest:
        return {"status": latest.model_dump()}

    # No event yet – report idle
    return {"status": "indexing not started"}