# mcp_package/mcp_context_engineer/orchestrator.py
from __future__ import annotations
from typing import Dict, Any, List, Type
from .tools import (
    BaseTool,
    ContextEngineeringTool,
    CodeMapperTool,
    StoryTellerTool,
    ScorerTool,
)


# Ordered list of tool classes – the orchestrator walks this list.
TOOL_CHAIN: List[Type[BaseTool]] = [
    ContextEngineeringTool,
    CodeMapperTool,
    StoryTellerTool,
    ScorerTool,
]



# Expected context schema (informal contract)
# {
#   raw_query: str
#   workspace: str
#   version: str
#   enriched_query: str
#   intent: str
#   entities: list
#   requirements: list
#   repo_map: dict
#   final_story: str
#   confidence: float
#   clarification: {
#       needed: bool
#       question: str (optional)
#   }
# }


class ContextEngineer:
    """
    Executes the tool chain.  The public API is `run` (first run) and
    `continue_from_score` (used after a clarification answer).
    """

    def __init__(self, threshold: float = 0.7):
        self.threshold = threshold

    def _run_chain(self, initial_context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Walk through TOOL_CHAIN sequentially, feeding the mutable `context`
        dict from one tool to the next.
        """
        context = initial_context.copy()
        for tool_cls in TOOL_CHAIN:
            # instantiate with the current context
            if tool_cls is ScorerTool:
                tool = tool_cls(context, threshold=self.threshold)
            else:
                tool = tool_cls(context)

            context = tool.run()

            # After running the scorer, validate it set the required fields
            if tool_cls is ScorerTool:
                if "confidence" not in context:
                    raise ValueError("ScorerTool must set 'confidence'")
                if "clarification" not in context:
                    raise ValueError("ScorerTool must set 'clarification'")

            # If a tool signals that we must stop early (only Scorer does this)
            if context.get("clarification", {}).get("needed"):
                break

        return context

    # ------------------------------------------------------------------
    # Public entry‑point used by the `/process` endpoint
    # ------------------------------------------------------------------
    def run(self, raw_query: str, workspace: str, version: str) -> Dict[str, Any]:
        """
        Starts the pipeline from the very first tool.
        Returns the full context dict (including possible clarification data).
        """
        initial = {
            "raw_query": raw_query,
            "workspace": workspace,
            "version": version,
        }
        return self._run_chain(initial)

    # ------------------------------------------------------------------
    # Public entry‑point used by the `/clarify` endpoint
    # ------------------------------------------------------------------
    def continue_from_score(
        self,
        original_query: str,
        workspace: str,
        version: str,
        clarification_answer: str,
        cached_state: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        The user answered the clarification question.  We preserve all context
        that was already computed by the pipeline and layer the clarification
        answer on top before re-running only the Scorer.
        """

        # Start from the full cached state so no computed field is lost.
        new_context = cached_state.copy()

        # Merge the clarification answer into raw_query so the scorer's
        # query-clarity rule sees the enriched user input.
        new_context["raw_query"] = (
            f"{original_query}\n\nUser clarification: {clarification_answer}"
        )

        # Append the answer to the enriched_query as well.
        previous_enriched = cached_state.get("enriched_query", original_query)
        new_context["enriched_query"] = (
            f"{previous_enriched}\nClarification: {clarification_answer}"
        )

        # Patch final_story if it is a dict (produced by StoryTeller).
        # We add the clarification to the supporting_context so the scorer
        # has the full picture when it evaluates context_completeness.
        previous_story = cached_state.get("final_story", {})
        if isinstance(previous_story, dict):
            updated_story = previous_story.copy()
            updated_story["supporting_context"] = (
                previous_story.get("supporting_context", "")
                + f"\n\nUser clarification: {clarification_answer}"
            )
            new_context["final_story"] = updated_story
        else:
            # Fallback for older plain-string stories.
            new_context["final_story"] = (
                f"{previous_story}\n\nUser clarification: {clarification_answer}"
            )

        # Carry workspace/version forward explicitly (they may not be in
        # cached_state if it came from a previous clarify round).
        new_context["workspace"] = workspace
        new_context["version"] = version

        # Re-run only the Scorer with the enriched context.
        scorer = ScorerTool(new_context, threshold=self.threshold)
        final_context = scorer.run()
        return final_context