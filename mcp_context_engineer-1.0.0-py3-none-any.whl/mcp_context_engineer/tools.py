# mcp_package/mcp_context_engineer/tools.py
from __future__ import annotations
from typing import Dict, Any, Optional
import json
import random

# Import actual tool implementations
from .tool_chain.context_engineer import ContextEngineer
from .tool_chain.code_mapper import CodeMapperTool as ActualCodeMapper
from .tool_chain.stroy_telling import StoryTellerTool as ActualStoryTeller  
from .tool_chain.scorer import ScorerTool as ActualScorer

# ----------------------------------------------------------------------
# Base class – every tool inherits from this and implements `run`.
# ----------------------------------------------------------------------
class BaseTool:
    """
    Base class for all tools in the pipeline.

    Each tool:
    - Consumes context
    - Produces new keys into context
    - Declares structured metadata for orchestration
    """

    name: str = "BaseTool"
    description: str = "Abstract base tool"
    details: Dict[str, Any] = {
        "inputs": [],
        "outputs": [],
        "depends_on": [],
        "stage": "base",
    }
    prev_tool: Optional[str] = None
    next_tool: Optional[str] = None
 
    def __init__(self, context: Dict[str, Any] | None = None):
        # `context` holds data produced by previous tools
        self.context = context or {}

    def run(self) -> Dict[str, Any]:
        """Override in subclasses - must return a dict that will be passed on."""
        raise NotImplementedError

    def _log(self, msg: str) -> None:
        # Simple stdout logging – replace with proper logger if needed
        print(f"[{self.name}] {msg}")

# ----------------------------------------------------------------------
# Context Engineering Tool
# ----------------------------------------------------------------------
class ContextEngineeringTool(BaseTool):
    name = "ContextEngineering"
    description = ( 
        "Enriches the raw user query, extracts intent & entities, " 
        "and adds any user-provided context." )
    details = {
        "inputs": ["raw_query"],
        "outputs": ["enriched_query", "intent", "entities"],
        "depends_on": [],
        "stage": "preprocessing",
    }
    prev_tool = None
    next_tool = "CodeMapper"

    def run(self) -> Dict[str, Any]:
        """
        WHEN TO USE:
        Use this as the FIRST step for any raw user query.

        INPUT:
        - raw_query (str): original user query

        OUTPUT:
        - enriched_query (str)
        - intent (str)
        - entities (list)

        DO NOT USE IF:
        - enriched_query already exists in context
        """

        self._log("Starting context engineering with actual implementation")
        
        # Use the actual ContextEngineer implementation
        context_engineer = ContextEngineer(self.context)
        updated_context = context_engineer.enrich_query()
        
        # Update our context with the results
        self.context.update(updated_context)
        
        self._log(f"Context engineering completed")
        return self.context


# ----------------------------------------------------------------------
# CodeMapper Tool
# ----------------------------------------------------------------------
class CodeMapperTool(BaseTool):
    name = "CodeMapper"
    description = (
        "Analyzes the repository structure, builds a map of folders/files "
        "and extracts language / extension information."
    )
    details = {
        "inputs": ["workspace"],
        "outputs": ["repo_map"],
        "depends_on": ["ContextEngineering"],
        "stage": "analysis",
    }
    prev_tool = "ContextEngineering"
    next_tool = "StoryTeller"

    def run(self) -> Dict[str, Any]:
        """
        WHEN TO USE:
        Use after RequirementGathering to understand repository structure.

        INPUT:
        - workspace (str)

        OUTPUT:
        - repo_map (dict)

        DO NOT USE IF:
        - workspace is not available
        """
        self._log("Building repository map with actual implementation")
        
        # Use the actual CodeMapper implementation
        code_mapper = ActualCodeMapper(self.context)
        updated_context = code_mapper.run()
        
        # Update our context with the results
        self.context = updated_context
        
        repo_map = self.context.get("repo_map", {})
        total_files = repo_map.get("total_files_in_workspace", 0)
        files_in_context = repo_map.get("files_in_context", 0)
        self._log(f"Repo map built: {files_in_context} of {total_files} files analyzed")
        return self.context


# ----------------------------------------------------------------------
# StoryTeller Tool
# ----------------------------------------------------------------------
class StoryTellerTool(BaseTool):
    name = "StoryTeller"
    description = (
        "Combines enriched query, requirements and repo map into a single "
        "rich narrative that will be used for retrieval."
    )
    details = {
        "inputs": ["enriched_query", "requirements", "repo_map"],
        "outputs": ["final_story"],
        "depends_on": ["CodeMapper"],
        "stage": "synthesis",
    }
    prev_tool = "CodeMapper"
    next_tool = "ScorerTool"

    def run(self) -> Dict[str, Any]:
        """
        WHEN TO USE:
        Use after CodeMapper to combine all context into a final narrative.

        INPUT:
        - enriched_query (str)
        - requirements (list)
        - repo_map (dict)

        OUTPUT:
        - final_story (str)

        DO NOT USE IF:
        - any of the required inputs are missing
        """
        self._log("Composing final story with actual implementation")
        
        # Use the actual StoryTeller implementation
        story_teller = ActualStoryTeller(self.context)
        updated_context = story_teller.run()
        
        # Update our context with the results
        self.context = updated_context
        
        final_story = self.context.get("final_story", {})
        strategy = final_story.get("strategy", "unknown") if isinstance(final_story, dict) else "string"
        chunks_count = len(final_story.get("retrieved_chunks", [])) if isinstance(final_story, dict) else 0
        
        self._log(f"Story composed: strategy={strategy}, chunks={chunks_count}")
        return self.context


# ----------------------------------------------------------------------
# Scorer Tool
# ----------------------------------------------------------------------
class ScorerTool(BaseTool):
    name = "ScorerTool"
    description = (
        "Assigns a confidence score (0-1) to the final story. "
        "If the score is below the threshold a clarification request is emitted."
    )
    details = {
        "inputs": ["final_story"],
        "outputs": ["confidence", "clarification"],
        "depends_on": ["StoryTeller"],
        "stage": "evaluation",
    }
    prev_tool = "StoryTeller"
    next_tool = None   # terminal tool

    def __init__(self, context: Dict[str, Any] | None = None, threshold: float = 0.7):
        super().__init__(context)
        self.threshold = threshold

    def run(self) -> Dict[str, Any]:
        """
        WHEN TO USE:
        Use as the FINAL step to evaluate the generated story.

        INPUT:
        - final_story (str)

        OUTPUT:
        - confidence (float)
        - clarification (dict)

        DO NOT USE IF:
        - final_story is missing
        """
        self._log("Scoring final story with actual implementation")
        
        # Use the actual Scorer implementation
        scorer = ActualScorer(self.context, threshold=self.threshold)
        updated_context = scorer.run()
        
        # Update our context with the results
        self.context = updated_context
        
        confidence = self.context.get("confidence", 0.0)
        clarification = self.context.get("clarification", {})
        needs_clarification = clarification.get("needed", False)
        
        self._log(f"Scoring completed: confidence={confidence:.3f}, clarification_needed={needs_clarification}")
        return self.context