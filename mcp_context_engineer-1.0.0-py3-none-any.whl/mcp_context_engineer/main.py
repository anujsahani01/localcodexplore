"""
Tool name	What it calls / does
process: 	Runs the tool-chain (ContextEngineer) locally and returns either a process result or a clarify payload.
clarify: 	Re-runs only the Scorer (using the cached state) and returns the same shape as process.
start:  	Calls the FastAPI POST /indexing endpoint asynchronously (fire-and-forget).
status: 	Calls the FastAPI GET /indexingstatus endpoint (non-SSE) and returns the JSON status.
retrieve:	Calls the FastAPI POST /retrieve endpoint, forwarding the enriched query.
"""

import os
import sys

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
os.chdir(BASE_DIR)
sys.path.insert(0, BASE_DIR)

print("Working dir:", os.getcwd())
# mcp_server/main.py
import os
import json
import logging
from datetime import datetime
from typing import Any, Dict

import httpx
from fastmcp import FastMCP  # <-- the FastMCP library you mentioned

# ----------------------------------------------------------------------
# Helper – simple logger (feel free to replace with your own)
# ----------------------------------------------------------------------
log = logging.getLogger("MCP")
log.setLevel(logging.INFO)
if not log.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    handler.setFormatter(formatter)
    log.addHandler(handler)

# ----------------------------------------------------------------------
# FastMCP application
# ----------------------------------------------------------------------
app = FastMCP(name="LocalXploreMCP")

# ----------------------------------------------------------------------
# Configuration – where the FastAPI server lives.
#     By default we assume it is already running on localhost:8000.
# ----------------------------------------------------------------------
# is used by your server to talk to another HTTP service
FASTAPI_URL = os.getenv("FASTAPI_URL", "http://localhost:8000")
client = httpx.AsyncClient(base_url=FASTAPI_URL, timeout=30.0)

# ----------------------------------------------------------------------
# TOOL:  process – runs the whole tool‑chain (Context → … → Scorer)
# ----------------------------------------------------------------------
async def process(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    WHEN TO USE:
    - Use this as the primary entry point for any new user query.
    - Always call this first before any other tool.
    - Use it to transform a raw query into an enriched, structured query.

    WHAT IT DOES:
    - Runs the full pipeline:
    ContextEngineering → RequirementGathering → CodeMapper → StoryTeller → Scorer
    - Determines whether the query is clear enough or needs clarification.

    INPUT:
    - query (string): raw user query
    - workspace (string): workspace identifier or path
    - version (string): index version

    OUTPUT:
    - If successful:
    {
        "next_step": "retrieve",
        "enriched_query": string,
        "confidence": float
    }

    - If clarification is needed:
    {
        "next_step": "clarify",
        "question": string,
        "original_query": string,
        "workspace": string,
        "version": string,
        "intermediate_state": object
    }

    DO NOT USE IF:
    - You already have a valid enriched_query from a previous step.
    - You are continuing from a clarification (use `clarify` instead).
    """
    try:
        # Validate required inputs
        required_fields = ["query", "workspace", "version"]
        missing_fields = [field for field in required_fields if not payload.get(field)]
        if missing_fields:
            return {
                "error": f"Missing required fields: {', '.join(missing_fields)}",
                "next_step": "error"
            }
        
        # Optional: Allow API credentials to be passed as parameters
        if payload.get("api_key"):
            os.environ["DEV_ASSISTANT_API_KEY"] = payload["api_key"]
        if payload.get("api_base"):
            os.environ["DEV_ASSISTANT_API_BASE"] = payload["api_base"]
        if payload.get("model_name"):
            os.environ["MODEL_NAME"] = payload["model_name"]
        
        from mcp_context_engineer.orchestrator import ContextEngineer

        engineer = ContextEngineer()
        result = engineer.run(
            raw_query=payload["query"],
            workspace=payload["workspace"],
            version=payload["version"],
        )
    except Exception as e:
        log.error("Process tool failed: %s", e)
        return {
            "error": f"Pipeline execution failed: {str(e)}",
            "next_step": "error"
        }

    # If the scorer asks for clarification we return the same shape
    # that the UI expects (question + cached state).
    if result.get("clarification", {}).get("needed"):
        return {
            "next_step": "clarify",
            "question": result["clarification"]["question"],
            "original_query": payload["query"],
            "workspace": payload["workspace"],
            "version": payload["version"],
            "intermediate_state": result,
        }

    # Otherwise we have a confident enriched query.
    final_story = result.get("final_story", {})
    if isinstance(final_story, dict):
        enriched_query = final_story.get("enriched_query", "")
    else:
        enriched_query = str(final_story)
    
    return {
        "next_step": "retrieve",
        "enriched_query": enriched_query,
        "confidence": result["confidence"],
        "supporting_context": final_story.get("supporting_context", "") if isinstance(final_story, dict) else "",
        "strategy": final_story.get("strategy", "unknown") if isinstance(final_story, dict) else "unknown"
    }

app.add_tool(process)

# ----------------------------------------------------------------------
# TOOL:  clarify – re‑run only the scorer after the user answers
# ----------------------------------------------------------------------
async def clarify(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    WHEN TO USE:
    - Use this only after the process tool returns a "clarify" response.
    - Use it when the user has answered a clarification question.

    WHAT IT DOES:
    - Re-runs only the Scorer step using the user's clarification.
    - Uses cached intermediate_state from the previous process call.

    INPUT:
    - original_query (string)
    - clarification_answer (string)
    - workspace (string)
    - version (string)
    - intermediate_state (object): from previous process response

    OUTPUT:
    - If resolved:
    {
        "next_step": "retrieve",
        "enriched_query": string,
        "confidence": float
    }

    - If still unclear:
    {
        "next_step": "clarify",
        "question": string,
        "original_query": string,
        "workspace": string,
        "version": string,
        "intermediate_state": object
    }

    DO NOT USE IF:
    - No clarification was requested previously.
    - You do not have intermediate_state from process.
    """
    try:
        # Validate required inputs  
        required_fields = ["original_query", "clarification_answer", "workspace", "version", "intermediate_state"]
        missing_fields = [field for field in required_fields if not payload.get(field)]
        if missing_fields:
            return {
                "error": f"Missing required fields: {', '.join(missing_fields)}",
                "next_step": "error"
            }
        
        from mcp_context_engineer.orchestrator import ContextEngineer

        engineer = ContextEngineer()
        result = engineer.continue_from_score(
            original_query=payload["original_query"],
            workspace=payload["workspace"],
            version=payload["version"],
            clarification_answer=payload["clarification_answer"],
            cached_state=payload["intermediate_state"],
        )
    except Exception as e:
        log.error("Clarify tool failed: %s", e)
        return {
            "error": f"Clarification processing failed: {str(e)}",
            "next_step": "error"
        }

    if result.get("clarification", {}).get("needed"):
        # Pass the accumulated raw_query forward so the next clarify round
        # has the full conversation history, not just the original message.
        accumulated_query = result.get("raw_query", payload["original_query"])
        return {
            "next_step": "clarify",
            "question": result["clarification"]["question"],
            "original_query": accumulated_query,
            "workspace": payload["workspace"],
            "version": payload["version"],
            "intermediate_state": result,   # full updated context, not cached_state
        }

    final_story = result.get("final_story", {})
    if isinstance(final_story, dict):
        enriched_query = final_story.get("enriched_query", "")
    else:
        enriched_query = str(final_story)

    return {
        "next_step": "retrieve",
        "enriched_query": enriched_query,
        "confidence": result["confidence"],
        "supporting_context": final_story.get("supporting_context", "") if isinstance(final_story, dict) else "",
        "strategy": final_story.get("strategy", "unknown") if isinstance(final_story, dict) else "unknown"
    }

app.add_tool(clarify)

# ----------------------------------------------------------------------
# TOOL:  start – fire‑and‑forget call to the FastAPI indexing endpoint
# ----------------------------------------------------------------------
async def start(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    WHEN TO USE:
    - Use this to start indexing a workspace.
    - Use it before retrieval if the workspace has not been indexed.

    WHAT IT DOES:
    - Triggers the FastAPI indexing job asynchronously (fire-and-forget).
    - Does NOT wait for indexing to complete.

    INPUT:
    - workspacepath (string): workspace path or identifier
    - version (string, optional)

    OUTPUT:
    {
    "type": "start",
    "response": object
    }

    DO NOT USE IF:
    - Indexing is already running or completed (use `status` to check first).
    - You are trying to retrieve data (use `retrieve` instead).
    """
    # The FastAPI endpoint is POST /indexing?workspacepath=…&version=…
    try:
        resp = await client.post(
            "/indexing",
            params={
                "workspacepath": payload.get("workspacepath"),
                "version": payload.get("version"),
            },
        )
        # The FastAPI endpoint returns a tiny JSON {"response":"Indexing Started"}
        return {"type": "start", "response": resp.json()}
    except Exception as exc:  # pragma: no cover
        log.error("Failed to call /indexing: %s", exc)
        raise

app.add_tool(start)

# ----------------------------------------------------------------------
# TOOL:  status – one‑shot JSON status (non‑SSE)
# ----------------------------------------------------------------------
# async def _status_tool(payload: Dict[str, Any]) -> Dict[str, Any]:
#     """
#     Payload (both fields optional):
#     {
#         "workspacepath": "...",
#         "version": "1"
#     }
#     """
#     try:
#         if payload.get("workspacepath") and payload.get("version"):
#             # FastAPI has a helper endpoint that returns the latest event
#             resp = await client.get(
#                 "/indexingstatus",
#                 params={
#                     "workspacepath": payload["workspacepath"],
#                     "version": payload["version"],
#                 },
#                 timeout=5.0,
#             )
#             # The SSE endpoint returns a stream; we just want the *latest* event.
#             # The FastAPI code also stores the latest event in EventStore, so we can
#             # safely call the same endpoint with `Accept: application/json` and it
#             # will give us the latest JSON object (the code already supports that).
#             return {"type": "status", "status": resp.json()}
#         else:
#             # Global status (same logic as the SSE endpoint when no args are given)
#             resp = await client.get("/indexingstatus", timeout=5.0)
#             return {"type": "status", "status": resp.text}
#     except Exception as exc:  # pragma: no cover
#         log.error("Failed to call /indexingstatus: %s", exc)
#         raise

# ----------------------------------------------------------------------
# TOOL:  status – one‑shot JSON status (non‑SSE)
# ----------------------------------------------------------------------

# TODO: LEARN WHAT IS THE DIFFERENCE BETWEEN THE CODE BELOW AND NEW CODE

# async def _status_tool(payload: Dict[str, Any]) -> Dict[str, Any]:
#     """
#     Payload (both fields optional):
#     {
#         "workspacepath": "...",
#         "version": "1"
#     }

#     Returns the latest indexing status **including** any progress % that the
#     SSE endpoint emits (e.g. `{ "progress": 42, "message": "…"} `).
#     """
#     try:
#         # Build the request – we keep the same query‑string that the SSE
#         # endpoint expects.
#         params = {}
#         if payload.get("workspacepath"):
#             params["workspacepath"] = payload["workspacepath"]
#         if payload.get("version"):
#             params["version"] = payload["version"]

#         # Ask for a streamed response so we can read the first event.
#         resp = await client.get(
#             "/indexingstatus",
#             params=params,
#             timeout=10.0,
#             headers={"Accept": "text/event-stream"},
#             stream=True,
#         )

#         # The FastAPI implementation yields two kinds of lines:
#         #   • “: ping …”  → keep‑alive messages we can ignore
#         #   • JSON payload (either the latest stored event or a ping‑status)
#         async for line in resp.aiter_lines():
#             line = line.strip()
#             if not line:
#                 continue
#             # Skip keep‑alive pings that start with “:”
#             if line.startswith(":"):
#                 continue

#             # At this point `line` should be a JSON string – try to decode it.
#             try:
#                 data = json.loads(line)
#                 # If the server sent a dict with a `progress` field we return it.
#                 # Otherwise we just forward whatever it gave us (e.g. a plain
#                 # status string).
#                 return {"type": "status", "status": data}
#             except json.JSONDecodeError:
#                 # The endpoint sometimes yields a raw string (e.g. “indexing …”)
#                 # – treat that as the status text.
#                 return {"type": "status", "status": line}

#         # Fallback – should never hit because the loop returns on first event.
#         return {"type": "status", "status": "no status received"}
#     except Exception as exc:  # pragma: no cover
#         log.error("Failed to call /indexingstatus: %s", exc)
#         raise

# ----------------------------------------------------------------------
# TOOL:  status – one‑shot JSON status (non‑SSE)
# ----------------------------------------------------------------------
# async def _status_tool(payload: Dict[str, Any]) -> Dict[str, Any]:
#     """
#     Payload (both fields optional):
#     {
#         "workspacepath": "...",
#         "version": "1"
#     }

#     Returns the latest indexing status **including** any progress % that the
#     SSE endpoint emits (e.g. `{ "progress": 42, "message": "…" }`).
#     """
#     try:
#         # Build query parameters for the FastAPI endpoint.
#         params: Dict[str, str] = {}
#         if payload.get("workspacepath"):
#             params["workspacepath"] = payload["workspacepath"]
#         if payload.get("version"):
#             params["version"] = payload["version"]

#         # Use `client.stream()` (the async streaming API) – this avoids the
#         # “unexpected keyword argument 'stream'” error.
#         async with client.stream(
#             "GET",
#             "/indexingstatus",
#             params=params,
#             timeout=10.0,
#             headers={"Accept": "text/event-stream"},
#         ) as resp:
#             # Iterate over the raw lines emitted by the SSE endpoint.
#             async for line in resp.aiter_lines():
#                 line = line.strip()
#                 if not line:
#                     continue
#                 # Skip keep‑alive ping lines that start with “:”.
#                 if line.startswith(":"):
#                     continue

#                 # Try to decode a JSON payload (the real event).
#                 try:
#                     data = json.loads(line)
#                     return {"type": "status", "status": data}
#                 except json.JSONDecodeError:
#                     # If it isn’t JSON, treat the raw string as the status.
#                     return {"type": "status", "status": line}

#         # Fallback – should never be reached because the loop returns on first event.
#         return {"type": "status", "status": "no status received"}
#     except Exception as exc:  # pragma: no cover
#         log.error("Failed to call /indexingstatus: %s", exc)
#         raise
async def status(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    WHEN TO USE:
    - Use this to check the current indexing status.
    - Use it after calling the start tool.

    WHAT IT DOES:
    - Fetches a one-time snapshot of indexing progress from the SSE endpoint.
    - Returns progress (if available) and a human-readable status message.

    INPUT:
    - workspacepath (string, optional)
    - version (string, optional)

    OUTPUT:
    {
    "type": "status",
    "status": {
        "message": string,
        "progress": number or null
    }
    }

    DO NOT USE IF:
    - You need to start indexing (use `start` instead).
    - You are trying to retrieve data (use `retrieve` instead).
    """
    try:
        params: Dict[str, str] = {}
        if payload.get("workspacepath"):
            params["workspacepath"] = payload["workspacepath"]
        if payload.get("version"):
            params["version"] = payload["version"]

        async with client.stream(
            "GET",
            "/indexingstatus",
            params=params,
            timeout=5.0,  # keep tight
            headers={"Accept": "text/event-stream"},
        ) as resp:

            async for line in resp.aiter_lines():
                if not line:
                    continue

                line = line.strip()

                # 🔹 CASE 1: Ping line → ": ping - time | status"
                if line.startswith(":"):
                    # Extract status after "|"
                    if "|" in line:
                        status_text = line.split("|", 1)[1].strip()
                    else:
                        status_text = line

                    return {
                        "type": "status",
                        "status": {
                            "message": status_text,
                            "progress": None
                        }
                    }

                # 🔹 CASE 2: JSON event (real progress)
                try:
                    data = json.loads(line)
                    return {
                        "type": "status",
                        "status": data
                    }
                except json.JSONDecodeError:
                    # fallback raw
                    return {
                        "type": "status",
                        "status": {
                            "message": line,
                            "progress": None
                        }
                    }

        return {"type": "status", "status": "no status received"}

    except Exception as exc:
        log.error("Failed to call /indexingstatus: %s", exc)
        raise
app.add_tool(status)

# ----------------------------------------------------------------------
# TOOL:  retrieve – forward the enriched query to the FastAPI /retrieve endpoint
# ----------------------------------------------------------------------
async def retrieve(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    WHEN TO USE:
    - Use this after a successful process step with high confidence.
    - Use it to retrieve relevant code or document chunks.

    WHAT IT DOES:
    - Sends the enriched_query to the retrieval service.
    - Returns semantically relevant chunks from the indexed workspace.

    INPUT:
    - enriched_query (string): must come from process or clarify
    - workspace (string)
    - version (string)

    OUTPUT:
    {
    "type": "retrieve",
    "chunks": list
    }

    DO NOT USE IF:
    - You only have a raw user query (use `process` first).
    - The workspace has not been indexed (use `start` first).
    """
    
    # Build the LocalContextProvider payload expected by the FastAPI /retrieve endpoint.
    # The FastAPI endpoint expects a JSON body that matches the Pydantic model
    # `LocalContextProvider`.  We only need `fullInput` and can leave `options` empty.
    retrieve_body = {
        "fullInput": payload["enriched_query"],
        "options": {}
    }

    try:
        resp = await client.post(
            "/retrieve",
            json=retrieve_body,
            params={
                "workspacepath": payload.get("workspace"),
                "version": payload.get("version"),
            },
        )
        # The FastAPI endpoint returns a list of chunks.
        return {"type": "retrieve", "chunks": resp.json()}
    except Exception as exc:  # pragma: no cover
        log.error("Failed to call /retrieve: %s", exc)
        raise

app.add_tool(retrieve)


# ----------------------------------------------------------------------
# Entry‑point – run the FastMCP server on stdio (the transport Continue expects)
# ----------------------------------------------------------------------
def main() -> None:
    log.info("MCP server starting (FastMCP)…")
    try:
        # `transport="stdio"` tells FastMCP to read/write JSON lines on stdin/stdout.
        app.run(transport="http", port = 8080)
    except Exception as exc:  # pragma: no cover
        log.exception("MCP server crashed")
        raise

if __name__ == "__main__":
    main()