# mcp_context_engineer/mcp_context_engineer/tool_chain/story_telling.py

import logging
import requests
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class StoryTellerTool:
    """
    Consumes all context produced by ContextEngineer and CodeMapper,
    performs a targeted retrieval against filtered file paths (when
    available), and structures a final enriched query for the last
    unfiltered retrieval step.

    For broad queries (full repo map), the repo map text itself is
    the primary context -- no intermediate retrieval is needed.

    Context contract
    ----------------
    Reads:
        raw_query, intent, entities, code_entities, language,
        repo_map, workspace, version
    Writes:
        final_story  ->  {
            enriched_query: str,       # optimized query for final unfiltered retrieval
            supporting_context: str,   # merged context for LLM
            retrieved_chunks: list,    # raw chunks from filtered retrieval (if any)
            strategy: str              # "specific" | "broad" | "fallback"
        }
    """

    RETRIEVAL_ENDPOINT = "http://localhost:8000/retrieve"
    DEFAULT_CHUNK_COUNT = 5

    def __init__(
        self,
        context: Dict[str, Any],
        retrieval_endpoint: str = None,
    ):
        self.context = context
        self.retrieval_endpoint = retrieval_endpoint or self.RETRIEVAL_ENDPOINT
        self.workspace = context.get("workspace", "")
        self.version = context.get("version", "1")

    # ==================================================================
    # Public entry point
    # ==================================================================

    def run(self) -> Dict[str, Any]:
        logger.info("StoryTeller: Starting query structuring")

        repo_map = self.context.get("repo_map")

        # Determine strategy
        if not repo_map:
            logger.warning("StoryTeller: No repo map available, using fallback")
            strategy = "fallback"
            chunks = []
        elif repo_map.get("is_full_map"):
            logger.info("StoryTeller: Broad query detected, using full repo map as context")
            strategy = "broad"
            chunks = []
        else:
            logger.info("StoryTeller: Specific query, retrieving from filtered files")
            strategy = "specific"
            chunks = self._retrieve_from_filtered_files(repo_map)

        # Build the final story
        enriched_query = self._build_enriched_query(strategy, chunks, repo_map)
        supporting_context = self._build_supporting_context(strategy, chunks, repo_map)

        self.context["final_story"] = {
            "enriched_query": enriched_query,
            "supporting_context": supporting_context,
            "retrieved_chunks": chunks,
            "strategy": strategy,
        }

        logger.info(
            "StoryTeller: Completed. Strategy='%s', chunks=%d, "
            "enriched_query_length=%d, context_length=%d",
            strategy, len(chunks), len(enriched_query), len(supporting_context),
        )

        return self.context

    # ==================================================================
    # Filtered retrieval (specific queries only)
    # ==================================================================

    def _retrieve_from_filtered_files(self, repo_map: Dict) -> List[Dict]:
        """
        Retrieve top-K chunks from the file paths identified by CodeMapper.
        Uses the filePaths filter on the retrieval endpoint.
        """
        structured = repo_map.get("structured", {})
        files = structured.get("files", {})

        if not files:
            logger.warning("StoryTeller: No filtered files to retrieve from")
            return []

        # Build file path list using the original path format from repo map
        file_paths = []
        for filename, data in files.items():
            original_path = data.get("path", f".\\{filename}")
            file_paths.append(original_path)

        raw_query = self.context.get("raw_query", "")

        payload = {
            "fullInput": raw_query,
            "options": {
                "filePaths": file_paths,
                "retrievalDocCount": self.DEFAULT_CHUNK_COUNT,
            },
        }

        params = {
            "workspace_path": self.workspace,
            "version": self.version,
        }

        logger.info(
            "StoryTeller: Retrieving from %d files: %s",
            len(file_paths), file_paths,
        )

        try:
            response = requests.post(
                self.retrieval_endpoint,
                params=params,
                json=payload,
                timeout=15,
            )

            if response.ok:
                results = response.json().get("results", [])
                logger.info("StoryTeller: Retrieved %d chunks", len(results))
                return results
            else:
                logger.warning(
                    "StoryTeller: Retrieval returned %d: %s",
                    response.status_code, response.text[:200],
                )
                return []

        except Exception as e:
            logger.error("StoryTeller: Retrieval request failed: %s", e)
            return []

    # ==================================================================
    # Enriched query builder
    # ==================================================================

    def _build_enriched_query(
        self,
        strategy: str,
        chunks: List[Dict],
        repo_map: Dict | None,
    ) -> str:
        """
        Build an optimized query string for the final unfiltered retrieval.
        This is what gets sent as `fullInput` in the last retrieval step.

        The enriched query combines:
        - Original user question (cleaned of code blocks)
        - Key entity names
        - Relevant function/class names from chunks or repo map
        """
        raw_query = self.context.get("raw_query", "")
        intent = self.context.get("intent", {})
        entities = self.context.get("entities", set())
        code_entities = self.context.get("code_entities") or {}

        # Start with the core question (strip code blocks for cleaner query)
        core_question = self._extract_natural_language(raw_query)

        # Collect key terms to enrich the query
        key_terms = set()

        # From NLP entities (filter short/noise)
        for entity in entities:
            if len(str(entity)) > 3:
                key_terms.add(str(entity))

        # From code entities
        for func in code_entities.get("functions", []):
            name = func.get("name") if isinstance(func, dict) else str(func)
            if name and len(name) > 2:
                key_terms.add(name)

        for cls in code_entities.get("classes", []):
            name = cls.get("name") if isinstance(cls, dict) else str(cls)
            if name and len(name) > 2:
                key_terms.add(name)

        # From retrieved chunks (specific strategy)
        if strategy == "specific" and chunks:
            for chunk in chunks[:3]:
                metadata = chunk.get("metadata", {})
                func_name = metadata.get("function_name")
                class_name = metadata.get("class_name")
                if func_name:
                    key_terms.add(func_name)
                if class_name:
                    key_terms.add(class_name)

        # From repo map summary (broad strategy)
        if strategy == "broad" and repo_map:
            summary = repo_map.get("structured", {}).get("summary", {})
            # Add top imports as context hints
            for imp in summary.get("all_imports", [])[:10]:
                if len(imp) > 3:
                    key_terms.add(imp)

        # Build the enriched query
        parts = [core_question]

        if key_terms:
            terms_str = ", ".join(sorted(key_terms)[:15])
            parts.append(f"Related: {terms_str}")

        primary_intent = intent.get("primary", "general") if isinstance(intent, dict) else str(intent)
        parts.append(f"Intent: {primary_intent}")

        enriched = "\n".join(parts)
        logger.info("StoryTeller: Enriched query built (%d chars)", len(enriched))
        return enriched

    # ==================================================================
    # Supporting context builder
    # ==================================================================

    def _build_supporting_context(
        self,
        strategy: str,
        chunks: List[Dict],
        repo_map: Dict | None,
    ) -> str:
        """
        Build the full supporting context that accompanies the enriched query.
        This provides the LLM with all necessary background to answer.
        """
        sections: List[str] = []

        # Section 1: User query and intent
        sections.append(self._section_query_summary())

        # Section 2: Strategy-dependent context
        if strategy == "broad":
            sections.append(self._section_repo_map(repo_map))
        elif strategy == "specific":
            sections.append(self._section_retrieved_chunks(chunks))
            # Also include filtered repo map as supplementary info
            if repo_map:
                sections.append(self._section_repo_map(repo_map))
        else:
            # Fallback: just the query summary
            sections.append("--- NO ADDITIONAL CONTEXT AVAILABLE ---")

        # Section 3: Extracted entities summary
        sections.append(self._section_entities_summary())

        return "\n\n".join(sections)

    def _section_query_summary(self) -> str:
        """Format the user query and detected intent."""
        raw_query = self.context.get("raw_query", "")
        intent = self.context.get("intent", {})
        language = self.context.get("language")

        lines = ["--- USER QUERY ---"]
        lines.append(raw_query.strip())
        lines.append("")

        primary = intent.get("primary", "general") if isinstance(intent, dict) else str(intent)
        secondary = intent.get("secondary") if isinstance(intent, dict) else None

        lines.append(f"Detected intent: {primary}")
        if secondary:
            lines.append(f"Secondary intent: {secondary}")
        if language:
            lines.append(f"Detected language: {language}")

        return "\n".join(lines)

    def _section_repo_map(self, repo_map: Dict | None) -> str:
        """Include the repo map text."""
        if not repo_map:
            return "--- REPOSITORY MAP ---\nNot available."

        lines = ["--- REPOSITORY MAP ---"]

        # Use the pre-formatted text from CodeMapper
        map_text = repo_map.get("text", "")
        if map_text:
            lines.append(map_text)
        else:
            lines.append("Empty repo map.")

        lines.append(
            f"(Showing {repo_map.get('files_in_context', 0)} of "
            f"{repo_map.get('total_files_in_workspace', 0)} files)"
        )

        return "\n".join(lines)

    def _section_retrieved_chunks(self, chunks: List[Dict]) -> str:
        """Format retrieved code chunks."""
        if not chunks:
            return "--- RETRIEVED CODE ---\nNo chunks retrieved."

        lines = ["--- RETRIEVED CODE ---"]
        lines.append(f"Retrieved {len(chunks)} relevant chunks:")
        lines.append("")

        for i, chunk in enumerate(chunks, 1):
            metadata = chunk.get("metadata", {})
            content = chunk.get("content", chunk.get("page_content", ""))
            file_path = metadata.get("file_path", "unknown")
            start_line = metadata.get("start_line", "?")
            end_line = metadata.get("end_line", "?")
            score = chunk.get("score", "N/A")

            lines.append(f"[Chunk {i}] {file_path}:{start_line}-{end_line} (score: {score})")
            lines.append(content.strip() if content else "(empty)")
            lines.append("")

        return "\n".join(lines)

    def _section_entities_summary(self) -> str:
        """Summarize all extracted entities."""
        entities = self.context.get("entities", set())
        code_entities = self.context.get("code_entities") or {}

        lines = ["--- EXTRACTED ENTITIES ---"]

        if entities:
            # Filter to meaningful ones
            filtered = sorted([str(e) for e in entities if len(str(e)) > 2])[:20]
            lines.append(f"NLP entities: {', '.join(filtered)}")

        if code_entities:
            funcs = [
                f.get("name", "?") if isinstance(f, dict) else str(f)
                for f in code_entities.get("functions", [])
                if (f.get("name") if isinstance(f, dict) else f)
            ]
            classes = [
                c.get("name", "?") if isinstance(c, dict) else str(c)
                for c in code_entities.get("classes", [])
                if (c.get("name") if isinstance(c, dict) else c)
            ]
            imports = code_entities.get("imports", [])

            if funcs:
                lines.append(f"Functions: {', '.join(funcs[:10])}")
            if classes:
                lines.append(f"Classes: {', '.join(classes[:10])}")
            if imports:
                imp_strs = [str(i) for i in imports[:10]]
                lines.append(f"Imports: {', '.join(imp_strs)}")

        if len(lines) == 1:
            lines.append("None extracted.")

        return "\n".join(lines)

    # ==================================================================
    # Helpers
    # ==================================================================

    @staticmethod
    def _extract_natural_language(raw_query: str) -> str:
        """
        Extract only the natural language portion of the query,
        stripping out code blocks.  Keeps the actual question the user asked.
        """
        lines = raw_query.strip().split("\n")
        nl_lines: List[str] = []
        in_code = False

        for line in lines:
            stripped = line.strip()

            # Detect code block boundaries
            if stripped.startswith("```"):
                in_code = not in_code
                continue

            if in_code:
                continue

            # Heuristic: lines that look like code (start with common keywords)
            code_indicators = [
                "import ", "from ", "def ", "class ", "async def ",
                "@", "return ", "    ", "\t",
            ]
            looks_like_code = any(stripped.startswith(ind) for ind in code_indicators)

            # Also check for assignment patterns: var = value
            if not looks_like_code and "=" in stripped:
                left = stripped.split("=")[0].strip()
                if left.replace("_", "").isalnum() and left == left.lower():
                    looks_like_code = True

            if not looks_like_code and stripped:
                nl_lines.append(stripped)

        result = " ".join(nl_lines).strip()

        if not result:
            # If we stripped everything, fall back to first non-empty line
            for line in lines:
                if line.strip():
                    return line.strip()

        return result


# ======================================================================
# Testing
# ======================================================================
if __name__ == "__main__":
    import sys
    import os

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    sys.path.insert(
        0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
    )

    print("\n" + "=" * 80)
    print("TESTING STORY TELLER TOOL")
    print("=" * 80)

    # ------------------------------------------------------------------
    # Test 1: Broad query (full repo map, no retrieval)
    # ------------------------------------------------------------------
    print("\n" + "-" * 80)
    print("TEST 1: Broad query - uses full repo map as context")
    print("-" * 80)

    broad_context = {
        "raw_query": "list all the frameworks used in this workspace with a one liner info",
        "workspace": r"D:\work_dsi\ASI84\temp_test_mcp",
        "version": "1",
        "intent": {"primary": "question", "secondary": None, "scores": {}},
        "entities": set(),
        "code_entities": None,
        "language": None,
        "repo_map": {
            "structured": {
                "files": {
                    "app.py": {
                        "path": ".\\app.py",
                        "extension": "py",
                        "imports": ["fastapi", "FastAPI", "pydantic", "BaseModel", "uvicorn"],
                        "classes": [{"name": "LocalContextProvider", "signature": "class LocalContextProvider(BaseModel):"}],
                        "functions": [
                            {"name": "built_filter_condition", "signature": "def built_filter_condition(includeAllFilters, **kwargs):"},
                        ],
                        "variables": [{"name": "app", "value": "app = FastAPI("}],
                    },
                    "loadVectorDatabase.py": {
                        "path": ".\\loadVectorDatabase.py",
                        "extension": "py",
                        "imports": ["langchain_community", "FAISS", "os"],
                        "classes": [{"name": "LoadVectorDatabase", "signature": "class LoadVectorDatabase:"}],
                        "functions": [
                            {"name": "load_faiss_vectorstore", "signature": "def load_faiss_vectorstore(self):"},
                        ],
                        "variables": [],
                    },
                },
                "summary": {
                    "total_files": 8,
                    "languages": ["json", "py", "toml", "yaml"],
                    "all_imports": ["FAISS", "FastAPI", "BaseModel", "fastapi", "langchain_community", "os", "pydantic", "uvicorn"],
                    "all_functions": [],
                    "all_classes": [],
                    "file_list": ["app.py", "loadVectorDatabase.py"],
                },
            },
            "text": "=== REPOSITORY MAP ===\nTotal files: 8\n[app.py]\n  imports: fastapi, FastAPI\n[loadVectorDatabase.py]\n  imports: langchain_community, FAISS\n",
            "is_full_map": True,
            "total_files_in_workspace": 8,
            "files_in_context": 2,
        },
    }

    storyteller = StoryTellerTool(broad_context)
    result = storyteller.run()
    story = result.get("final_story", {})

    print(f"\n  Strategy: {story.get('strategy')}")
    print(f"  Chunks retrieved: {len(story.get('retrieved_chunks', []))}")
    print(f"\n  Enriched query:\n  {story.get('enriched_query', '')}")
    print(f"\n  Supporting context (first 800 chars):\n  {story.get('supporting_context', '')[:800]}")

    # ------------------------------------------------------------------
    # Test 2: Specific query (filtered files, retrieval needed)
    # ------------------------------------------------------------------
    print("\n" + "-" * 80)
    print("TEST 2: Specific query - retrieves from filtered files")
    print("-" * 80)

    specific_context = {
        "raw_query": """
            How do I add pagination to my FastAPI endpoint?

            from fastapi import FastAPI, Query
            app = FastAPI()

            @app.get("/items")
            def get_items(page: int = Query(1, ge=1)):
                items = [f"item-{i}" for i in range(1, 101)]
                return items
        """,
        "workspace": r"D:\work_dsi\ASI84\temp_test_mcp",
        "version": "1",
        "intent": {"primary": "feature_request", "secondary": None, "scores": {"feature_request": 3}},
        "entities": {"FastAPI", "pagination", "Query"},
        "code_entities": {
            "functions": [{"name": "get_items"}],
            "classes": [],
            "imports": ["fastapi", "typing"],
            "variables": [{"name": "app"}],
        },
        "language": "py",
        "repo_map": {
            "structured": {
                "files": {
                    "app.py": {
                        "path": ".\\app.py",
                        "extension": "py",
                        "imports": ["fastapi", "FastAPI", "Query"],
                        "classes": [],
                        "functions": [
                            {"name": "built_filter_condition", "signature": "def built_filter_condition(includeAllFilters, **kwargs):"},
                        ],
                        "variables": [{"name": "app", "value": "app = FastAPI("}],
                    },
                },
                "summary": {
                    "total_files": 8,
                    "languages": ["py"],
                    "all_imports": ["fastapi", "FastAPI", "Query"],
                    "all_functions": [],
                    "all_classes": [],
                    "file_list": ["app.py"],
                },
            },
            "text": "=== REPOSITORY MAP ===\n[app.py]\n  imports: fastapi, FastAPI, Query\n",
            "is_full_map": False,
            "total_files_in_workspace": 8,
            "files_in_context": 1,
        },
    }

    storyteller_specific = StoryTellerTool(specific_context)
    result_specific = storyteller_specific.run()
    story_specific = result_specific.get("final_story", {})

    print(f"\n  Strategy: {story_specific.get('strategy')}")
    print(f"  Chunks retrieved: {len(story_specific.get('retrieved_chunks', []))}")
    print(f"\n  Enriched query:\n  {story_specific.get('enriched_query', '')}")
    print(f"\n  Supporting context (first 800 chars):\n  {story_specific.get('supporting_context', '')[:800]}")

    # ------------------------------------------------------------------
    # Test 3: Full pipeline - ContextEngineer -> CodeMapper -> StoryTeller
    # ------------------------------------------------------------------
    print("\n" + "-" * 80)
    print("TEST 3: Full pipeline")
    print("-" * 80)

    try:
        from mcp_context_engineer.tool_chain.context_engineer import ContextEngineer
        from mcp_context_engineer.tool_chain.code_mapper import CodeMapperTool

        pipeline_context = {
            "raw_query": """
                I'm trying to add pagination to a FastAPI endpoint.

                from fastapi import FastAPI, Query
                from typing import List

                app = FastAPI()

                @app.get("/items")
                def get_items(page: int = Query(1, ge=1), size: int = Query(10, ge=1)):
                    items = [f"item-{i}" for i in range(1, 101)]
                    start = (page - 1) * size
                    end = start + size
                    return {"page": page, "size": size, "items": items[start:end]}
            """,
            "workspace": r"D:\work_dsi\ASI84\temp_test_mcp",
            "version": "1",
        }

        # Step 1
        print("\n  Step 1: ContextEngineer...")
        ce = ContextEngineer(pipeline_context)
        pipeline_context.update(ce.enrich_query())
        print(f"    Intent: {pipeline_context.get('intent', {}).get('primary')}")
        print(f"    Language: {pipeline_context.get('language')}")

        # Step 2
        print("\n  Step 2: CodeMapper...")
        mapper = CodeMapperTool(pipeline_context)
        pipeline_context = mapper.run()
        rm = pipeline_context.get("repo_map", {})
        print(f"    Full map: {rm.get('is_full_map')}")
        print(f"    Files: {rm.get('files_in_context')}")

        # Step 3
        print("\n  Step 3: StoryTeller...")
        storyteller_full = StoryTellerTool(pipeline_context)
        pipeline_context = storyteller_full.run()
        fs = pipeline_context.get("final_story", {})
        print(f"    Strategy: {fs.get('strategy')}")
        print(f"    Chunks: {len(fs.get('retrieved_chunks', []))}")
        print(f"    Enriched query:\n    {fs.get('enriched_query', '')[:300]}")

    except Exception as e:
        print(f"\n  Pipeline test failed: {e}")
        import traceback
        traceback.print_exc()

    print("\n" + "=" * 80)
    print("TESTING COMPLETE")
    print("=" * 80 + "\n")