# mcp_context_engineer/mcp_context_engineer/tool_chain/scorer.py

import logging
import json
import re
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

# Use dev assistant LLM
from utils.devassistant_llm import LLMClient
# Import environment loading from utils  
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from utils.devassistant_llm import _load_environment
_load_environment()

logger = logging.getLogger(__name__)

class ConfidenceLevel(Enum):
    """Confidence level classifications for scoring"""
    VERY_HIGH = "very_high"    # 0.9+
    HIGH = "high"              # 0.7-0.89
    MEDIUM = "medium"          # 0.5-0.69
    LOW = "low"                # 0.3-0.49
    VERY_LOW = "very_low"      # 0.0-0.29

@dataclass
class ScoringRule:
    """Individual scoring rule configuration"""
    name: str
    weight: float
    min_score: float = 0.0
    max_score: float = 1.0
    description: str = ""
    
    def normalize_score(self, score: float) -> float:
        """Normalize score to rule's min/max range"""
        return max(self.min_score, min(self.max_score, score))

@dataclass 
class ScoringConfig:
    """Configuration for scoring rules and thresholds"""
    
    # Rule weights (must sum to 1.0)
    query_clarity_weight: float = 0.25
    context_completeness_weight: float = 0.25
    entity_coverage_weight: float = 0.20
    intent_confidence_weight: float = 0.15
    code_context_weight: float = 0.15
    
    # Scoring thresholds
    clarification_threshold: float = 0.7
    min_acceptable_score: float = 0.3
    
    # Rule-specific thresholds
    min_query_length: int = 10
    min_entities_for_bonus: int = 2
    high_intent_confidence: float = 0.8
    
    def __post_init__(self):
        """Validate configuration"""
        total_weight = (
            self.query_clarity_weight + 
            self.context_completeness_weight +
            self.entity_coverage_weight +
            self.intent_confidence_weight +
            self.code_context_weight
        )
        if abs(total_weight - 1.0) > 0.001:
            raise ValueError(f"Rule weights must sum to 1.0, got {total_weight}")

class ScorerTool:
    """
    Robust scorer tool that evaluates query context for retrieval confidence.
    
    Uses both LLM-based scoring and rule-based heuristics to determine if 
    the context is sufficient for retrieval or if clarification is needed.
    
    Context contract:
    -----------------
    Reads:
        final_story: dict - Complete story from StoryTeller
        intent: dict - Detected intent information
        entities: set - Extracted entities
        code_entities: dict - Code-specific entities 
        enriched_query: str - Processed query
        raw_query: str - Original user query
    
    Writes:
        confidence: float - Overall confidence score (0.0-1.0)
        clarification: dict - Clarification request info
        scoring_details: dict - Detailed breakdown of scoring
    """
    
    def __init__(self, context: Dict[str, Any], threshold: float = 0.7):
        self.context = context
        self.threshold = threshold
        self.config = ScoringConfig(clarification_threshold=threshold)
        self.client = LLMClient()
        
        # Initialize scoring rules
        self.rules = self._initialize_scoring_rules()
        
    def _initialize_scoring_rules(self) -> Dict[str, ScoringRule]:
        """Initialize the scoring rules with weights and descriptions"""
        return {
            "query_clarity": ScoringRule(
                name="Query Clarity",
                weight=self.config.query_clarity_weight,
                description="Evaluates how clear and specific the user query is"
            ),
            "context_completeness": ScoringRule(
                name="Context Completeness", 
                weight=self.config.context_completeness_weight,
                description="Assesses if we have sufficient context to answer"
            ),
            "entity_coverage": ScoringRule(
                name="Entity Coverage",
                weight=self.config.entity_coverage_weight,
                description="Measures how well entities are identified and covered"
            ),
            "intent_confidence": ScoringRule(
                name="Intent Confidence",
                weight=self.config.intent_confidence_weight,
                description="Evaluates confidence in detected user intent"
            ),
            "code_context": ScoringRule(
                name="Code Context",
                weight=self.config.code_context_weight,
                description="Assesses code-related context quality"
            )
        }
    
    def run(self) -> Dict[str, Any]:
        """
        Main scoring method that evaluates the context and determines confidence.
        
        Returns the updated context with scoring results.
        """
        logger.info("ScorerTool: Starting confidence evaluation")
        
        try:
            # Get rule-based scores
            rule_scores = self._compute_rule_based_scores()
            
            # Get LLM-based score
            llm_score = self._compute_llm_score()
            
            # Combine scores with weighted average
            # 70% rule-based, 30% LLM-based for robustness
            rule_confidence = sum(score * rule.weight for score, rule in 
                                zip(rule_scores.values(), self.rules.values()))
            
            final_confidence = 0.7 * rule_confidence + 0.3 * llm_score
            final_confidence = max(0.0, min(1.0, final_confidence))  # Clamp to [0,1]
            
            # Determine confidence level
            confidence_level = self._get_confidence_level(final_confidence)
            
            # Build scoring details
            scoring_details = {
                "final_confidence": final_confidence,
                "confidence_level": confidence_level.value,
                "rule_based_score": rule_confidence,
                "llm_based_score": llm_score,
                "rule_breakdown": {
                    name: {"score": score, "weight": rule.weight, "weighted_score": score * rule.weight}
                    for name, (score, rule) in zip(rule_scores.keys(), 
                                                 zip(rule_scores.values(), self.rules.values()))
                },
                "threshold": self.threshold,
                "needs_clarification": final_confidence < self.threshold
            }
            
            # Determine if clarification is needed
            clarification_info = self._build_clarification_request(
                final_confidence, rule_scores, scoring_details
            )
            
            # Update context
            self.context.update({
                "confidence": final_confidence,
                "clarification": clarification_info,
                "scoring_details": scoring_details
            })
            
            logger.info(
                "ScorerTool: Scoring complete - confidence=%.3f, level=%s, clarification_needed=%s",
                final_confidence, confidence_level.value, clarification_info["needed"]
            )
            
            return self.context
            
        except Exception as e:
            logger.error("ScorerTool: Scoring failed - %s", e, exc_info=True)
            # Fallback scoring
            self.context.update({
                "confidence": 0.5,  # Neutral score
                "clarification": {
                    "needed": True,
                    "question": "I encountered an issue while evaluating your query. Could you please rephrase or provide more details?"
                },
                "scoring_details": {"error": str(e)}
            })
            return self.context
    
    def _compute_rule_based_scores(self) -> Dict[str, float]:
        """Compute scores based on heuristic rules"""
        scores = {}
        
        # Rule 1: Query Clarity
        scores["query_clarity"] = self._score_query_clarity()
        
        # Rule 2: Context Completeness  
        scores["context_completeness"] = self._score_context_completeness()
        
        # Rule 3: Entity Coverage
        scores["entity_coverage"] = self._score_entity_coverage()
        
        # Rule 4: Intent Confidence
        scores["intent_confidence"] = self._score_intent_confidence()
        
        # Rule 5: Code Context
        scores["code_context"] = self._score_code_context()
        
        logger.debug("Rule-based scores: %s", scores)
        return scores
    
    def _score_query_clarity(self) -> float:
        """Score based on query clarity and specificity"""
        raw_query = self.context.get("raw_query", "")
        
        if not raw_query or len(raw_query.strip()) < self.config.min_query_length:
            return 0.1
        
        score = 0.5  # Base score
        
        # Bonus for question words (indicates clear intent)
        question_words = ["how", "what", "why", "when", "where", "which", "can", "should"]
        if any(word in raw_query.lower() for word in question_words):
            score += 0.2
        
        # Bonus for specific technical terms
        tech_indicators = ["function", "class", "method", "import", "library", "framework", "api"]
        tech_count = sum(1 for term in tech_indicators if term in raw_query.lower())
        score += min(0.2, tech_count * 0.05)
        
        # Penalty for very short queries
        if len(raw_query.strip()) < 20:
            score -= 0.2
        
        # Bonus for moderate length (not too short, not too verbose)
        if 20 <= len(raw_query.strip()) <= 200:
            score += 0.1
            
        return max(0.0, min(1.0, score))
    
    def _score_context_completeness(self) -> float:
        """Score based on available context information"""
        score = 0.0
        
        # Check for story completeness
        final_story = self.context.get("final_story", {})
        if final_story:
            score += 0.3
            
            # Bonus for retrieval strategy
            strategy = final_story.get("strategy", "")
            if strategy == "specific":
                score += 0.2  # Specific queries are better
            elif strategy == "broad":
                score += 0.1
            
            # Bonus for retrieved chunks
            chunks = final_story.get("retrieved_chunks", [])
            if chunks:
                score += min(0.2, len(chunks) * 0.05)
        
        # Check for repo map
        repo_map = self.context.get("repo_map")
        if repo_map:
            score += 0.2
            if repo_map.get("structured"):
                score += 0.1
        
        # Check for enriched query
        if self.context.get("enriched_query"):
            score += 0.2
        
        return max(0.0, min(1.0, score))
    
    def _score_entity_coverage(self) -> float:
        """Score based on entity extraction quality"""
        entities = self.context.get("entities", set())
        code_entities = self.context.get("code_entities", {})
        
        score = 0.3  # Base score
        
        # Bonus for general entities
        entity_count = len(entities) if entities else 0
        if entity_count >= self.config.min_entities_for_bonus:
            score += min(0.3, entity_count * 0.05)
        
        # Bonus for code entities
        if code_entities:
            score += 0.2
            
            # Specific bonuses for different entity types
            if code_entities.get("functions"):
                score += 0.1
            if code_entities.get("classes"):
                score += 0.1
            if code_entities.get("imports"):
                score += 0.1
        
        # Penalty for no entities at all
        if not entities and not code_entities:
            score = 0.2
        
        return max(0.0, min(1.0, score))
    
    def _score_intent_confidence(self) -> float:
        """Score based on intent detection confidence"""
        intent = self.context.get("intent", {})
        
        if not intent:
            return 0.2
        
        score = 0.4  # Base score
        
        # Handle different intent formats
        if isinstance(intent, dict):
            primary = intent.get("primary", "general")
            scores_dict = intent.get("scores", {})
            
            # Bonus for non-general intent
            if primary != "general":
                score += 0.2
            
            # Bonus for high confidence scores
            if scores_dict and primary in scores_dict:
                intent_score = scores_dict[primary]
                if intent_score >= self.config.high_intent_confidence:
                    score += 0.3
                elif intent_score >= 0.5:
                    score += 0.1
        else:
            # String intent format
            if str(intent).lower() != "general":
                score += 0.2
        
        return max(0.0, min(1.0, score))
    
    def _score_code_context(self) -> float:
        """Score code-specific context quality"""
        language = self.context.get("language")
        code_entities = self.context.get("code_entities", {})
        raw_query = self.context.get("raw_query", "")
        
        score = 0.5  # Base score for non-code queries
        
        # If we detected code in the query
        if language or code_entities:
            score = 0.3  # Reset to lower base for code queries
            
            # Bonus for language detection
            if language:
                score += 0.2
            
            # Bonus for parsed code entities
            if code_entities:
                score += 0.2
                
                # Detailed bonuses
                functions = code_entities.get("functions", [])
                classes = code_entities.get("classes", [])
                imports = code_entities.get("imports", [])
                
                if functions:
                    score += min(0.2, len(functions) * 0.05)
                if classes:
                    score += min(0.2, len(classes) * 0.05)
                if imports:
                    score += min(0.1, len(imports) * 0.02)
        
        # Check for code patterns in raw query
        code_patterns = ["def ", "class ", "import ", "from ", "@", "return ", "if __name__"]
        code_indicators = sum(1 for pattern in code_patterns if pattern in raw_query)
        if code_indicators > 0:
            score += min(0.2, code_indicators * 0.04)
        
        return max(0.0, min(1.0, score))
    
    def _compute_llm_score(self) -> float:
        """Use LLM to evaluate context quality and provide confidence score"""
        try:
            # Prepare context summary for LLM
            context_summary = self._prepare_context_for_llm()
            
            # Create scoring prompt
            scoring_prompt = """
You are an expert at evaluating whether a user query has sufficient context for accurate retrieval and response generation.

Analyze the following context and provide a confidence score between 0.0 and 1.0:
- 0.0-0.3: Very poor context, definitely needs clarification
- 0.3-0.5: Poor context, likely needs clarification  
- 0.5-0.7: Moderate context, might need clarification
- 0.7-0.9: Good context, probably sufficient
- 0.9-1.0: Excellent context, definitely sufficient

Consider these factors:
1. Query clarity and specificity
2. Available context completeness
3. Entity and intent detection quality
4. Code context relevance (if applicable)
5. Likelihood of providing accurate answer

Return ONLY a JSON object with this format:
{
    "confidence_score": 0.X,
    "reasoning": "Brief explanation of the score",
    "key_factors": ["factor1", "factor2", "factor3"]
}
"""
            
            user_content = f"{scoring_prompt}\n\nCONTEXT TO EVALUATE:\n{context_summary}"
            
            response = self.client.simple_chat(
                user_content=user_content,
                temperature=0.1,  # Low temperature for consistent scoring
                max_tokens=500
            )
            
            # Parse LLM response
            llm_result = self._parse_llm_scoring_response(response)
            return llm_result.get("confidence_score", 0.5)
            
        except Exception as e:
            logger.warning("LLM scoring failed, using fallback: %s", e)
            return 0.5  # Neutral fallback score
    
    def _prepare_context_for_llm(self) -> str:
        """Prepare a concise context summary for LLM evaluation"""
        parts = []
        
        # Raw query
        raw_query = self.context.get("raw_query", "")
        if raw_query:
            parts.append(f"User Query: {raw_query[:300]}...")
        
        # Intent
        intent = self.context.get("intent", {})
        if intent:
            if isinstance(intent, dict):
                primary = intent.get("primary", "unknown")
                confidence = intent.get("scores", {}).get(primary, "unknown")
                parts.append(f"Detected Intent: {primary} (confidence: {confidence})")
            else:
                parts.append(f"Detected Intent: {intent}")
        
        # Entities
        entities = self.context.get("entities", set())
        if entities:
            entity_list = list(entities)[:10]  # Limit to avoid too much text
            parts.append(f"Extracted Entities: {', '.join(entity_list)}")
        
        # Code context
        language = self.context.get("language")
        code_entities = self.context.get("code_entities", {})
        if language:
            parts.append(f"Programming Language: {language}")
        if code_entities:
            functions = len(code_entities.get("functions", []))
            classes = len(code_entities.get("classes", []))
            imports = len(code_entities.get("imports", []))
            parts.append(f"Code Entities: {functions} functions, {classes} classes, {imports} imports")
        
        # Final story summary
        final_story = self.context.get("final_story", {})
        if final_story:
            strategy = final_story.get("strategy", "unknown")
            chunks = len(final_story.get("retrieved_chunks", []))
            parts.append(f"Retrieval Strategy: {strategy}, Retrieved Chunks: {chunks}")
        
        return "\n".join(parts)
    
    def _parse_llm_scoring_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM response to extract scoring information"""
        try:
            # Extract JSON from response
            json_match = re.search(r'\{[^{}]*\}', response, re.DOTALL)
            if json_match:
                json_str = json_match.group(0)
                result = json.loads(json_str)
                
                # Validate score range
                score = result.get("confidence_score", 0.5)
                if not isinstance(score, (int, float)) or not (0.0 <= score <= 1.0):
                    logger.warning("Invalid LLM confidence score: %s, using 0.5", score)
                    result["confidence_score"] = 0.5
                
                return result
        except Exception as e:
            logger.warning("Failed to parse LLM scoring response: %s", e)
        
        # Fallback parsing - look for score in text
        try:
            score_match = re.search(r'(?:score|confidence)[:\s]+(\d+\.?\d*)', response.lower())
            if score_match:
                score = float(score_match.group(1))
                if score <= 1.0:
                    return {"confidence_score": score, "reasoning": "Extracted from text"}
        except:
            pass
        
        return {"confidence_score": 0.5, "reasoning": "Fallback due to parsing failure"}
    
    def _get_confidence_level(self, score: float) -> ConfidenceLevel:
        """Convert numeric score to confidence level enum"""
        if score >= 0.9:
            return ConfidenceLevel.VERY_HIGH
        elif score >= 0.7:
            return ConfidenceLevel.HIGH
        elif score >= 0.5:
            return ConfidenceLevel.MEDIUM
        elif score >= 0.3:
            return ConfidenceLevel.LOW
        else:
            return ConfidenceLevel.VERY_LOW
    
    def _build_clarification_request(
        self, 
        confidence: float, 
        rule_scores: Dict[str, float],
        scoring_details: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Build clarification request based on scoring results"""
        
        if confidence >= self.threshold:
            return {"needed": False}
        
        # Determine what kind of clarification to request based on weak areas
        weak_areas = [name for name, score in rule_scores.items() if score < 0.5]
        
        clarification_question = self._generate_clarification_question(weak_areas, rule_scores)
        
        return {
            "needed": True,
            "question": clarification_question,
            "confidence_score": confidence,
            "weak_areas": weak_areas,
            "suggested_improvements": self._get_improvement_suggestions(weak_areas)
        }
    
    def _generate_clarification_question(self, weak_areas: List[str], scores: Dict[str, float]) -> str:
        """Generate specific clarification question based on weak scoring areas"""
        
        if not weak_areas:
            return "Could you provide more details or context to help me better understand your request?"
        
        # Prioritize the most important weak areas
        question_templates = {
            "query_clarity": [
                "Could you clarify what specifically you're trying to achieve?",
                "What is the main goal or problem you're trying to solve?",
                "Could you provide more details about what you need help with?"
            ],
            "context_completeness": [
                "Could you provide more context about your project structure or codebase?",
                "What additional information about your setup would be helpful?",
                "Are there specific files or components I should focus on?"
            ],
            "entity_coverage": [
                "Could you mention specific functions, classes, or libraries you're working with?",
                "What are the key components or entities involved in your question?",
                "Are there particular technical terms or concepts I should know about?"
            ],
            "intent_confidence": [
                "Are you looking for an explanation, implementation guidance, or debugging help?",
                "What type of assistance are you seeking - learning, troubleshooting, or development?",
                "Could you clarify whether this is a question, feature request, or issue report?"
            ],
            "code_context": [
                "Could you share more of the relevant code or provide the programming language you're using?",
                "What programming language and frameworks are you working with?",
                "Are there specific code patterns or libraries I should consider?"
            ]
        }
        
        # Pick the most relevant question based on the weakest area
        primary_weak_area = min(weak_areas, key=lambda area: scores.get(area, 1.0))
        questions = question_templates.get(primary_weak_area, question_templates["query_clarity"])
        
        # For now, return the first question (could be randomized or selected based on other factors)
        return questions[0]
    
    def _get_improvement_suggestions(self, weak_areas: List[str]) -> List[str]:
        """Provide suggestions for improving the query context"""
        suggestions = []
        
        suggestion_map = {
            "query_clarity": "Be more specific about what you want to achieve",
            "context_completeness": "Provide more details about your project or environment",
            "entity_coverage": "Mention specific functions, classes, or libraries you're working with",
            "intent_confidence": "Clarify whether you need explanation, implementation, or debugging help",
            "code_context": "Include relevant code snippets or specify the programming language"
        }
        
        for area in weak_areas:
            if area in suggestion_map:
                suggestions.append(suggestion_map[area])
        
        return suggestions


# ======================================================================
# Testing functionality
# ======================================================================
if __name__ == "__main__":
    import sys
    import os
    
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    
    # Add parent directory to path for imports
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))
    
    print("\n" + "=" * 80)
    print("TESTING SCORER TOOL")  
    print("=" * 80)
    
    # Test case 1: High confidence scenario
    print("\n" + "-" * 50)
    print("TEST 1: High confidence context")
    print("-" * 50)
    
    high_confidence_context = {
        "raw_query": "How do I implement pagination in my FastAPI endpoint using Query parameters?",
        "enriched_query": "How do I implement pagination in my FastAPI endpoint using Query parameters?",
        "intent": {
            "primary": "feature_request",
            "secondary": "question", 
            "scores": {"feature_request": 0.85, "question": 0.6}
        },
        "entities": {"FastAPI", "pagination", "Query", "endpoint"},
        "code_entities": {
            "functions": [{"name": "get_items"}],
            "classes": [],
            "imports": ["fastapi", "Query"],
            "variables": [{"name": "app"}]
        },
        "language": "py",
        "final_story": {
            "enriched_query": "FastAPI pagination Query parameters endpoint implementation",
            "supporting_context": "User wants to add pagination...",
            "retrieved_chunks": [
                {"content": "def paginate(items, page, size):", "metadata": {"function_name": "paginate"}},
                {"content": "@app.get('/items')", "metadata": {"function_name": "get_items"}}
            ],
            "strategy": "specific"
        },
        "repo_map": {
            "structured": {"files": {"app.py": {}}},
            "text": "FastAPI project structure"
        }
    }
    
    scorer = ScorerTool(high_confidence_context, threshold=0.7)
    result = scorer.run()
    
    print(f"Confidence: {result['confidence']:.3f}")
    print(f"Clarification needed: {result['clarification']['needed']}")
    print(f"Confidence level: {result['scoring_details']['confidence_level']}")
    print(f"Rule breakdown: {result['scoring_details']['rule_breakdown']}")
    
    # Test case 2: Low confidence scenario
    print("\n" + "-" * 50)
    print("TEST 2: Low confidence context")
    print("-" * 50)
    
    low_confidence_context = {
        "raw_query": "help me",
        "enriched_query": "Help me",
        "intent": {"primary": "general", "scores": {"general": 0.2}},
        "entities": set(),
        "code_entities": {},
        "language": None,
        "final_story": {
            "enriched_query": "help me",
            "supporting_context": "Very minimal context",
            "retrieved_chunks": [],
            "strategy": "fallback"
        }
    }
    
    scorer_low = ScorerTool(low_confidence_context, threshold=0.7)
    result_low = scorer_low.run()
    
    print(f"Confidence: {result_low['confidence']:.3f}")
    print(f"Clarification needed: {result_low['clarification']['needed']}")
    print(f"Clarification question: {result_low['clarification']['question']}")
    print(f"Weak areas: {result_low['clarification'].get('weak_areas', [])}")
    
    # Test case 3: Medium confidence with code
    print("\n" + "-" * 50)  
    print("TEST 3: Medium confidence with code context")
    print("-" * 50)
    
    medium_confidence_context = {
        "raw_query": """
        I have this FastAPI code but it's not working:
        
        from fastapi import FastAPI
        app = FastAPI()
        
        @app.get("/items")
        def get_items():
            return {"items": []}
        """,
        "enriched_query": "FastAPI code not working",
        "intent": {"primary": "issue_report", "scores": {"issue_report": 0.7}},
        "entities": {"FastAPI", "code", "items"},
        "code_entities": {
            "functions": [{"name": "get_items"}],
            "classes": [],
            "imports": ["fastapi", "FastAPI"],
            "variables": [{"name": "app"}]
        },
        "language": "py",
        "final_story": {
            "enriched_query": "FastAPI endpoint not working",
            "supporting_context": "Code provided but issue unclear",
            "retrieved_chunks": [
                {"content": "FastAPI example", "metadata": {"file_path": "examples.py"}}
            ],
            "strategy": "specific"
        }
    }
    
    scorer_med = ScorerTool(medium_confidence_context, threshold=0.7)
    result_med = scorer_med.run()
    
    print(f"Confidence: {result_med['confidence']:.3f}")
    print(f"Clarification needed: {result_med['clarification']['needed']}")
    if result_med['clarification']['needed']:
        print(f"Clarification question: {result_med['clarification']['question']}")
    
    print("\n" + "=" * 80)
    print("SCORER TOOL TESTING COMPLETE")
    print("=" * 80 + "\n")