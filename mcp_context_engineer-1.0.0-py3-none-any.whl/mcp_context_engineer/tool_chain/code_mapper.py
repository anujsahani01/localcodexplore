# mcp_context_engineer/mcp_context_engineer/tool_chain/code_mapper.py

import logging
import sqlite3
from pathlib import Path
from typing import Dict, Any, List, Set

logger = logging.getLogger(__name__)


# Path to the pre-computed repo map database
DEFAULT_DB_PATH = Path.home() / ".LocalXplore" / "DS3.db"
TABLE_NAME = "master_code_repo"

# Keywords that indicate the user wants a workspace-level answer,
# not a targeted lookup.  Checked against the lowercased raw query.
BROAD_QUERY_INDICATORS = [
    "all functions", "all classes", "all imports", "all files",
    "all modules", "all methods", "all variables",
    "every function", "every class", "every file",
    "list functions", "list classes", "list files", "list imports",
    "list methods", "list modules",
    "overview", "summary", "structure", "architecture",
    "entire", "whole workspace", "whole project", "whole codebase",
    "what frameworks", "what libraries", "how many",
    "describe the project", "explain the project",
    "walk me through", "give me a map", "repo map",
]

# File extensions that are always included in filtered output
ALWAYS_INCLUDE_EXTENSIONS = {"md", "markdown", "rst", "txt"}


class CodeMapperTool:
    """
    Loads a pre-computed repository map from SQLite, parses it into
    a structured dictionary, and attaches the relevant portion to the
    pipeline context.

    No retrieval calls are made.  This is a purely local, read-only
    operation against the indexing database.

    Context contract
    ----------------
    Reads:
        workspace, version, raw_query, entities, code_entities, language
    Writes:
        repo_map  ->  {structured, text, is_full_map,
                       total_files_in_workspace, files_in_context}
    """

    def __init__(
        self,
        context: Dict[str, Any],
        db_path: Path = DEFAULT_DB_PATH,
    ):
        self.context = context
        self.workspace_path = context.get("workspace", "")
        self.version = context.get("version", "1")
        self.workspace_name = self._resolve_workspace_name()
        self.db_path = Path(db_path)


    def _resolve_workspace_name(self) -> str:
        """
        Derive the DB workspace name from the workspace path and version.

        Convention:  <last_directory>_<version>
        Example:     D:\\work_dsi\\ASI84\\new_test_del  +  version=1
                     ->  new_test_del_1
        """
        workspace = self.workspace_path.rstrip("/\\")
        last_dir = Path(workspace).name
        name = f"{last_dir}_{self.version}"
        logger.info("CodeMapper: Resolved workspace name '%s'", name)
        return name

    # ==================================================================
    # Public entry point
    # ==================================================================
    def run(self) -> Dict[str, Any]:
        logger.info(
            "CodeMapper: workspace_path='%s', workspace_name='%s', version='%s'",
            self.workspace_path, self.workspace_name, self.version,
        )

        # 1 -- Load raw text from DB
        raw_map = self._load_repo_map_from_db()
        if not raw_map:
            logger.warning("CodeMapper: No repo map found, skipping")
            self.context["repo_map"] = None
            return self.context

        # 2 -- Parse into structured dict
        parsed = self._parse_repo_map(raw_map)
        logger.info(
            "CodeMapper: Parsed %d files from repo map",
            parsed["summary"]["total_files"],
        )

        # 3 -- Decide: full map vs filtered
        needs_full = self._is_broad_query()
        logger.info("CodeMapper: Broad query = %s", needs_full)

        if needs_full:
            output = parsed
        else:
            output = self._filter_repo_map(parsed)
            logger.info(
                "CodeMapper: Filtered to %d / %d files",
                len(output["files"]),
                parsed["summary"]["total_files"],
            )

        # 4 -- Format compact text for LLM consumption
        context_text = self._format_for_context(output)

        # 5 -- Attach to pipeline context
        self.context["repo_map"] = {
            "structured": output,
            "text": context_text,
            "is_full_map": needs_full,
            "total_files_in_workspace": parsed["summary"]["total_files"],
            "files_in_context": len(output["files"]),
        }
        return self.context

    # ==================================================================
    # Database layer
    # ==================================================================

    def _load_repo_map_from_db(self) -> str | None:
        if not self.db_path.exists():
            logger.error("CodeMapper: DB not found at %s", self.db_path)
            return None

        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute(
                f"SELECT repo_map FROM {TABLE_NAME} "
                "WHERE workspace_name = ? AND version = ?",
                (self.workspace_name, self.version),
            )
            row = cursor.fetchone()
            conn.close()

            if row and row[0]:
                logger.info("CodeMapper: Loaded repo map (%d chars)", len(row[0]))
                return row[0]

            logger.warning(
                "CodeMapper: No DB row for workspace_name='%s', version='%s'",
                self.workspace_name, self.version,
            )
            return None

        except Exception as e:
            logger.error("CodeMapper: DB error: %s", e)
            return None

    # ==================================================================
    # Parser:  raw text  -->  structured dict
    # ==================================================================

    def _parse_repo_map(self, raw_text: str) -> Dict[str, Any]:
        """
        Convert the flat repo-map text into::

            {
              "files": {
                "app.py": {
                  "path": ".\\app.py",
                  "extension": "py",
                  "imports": [...],
                  "classes": [{"name": ..., "signature": ...}],
                  "functions": [{"name": ..., "signature": ...}],
                  "variables": [{"name": ..., "value": ...}]
                }, ...
              },
              "summary": { ... }
            }
        """
        files: Dict[str, Dict] = {}
        current_file: str | None = None

        for line in raw_text.split("\n"):
            stripped = line.strip()
            if not stripped:
                continue

            # ---- New file boundary ----
            if stripped.startswith(".\\") or stripped.startswith("./"):
                filename = stripped.lstrip(".").lstrip("\\/")
                current_file = filename
                ext = filename.rsplit(".", 1)[-1] if "." in filename else ""
                files[current_file] = {
                    "path": stripped,
                    "extension": ext.lower(),
                    "imports": [],
                    "classes": [],
                    "functions": [],
                    "variables": [],
                }
                continue

            if current_file is None:
                continue

            entry = files[current_file]

            # ---- Imports ----
            if stripped.startswith("imports:"):
                tokens = stripped[len("imports:"):].strip()
                entry["imports"] = [
                    t.strip() for t in tokens.split(",") if t.strip()
                ]

            # ---- Class ----
            elif stripped.startswith("class "):
                name = (
                    stripped[len("class "):]
                    .split("(")[0]
                    .split(":")[0]
                    .strip()
                )
                entry["classes"].append(
                    {"name": name, "signature": stripped}
                )

            # ---- Function ----
            elif stripped.startswith("def ") or stripped.startswith("async def "):
                clean = stripped.replace("async ", "")
                name = clean[len("def "):].split("(")[0].strip()
                entry["functions"].append(
                    {"name": name, "signature": stripped}
                )

            # ---- Variable / other ----
            else:
                if "=" in stripped and not stripped.startswith("#"):
                    var_name = stripped.split("=", 1)[0].strip()
                    # Basic sanity: must look like a valid identifier
                    if var_name.replace("_", "").replace(".", "").isalnum():
                        entry["variables"].append(
                            {"name": var_name, "value": stripped}
                        )

        summary = self._build_summary(files)
        return {"files": files, "summary": summary}

    @staticmethod
    def _build_summary(files: Dict[str, Dict]) -> Dict[str, Any]:
        all_imports: Set[str] = set()
        all_functions: List[Dict] = []
        all_classes: List[Dict] = []
        extensions: Set[str] = set()

        for filename, data in files.items():
            ext = data.get("extension", "")
            if ext:
                extensions.add(ext)
            all_imports.update(data.get("imports", []))

            for func in data.get("functions", []):
                all_functions.append({
                    "name": func["name"],
                    "file": filename,
                    "signature": func["signature"],
                })
            for cls in data.get("classes", []):
                all_classes.append({
                    "name": cls["name"],
                    "file": filename,
                    "signature": cls["signature"],
                })

        return {
            "total_files": len(files),
            "languages": sorted(extensions),
            "all_imports": sorted(all_imports),
            "all_functions": all_functions,
            "all_classes": all_classes,
            "file_list": sorted(files.keys()),
        }

    # ==================================================================
    # Query classification:  broad  vs  specific
    # ==================================================================

    def _is_broad_query(self) -> bool:
        raw_query = self.context.get("raw_query", "").lower()
        code_entities = self.context.get("code_entities")

        # If user pasted actual code, the query is specific
        has_code = bool(
            code_entities
            and (code_entities.get("functions") or code_entities.get("classes"))
        )
        if has_code:
            return False

        # Check for broad-scope phrases
        for indicator in BROAD_QUERY_INDICATORS:
            if indicator in raw_query:
                return True

        # If context engineer found no meaningful entities, treat as broad
        entities = self.context.get("entities", set())
        if not entities and not code_entities:
            return True

        return False

    # ==================================================================
    # Filtering:  keep only files that match extracted signals
    # ==================================================================

    def _filter_repo_map(self, parsed_map: Dict) -> Dict:
        """
        Keep files whose symbols overlap with the extracted entities.
        Always keep .md / doc files.
        Falls back to full map if filtering removes everything.
        """
        search_terms = self._collect_search_terms()
        allowed_extensions = self._resolve_extensions()

        # Dynamic noise removal: drop terms that match too many files
        if search_terms:
            search_terms = self._remove_noisy_terms(search_terms, parsed_map["files"])

        relevant: Dict[str, Dict] = {}

        for filename, data in parsed_map["files"].items():
            ext = data.get("extension", "")

            # Always include documentation files
            if ext in ALWAYS_INCLUDE_EXTENSIONS:
                relevant[filename] = data
                continue

            # Extension gate (only when we know the language)
            if allowed_extensions and ext and ext not in allowed_extensions:
                continue

            # Symbol match
            if self._file_matches(data, search_terms):
                relevant[filename] = data

        # Safety: never return empty
        if not relevant:
            logger.info("CodeMapper: Filter matched nothing, returning full map")
            return parsed_map

        # Always attach the full summary so downstream tools see
        # the complete function/class lists regardless of filtering
        return {
            "files": relevant,
            "summary": parsed_map["summary"],
        }
    

    # if the term is used in too many files then that's useless of us.
    def _remove_noisy_terms(
        self,
        terms: Set[str],
        files: Dict[str, Dict],
        threshold: float = 0.7,
    ) -> Set[str]:
        """
        Remove search terms that match more than `threshold` fraction of
        files.  Such terms have no discriminating power regardless of
        language.

        Example: "import" appears in every Python file -> useless as filter.
        """
        total = len(files)
        if total == 0:
            return terms

        clean: Set[str] = set()
        for term in terms:
            match_count = sum(
                1 for data in files.values()
                if self._file_matches(data, {term})
            )
            ratio = match_count / total
            if ratio <= threshold:
                clean.add(term)
            else:
                logger.info(
                    "CodeMapper: Dropping noisy term '%s' (matches %d/%d files, %.0f%%)",
                    term, match_count, total, ratio * 100,
                )

        if not clean:
            logger.warning(
                "CodeMapper: All search terms were noisy, keeping original set"
            )
            return terms

        logger.info("CodeMapper: Search terms after noise removal (%d): %s", len(clean), sorted(clean))
        return clean

    def _collect_search_terms(self) -> Set[str]:
        """Gather all searchable tokens from context."""
        terms: Set[str] = set()

        # NLP entities
        for entity in self.context.get("entities", set()):
            terms.add(str(entity).lower())

        # Code entities
        code_entities = self.context.get("code_entities") or {}

        for func in code_entities.get("functions", []):
            name = func.get("name") if isinstance(func, dict) else str(func)
            if name:
                terms.add(name.lower())

        for cls in code_entities.get("classes", []):
            name = cls.get("name") if isinstance(cls, dict) else str(cls)
            if name:
                terms.add(name.lower())

        for imp in code_entities.get("imports", []):
            if isinstance(imp, str):
                terms.add(imp.lower())

        for var in code_entities.get("variables", []):
            name = var.get("name") if isinstance(var, dict) else str(var)
            if name:
                terms.add(name.lower())

        # Remove noise tokens (very short or common)
        terms.discard("")
        # filtering our single character terms
        return {t for t in terms if len(t) > 2}

    def _resolve_extensions(self) -> Set[str]:
        """
        Determine which file extensions are relevant.
        Derived from the language detected by ContextEngineer.
        Always includes ALWAYS_INCLUDE_EXTENSIONS.
        """
        from utils import ast_parsers_nodes as astcst

        allowed = set(ALWAYS_INCLUDE_EXTENSIONS)
        language = self.context.get("language")

        if language:
            # language might be an extension ("py") or a language name ("python")
            for lang_name, exts in astcst.MAP_LANG_EXTENSIONS.items():
                if language == lang_name or language in exts:
                    allowed.update(exts)
                    logger.info(
                        "CodeMapper: Language '%s' resolved to extensions: %s",
                        language, sorted(allowed),
                    )
                    break
            else:
                # If not found in map, just add it directly
                allowed.add(language)
                logger.info(
                    "CodeMapper: Language '%s' not in MAP_LANG_EXTENSIONS, "
                    "using as-is", language)
        else:
            # No language detected -- do not filter by extension at all.
            # Empty set signals "allow everything" to the caller.
            logger.info("CodeMapper: No language detected, skipping extension filter")
            return set()
        
        return allowed

    @staticmethod
    def _file_matches(file_data: Dict, search_terms: Set[str]) -> bool:
        """Check if any search term matches any symbol in the file."""
        if not search_terms:
            return True  # No terms = include everything

        # Build a set of all symbols in this file (lowered)
        symbols: Set[str] = set()
        symbols.update(s.lower() for s in file_data.get("imports", []))
        for f in file_data.get("functions", []):
            symbols.add(f["name"].lower())
        for c in file_data.get("classes", []):
            symbols.add(c["name"].lower())
        for v in file_data.get("variables", []):
            symbols.add(v["name"].lower())

        # Substring match in both directions
        for term in search_terms:
            for sym in symbols:
                if term in sym or sym in term:
                    return True
        return False

    # ==================================================================
    # Formatting:  structured dict  -->  compact text for LLM
    # ==================================================================

    def _format_for_context(self, parsed_map: Dict) -> str:
        """
        Produce a compact text block that an LLM can read as context.
        """
        lines: List[str] = []
        summary = parsed_map["summary"]

        lines.append("=== REPOSITORY MAP ===")
        lines.append(
            f"Total files: {summary['total_files']} | "
            f"Extensions: {', '.join(summary['languages'])}"
        )

        # Top-level imports (deduplicated across all files)
        if summary["all_imports"]:
            lines.append(
                f"Workspace imports: {', '.join(summary['all_imports'])}"
            )

        lines.append("")

        # Per-file section
        for filename in sorted(parsed_map["files"]):
            data = parsed_map["files"][filename]
            lines.append(f"[{filename}]")

            if data["imports"]:
                lines.append(f"  imports: {', '.join(data['imports'])}")

            for cls in data["classes"]:
                lines.append(f"  {cls['signature']}")

            for func in data["functions"]:
                lines.append(f"  {func['signature']}")

            # Limit variables to avoid bloating context
            for var in data["variables"][:5]:
                lines.append(f"  {var['value']}")
            if len(data["variables"]) > 5:
                lines.append(
                    f"  ... and {len(data['variables']) - 5} more variables"
                )

            lines.append("")

        return "\n".join(lines)


# ======================================================================
# Testing
# ======================================================================
if __name__ == "__main__":
    import sys
    import os

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    print("\n" + "=" * 80)
    print("TESTING CODE MAPPER TOOL")
    print("=" * 80)

    # ------------------------------------------------------------------
    # Test 1: Broad query (should return full map)
    # ------------------------------------------------------------------
    print("\n" + "-" * 80)
    print("TEST 1: Broad query - 'list all functions used in the workspace'")
    print("-" * 80)

    broad_context = {
        "raw_query": "list all functions used in the workspace",
        "workspace": r"D:\work_dsi\ASI84\temp_test_mcp",
        "version": "1",
        "intent": {"primary": "question", "secondary": None, "scores": {}},
        "entities": set(),
        "code_entities": None,
    }

    mapper_broad = CodeMapperTool(broad_context)
    result_broad = mapper_broad.run()
    repo_map_broad = result_broad.get("repo_map")

    if repo_map_broad:
        print(f"\n  Is full map: {repo_map_broad['is_full_map']}")
        print(f"  Total files in workspace: {repo_map_broad['total_files_in_workspace']}")
        print(f"  Files in context: {repo_map_broad['files_in_context']}")

        summary = repo_map_broad["structured"]["summary"]
        print(f"\n  All functions ({len(summary['all_functions'])}):")
        for func in summary["all_functions"]:
            print(f"    {func['file']}:  {func['signature']}")

        print(f"\n  All classes ({len(summary['all_classes'])}):")
        for cls in summary["all_classes"]:
            print(f"    {cls['file']}:  {cls['signature']}")

        print(f"\n  All imports: {', '.join(summary['all_imports'][:20])}")
        print(f"\n  Formatted text preview (first 500 chars):")
        print(f"  {repo_map_broad['text'][:500]}")
    else:
        print("\n  No repo map found (DB may not exist at expected path)")

    # ------------------------------------------------------------------
    # Test 2: Specific query with code entities (should filter)
    # ------------------------------------------------------------------
    print("\n" + "-" * 80)
    print("TEST 2: Specific query - pagination with code entities")
    print("-" * 80)

    specific_context = {
        "raw_query": "How do I add pagination to my FastAPI endpoint?",
        "workspace": r"D:\work_dsi\ASI84\temp_test_mcp",
        "version": "1",
        "intent": {"primary": "question", "secondary": None, "scores": {}},
        "entities": {"FastAPI", "pagination"},
        "code_entities": {
            "functions": [{"name": "get_items"}],
            "classes": [],
            "imports": ["fastapi", "typing"],
            "variables": [{"name": "app"}],
        },
        "language": "py",
    }

    mapper_specific = CodeMapperTool(specific_context)
    result_specific = mapper_specific.run()
    repo_map_specific = result_specific.get("repo_map")

    if repo_map_specific:
        print(f"\n  Is full map: {repo_map_specific['is_full_map']}")
        print(f"  Total files in workspace: {repo_map_specific['total_files_in_workspace']}")
        print(f"  Files in context: {repo_map_specific['files_in_context']}")

        print(f"\n  Filtered files:")
        for fname in repo_map_specific["structured"]["files"]:
            print(f"    - {fname}")

        print(f"\n  Formatted text preview (first 500 chars):")
        print(f"  {repo_map_specific['text'][:500]}")
    else:
        print("\n  No repo map found (DB may not exist at expected path)")

    # ------------------------------------------------------------------
    # Test 3: Full pipeline - ContextEngineer -> CodeMapper
    # ------------------------------------------------------------------
    print("\n" + "-" * 80)
    print("TEST 3: Full pipeline - ContextEngineer -> CodeMapper")
    print("-" * 80)

    try:
        sys.path.insert(
            0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
        )
        from mcp_context_engineer.tool_chain.context_engineer import ContextEngineer

        pipeline_context = {
            "raw_query": """
                I'm trying to add pagination to a FastAPI endpoint.

                from fastapi import FastAPI, Query
                from typing import List

                app = FastAPI()

                @app.get("/items")
                def get_items(page: int = Query(1, ge=1), size: int = Query(10, ge=1)):
                    items = [f"item-{i}" for i in range(1, 101)]
                    start = (page - 1) * size
                    end = start + size
                    return {"page": page, "size": size, "items": items[start:end]}
            """,
            "workspace": r"D:\work_dsi\ASI84\temp_test_mcp",
            "version": "1",
        }

        # Step 1: Context Engineering
        print("\n  Running ContextEngineer...")
        ce = ContextEngineer(pipeline_context)
        enriched = ce.enrich_query()

        # Merge enriched output back into context
        pipeline_context.update(enriched)

        print(f"  Intent: {pipeline_context.get('intent')}")
        print(f"  Entities: {pipeline_context.get('entities')}")
        print(f"  Code entities: {pipeline_context.get('code_entities') is not None}")
        print(f"  Language: {pipeline_context.get('language')}")

        # Step 2: Code Mapper
        print("\n  Running CodeMapper...")
        mapper = CodeMapperTool(pipeline_context)
        final = mapper.run()
        repo_map = final.get("repo_map")

        if repo_map:
            print(f"  Is full map: {repo_map['is_full_map']}")
            print(f"  Files in context: {repo_map['files_in_context']}")
            print(f"\n  Filtered files:")
            for fname in repo_map["structured"]["files"]:
                print(f"    - {fname}")
        else:
            print("  No repo map available")

    except Exception as e:
        print(f"\n  Pipeline test skipped: {e}")
        import traceback
        traceback.print_exc()

    print("\n" + "=" * 80)
    print("TESTING COMPLETE")
    print("=" * 80 + "\n")