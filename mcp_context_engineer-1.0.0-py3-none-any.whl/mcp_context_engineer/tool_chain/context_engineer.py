# mcp_context_engineer/mcp_context_engineer/context_engineer.py

import logging
from typing import Dict, Any, Set
from collections import defaultdict
import json
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# use huggingface
# from mcp_context_engineer.utils.huggingface_llm import LLMClient
# use dev assistant
from utils.devassistant_llm import LLMClient
from utils import ast_parsers_nodes as astcst

# for validating the json schema
import json
from jsonschema import validate, ValidationError, Draft202012Validator
from tree_sitter_language_pack import get_binding, get_language, get_parser



# ----------------------------------------------------------------------
# Optional heavy‑weight NLP – we try to import spaCy, otherwise fall back
# to a lightweight regex‑based extractor.  This keeps the package usable
# even when spaCy isn’t installed.
# ----------------------------------------------------------------------
try:
    import spacy
    _nlp = spacy.load("en_core_web_sm")
except Exception:          # pragma: no cover
    _nlp = None


# Import environment loading from utils
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from utils.devassistant_llm import _load_environment
_load_environment()

import base64
import os

# using HuggingFace LLM
# _HUGGINGFACE_TOKEN: str = base64.b64encode(os.getenv("ACCESS_TOKEN").encode("utf-8"))
# _MODEL: str = os.getenv("MODEL_NAME", "Qwen/Qwen2.5-Coder-7B")
# client = LLMClient(api_key = _HUGGINGFACE_TOKEN,
#                     model = _MODEL)

# using dev assistant
client = LLMClient()

def encode_code(encoded_str: str) -> str:
    decoded_bytes = base64.b64decode(encoded_str)
    return decoded_bytes.decode("utf-8")



def decode_code(code_b64: str) -> str:
    return base64.b64decode(code_b64.encode()).decode()

"""
when we get a json, sometimes we get a validation error as the code key might have "" inside of it.
"""

# ----------------------------------------------------------------------
# Helper: repair a broken JSON string that contains un‑escaped quotes
# ----------------------------------------------------------------------
def _repair_json_with_code(raw: str) -> str:
    code_match = re.search(r'"code"\s*:\s*"([^"]*)"', raw, flags=re.DOTALL)
    if not code_match:
        return raw

    # Grab everything up to the next *unescaped* quote
    start = code_match.end(1)
    end = start
    while end < len(raw):
        if raw[end] == '"' and raw[end - 1] != '\\':
            break
        end += 1

    broken_code = raw[code_match.start(1):end]
    escaped_code = json.dumps(broken_code)[1:-1]   # strip outer quotes added by dumps
    repaired = raw[:code_match.start(1)] + escaped_code + raw[end:]
    return repaired



# making sure of extracting json from llm repsonse
def _extract_json_from_text(text: str) -> str:
    """
    Remove common wrappers (markdown fences, leading explanations, etc.)
    and return the first JSON object/array found in *text*.
    If nothing looks like JSON, return an empty string.
    """
    # Step 1: Trim whitespace
    txt = text.strip()

    # Step 2: Remove markdown fences (```json ... ```) if present
    txt = re.sub(r"^```(?:json)?\s*", "", txt, flags=re.IGNORECASE)
    txt = re.sub(r"\s*```$", "", txt)

    # Step 3: Find the first `{` … `}` or `[` … `]` block
    #    (non‑greedy, stops at the matching closing brace)
    match = re.search(r"(\{.*?\}|\[.*?\])", txt, flags=re.DOTALL)
    return match.group(1) if match else ""


class ContextEngineer:
    def __init__(self, context: Dict[str, Any] | None = None, logger: logging.Logger = logger):
        self.logger = logger
        self.context = context
        self.parsers = {}

    def enrich_query(self) -> Dict[str, Any]:
        """
        Enriches the raw user query, extracts intent & entities,
        and adds any user-provided context.

        Returns:
            Dict[str, Any]: The updated context with enriched query, intent, and entities.
        """
        self.logger.info("Starting context engineering process.")
        # updated_context = self.context_engineering_tool.run()
        updated_context = self.intent_entity_extraction()
        self.logger.info("Context engineering process completed.")
        return updated_context
    
    def intent_entity_extraction(self) -> Dict[str, Any]:
        """
        Extracts a high-level *intent* and a set of *named entities*
        from the (already) enriched user query.

        Returns
        dict
            ``{\"intent\": <str>, \"entities\": <set[str]>}``
        """
        query = self.context.get("enriched_query") or self.context.get("raw_query", "")
        if not query:
            self.logger.warning("No query found for intent/entity extraction.")
            return {"intent": None, "entities": set()}

        # Intent detection – simple rule‑based classifier
        intent = self._detect_intent(query)

        # Entity extraction – spaCy if available, else regex fallback
        entities = self._extract_entities(query)

        self.logger.info(f"Detected intent: {intent}")
        self.logger.info(f"Extracted entities: {entities}")


        has_code, code_entities = self.code_entity_extraction()
        logger.info(f"The user user code detection:  {has_code}")
        logger.info(f"The code entities detected from the user query is : {code_entities}")

        if has_code.get("has_code").lower() == "yes":
            return {"intent": intent, "entities": entities, "code_entities": code_entities, "language":has_code.get("extension")}
        else:
            return {"intent": intent, "entities": entities}



    def _detect_intent(self, text: str) -> str:
        lowered = text.lower()
        scores = defaultdict(int)

        # list of basic intents
        intent_keywords = {
            "question": ["how", "what", "why", "when", "where", "which"],
            "issue_report": ["error", "exception", "traceback", "bug", "fail", "not working", "crash"],
            "feature_request": ["add", "implement", "support", "enable", "create", "should have"],
            "comparison": ["vs", "compare", "difference", "better"],
            "instruction": ["guide", "steps", "tutorial", "walkthrough"]
        }


        # adding weights to different intents
        with open(r'./utils/intent_keywords.json', 'r') as file:
            intent_keywords_weights = json.load(file)

        
        for intent, keywords in intent_keywords.items():
            for keyword in keywords:
                if keyword in lowered:
                    scores[intent] += intent_keywords_weights[intent].get(keyword)

        sorted_intents = sorted(scores.items(), key=lambda x: x[1], reverse=True)

        if not scores:
            return "general"
        
        return {
            "primary": sorted_intents[0][0] if sorted_intents else "general",
            "secondary": sorted_intents[1][0] if len(sorted_intents) > 1 else None,
            "scores": dict(scores)
        }


    def _extract_entities(self, text: str) -> Set[str]:
        """Extract named entities using spaCy if present, otherwise a tiny regex."""
        entities: Set[str] = set()

        if _nlp:   # spaCy is available
            doc = _nlp(text)
            for ent in doc.ents:
                entities.add(ent.text)
        else:       
            # Very small regex fallback – captures camelCase, snake_case, and
            # dot‑separated identifiers that look like code symbols.
            import re
            pattern = r"\b([A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*|[A-Za-z_][A-Za-z0-9_]*|[A-Z][a-z]+(?:[A-Z][a-z]+)+)\b"
            for match in re.finditer(pattern, text):
                entities.add(match.group(0))

        return entities
    

    def _load_language(self, extension, language_name: str):
        """
        Load the language parser for the given file language.

        :param extension: The file extension.
        :param language_name: The coding language
        """

        code_binding = get_binding(
            language_name
        )  # this is a pycapsule object pointing to the C binding
        code_lang = get_language(
            language_name
        )  # this is an instance of tree_sitter.Language
        code_parser = get_parser(
            language_name
        )  # this is an instance of tree_sitter.Parser

        # CODE_LANGUAGE = Language(java_language.language())
        # parser = Parser(CODE_LANGUAGE)
        return code_parser


    def _get_parser_for_extension(self, extension: str):
        """
        Get the parser for the given file extension.

        :param extension: The file extension.
        """
        language_name = ""
        if extension not in self.parsers:
            logging.info(f"Loading parser for extension: {extension}")
            for language, extensions in astcst.MAP_LANG_EXTENSIONS.items():
                if extension in extensions:
                    language_name = language
                    self.parsers[extension] = self._load_language(
                        extension, language_name
                    )
                    return self.parsers[extension], language_name
            print(f"NOT ABLE TO FIND A PARSER FOR {extension}.")
            return None, None
        else:
            for language, extensions in astcst.MAP_LANG_EXTENSIONS.items():
                if extension in extensions:
                    language_name = language
            return self.parsers[extension], language_name


    def extract_entities(self, node, code, language):
        result = {
            "imports": [],
            "classes": [],
            "functions": [],
            "variables": []
        }

        def traverse(node, inside_function=False):
            node_text = code[node.start_byte: node.end_byte]

            # IMPORTS
            if node.type in astcst.IMPORT_NODE_TYPES:
                result["imports"].append(node_text)

            # CLASSES
            elif node.type in astcst.CLASS_NODE_TYPES:
                result["classes"].append({
                    "name": self._get_class_name(node, code),
                    "content": node_text
                })

            # FUNCTIONS
            elif node.type in astcst.FUNCTION_NODE_TYPES or node.type in astcst.DECORATOR_NODE_TYPES:
                result["functions"].append({
                    "name": self._get_function_name(node, code),
                    "content": node_text
                })
                inside_function = True  # mark context

            # VARIABLES
            elif node.type in astcst.CLASS_VARIABLE_NAMES:
                var_name = code[node.start_byte: node.end_byte]

                result["variables"].append({
                    "name": var_name,
                    "scope": "local" if inside_function else "global"
                })

            # Traverse children
            for child in node.children:
                traverse(child, inside_function)

        traverse(node)
        return result
    

    def _get_class_name(self, node, code):
        for child in node.children:
            if child.type == "identifier":
                return code[child.start_byte:child.end_byte]
        return None

    def _get_function_name(self, node, code):
        for child in node.children:
            if child.type == "identifier":
                return code[child.start_byte:child.end_byte]
        return None


    def code_entity_extraction(self) -> Dict[str, Any]:
        """
        Identifies the code entities from the user query
        Format:
        {   
            "functions": set(),
            "classes": set(),
            "imports": set(),
            "variables": set(),
            "calls": set(),
            "attributes": set()
        }
        """
        # checking if we have a code block present in the input prompt
        with open(r"mcp_context_engineer\prompts_and_schema\code_search.txt", "r", encoding="utf-8") as f:
            template = f.read()

        raw_query = self.context.get("raw_query") or ""
        query = template.replace("{content}", raw_query)
        logger.info(f"The input query for the code search is : {query}")
        search_raw = client.simple_chat(
            user_content = query, 
            temperature=0.0,
            max_tokens = 10000
        )

        logger.info(f"The raw output from the llm for code search is : {search_raw}")
        search_json_str = _extract_json_from_text(search_raw)

        # If that fails, attempt a repair (un‑escaped quotes)
        if not search_json_str:
            self.logger.warning("Initial JSON extraction failed - trying repair.")
            repaired = _repair_json_with_code(search_raw)
            search_json_str = _extract_json_from_text(repaired)

        if not search_json_str:
            logger.warning("LLM returned no JSON for code-search. Raw output:\n%s", search_raw)
            search_output = None

        else:
            try:
                search_output = json.loads(search_json_str)
                logger.info(f"Successfully read the json: {search_output}")

            except:
                try:
                    logger.info(f"Failed to read the string as JSON in first attempt")
                    # Validate against the schema (quick sanity check)
                    # If the model gave us a base‑64 payload, decode it now
                    # we decoded the code so we don't face any schema issues -- so decoding it
                    # if isinstance(search_output.get("code"), str):
                    #     code_val = search_output["code"]
                    #     if re.fullmatch(r"[A-Za-z0-9+/=]+", code_val):
                    #         search_output["code"] = encode_code(code_val)

                    with open(r"mcp_context_engineer\prompts_and_schema\code_search_schema.json", "r") as file:
                        code_search_schema = json.load(file)
                    validate(instance=search_output, schema=code_search_schema)

                    # we will encode the code as we decoded it just to pass the schema validation
                    if isinstance(search_output.get("code"), str):
                        code_val = search_output["code"]
                        if re.fullmatch(r"[A-Za-z0-9+/=]+", code_val):
                            search_output["code"] = decode_code(code_val)

                    logger.info(f"Schema validation done successfully")
                    logger.info(f"The query after decoding the code block is: {search_output}")

                except (json.JSONDecodeError, ValidationError) as e:
                    logger.warning("Failed to parse/validate code-search JSON: %s\nRaw LLM output:\n%s", e, search_raw)
                    search_output = None

        entity_output = None
        print(search_output, type(search_output))
        if search_output and search_output.get("has_code") == "yes" and search_output.get("extension"):

            # as the code is present we will be using tree sitter to extract the code form the given user query: 
            # extrcating the code 

            # we will encode the code as we decoded it just to pass the schema validation
            if isinstance(search_output.get("code"), str):
                code_val = search_output["code"]
                if re.fullmatch(r"[A-Za-z0-9+/=]+", code_val):
                    search_output["code"] = decode_code(code_val)
            
            code_block = search_output.get("code")

            logger.info(f"The extracted code block looks like: {code_block}")
            
            extension = search_output.get("extension")
            logger.info(f"The extrcated code block looks like: \n {code_block}")

            parser, language = self._get_parser_for_extension(extension)
            if parser is None:
                logging.warning("PARSER NOT FOUND!!!")
            
            tree = parser.parse(bytes(code_block, "utf8")) 
            root_node = tree.root_node
            # extracting the code entities using tree sitter along with class and function name
            entity_output = self.extract_entities(root_node, code_block, language)

            logger.info(f"The extracted code entities looks like: {entity_output}")


            # with open(r"mcp_context_engineer\prompts_and_schema\code_entity_extraction.txt", "r", encoding="utf-8") as f:
            #     template = f.read()

            # # The format can easily fail if we have code inside the raw query
            # # query = template.format(content=self.context.get("raw_query"))

            # query = template.replace("{content}", raw_query)
            # entity_raw = client.simple_chat(
            #     user_content=query,
            #     temperature=0.7,          # deterministic JSON again
            #     max_tokens=1028
            # )

            # logger.info(f"The raw output from the llm for code entity detection is : {entity_raw}")


            # entity_json_str = _extract_json_from_text(entity_raw)
            # if not entity_json_str:
            #     logger.warning("LLM returned no JSON for code-entity extraction. Raw output:\n%s", entity_raw)
            #     entity_output = None
            # else:
            #     try:
            #         entity_output = json.loads(entity_json_str)
            #         with open(r"mcp_context_engineer\prompts_and_schema\code_entity_extraction.json", "r") as file:
            #             entity_schema = json.load(file)
            #         validate(instance=entity_output, schema=entity_schema)
            #     except (json.JSONDecodeError, ValidationError) as e:
            #         logger.warning("Failed to parse/validate entity JSON: %s\nRaw LLM output:\n%s", e, entity_raw)
            #         entity_output = None
        
            # if search_output.get("has_code") == "yes":
            #     logger.info(f"The llm failed to determine the language of the code written in the user query")
            # else:
            #     logger.info(f"No code block is present in the query")

        return search_output, entity_output
    

# Testing
if __name__ == "__main__":
    context = {
        # "raw_query": "How do I implement pagination in my application?"
        "raw_query": """
                    Hey, I'm trying to add pagination to a FastAPI endpoint but I'm not sure how to slice the data correctly. Could you show me a tiny example that works? Also, what do I need to import?

                    
                    from fastapi import FastAPI, Query
                    from typing import List

                    app = FastAPI()

                    @app.get("/items")
                    def get_items(page: int = Query(1, ge=1), size: int = Query(10, ge=1)):
                        # dummy list of 100 items
                        items = [f"item-{i}" for i in range(1, 101)]
                        start = (page - 1) * size
                        end = start + size
                        return {"page": page, "size": size, "items": items[start:end]}
                    """
    }
    context_engineer = ContextEngineer(context)
    updated_context = context_engineer.enrich_query()
    print(updated_context)