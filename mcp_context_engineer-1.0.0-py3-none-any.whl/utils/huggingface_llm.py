# mcp_context_engineer/utils/llm.py
import os
import logging
from typing import List, Dict, Any, Optional
import base64
from transformers import AutoTokenizer, AutoModelForCausalLM

# loading the env file
from dotenv import load_dotenv
load_dotenv()

# ----------------------------------------------------------------------
# Logging configuration – the library should not configure root logging,
# it only creates a module‑level logger that the host application can
# control (e.g. via `uv run -q` or a custom logging config).
# ----------------------------------------------------------------------
logger = logging.getLogger(__name__)

# ----------------------------------------------------------------------
# Helper – read credentials from environment (fallback to the hard‑coded
# placeholder used in the original script).  This keeps secrets out of
# source control.
# ----------------------------------------------------------------------
_HUGGINGFACE_TOKEN: str = base64.b64encode(os.getenv("ACCESS_TOKEN").encode("utf-8"))
_MODEL: str = os.getenv("MODEL_NAME", "Qwen/Qwen2.5-Coder-7B")

# ----------------------------------------------------------------------
# Core LLM client – thin, test‑able wrapper around the OpenAI SDK.
# ----------------------------------------------------------------------
class LLMClient:
    """
    Simple wrapper for the huggingface model

    Parameters
    ----------
    access_token: str, optional
        access token for the service.  If omitted the value is read from the
        ``ACCESS_TOKEN`` environment variable.
    model: str, optional
        Default model to use for ``generate`` calls.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "openai/gpt-oss-120b",
    ) -> None:
        self.api_key = api_key or _HUGGINGFACE_TOKEN
        self.model_name = model or _MODEL
        
        # for efficient reuseability
        self.tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen2.5-Coder-7B", token = _HUGGINGFACE_TOKEN)
        self.model = AutoModelForCausalLM.from_pretrained("Qwen/Qwen2.5-Coder-7B", token = _HUGGINGFACE_TOKEN)

        # Initialise the OpenAI client – this is cheap and can be reused.
        logger.debug(
            "LLMClient initialised - model=%s", self.model_name
        )

    # ------------------------------------------------------------------
    # Public API – generate a completion from a list of messages.
    # ------------------------------------------------------------------
    def generate(
        self,
        messages: List[Dict[str, str]],
        *,
        temperature: float = 0.0,
        # max_tokens: int = 256,
        stop: Optional[List[str]] = None,
    ) -> str:
        """
        Send a chat completion request and return the assistant’s content.

        Parameters
        ----------
        messages: List[Dict[str, str]]
            Chat history in OpenAI format, e.g.
            ``[{"role": "system", "content": "..."}]``.
        temperature: float, default 0.0
            Controls randomness - keep low for deterministic answers.
        max_tokens: int, default 256
            Upper bound on generated tokens.
        stop: List[str] | None
            Optional stop sequences.

        Returns
        -------
        str
            The generated text (stripped of surrounding whitespace).
        """
        logger.info("Calling LLM - %d message(s)", len(messages))
        try:
            inputs = self.tokenizer.apply_chat_template(
                messages,
                add_generation_prompt=True,
                tokenize=True,
                return_dict=True,
                return_tensors="pt",
            ).to(self.model.device)

            outputs = self.model.generate(**inputs)   #, max_new_tokens=max_tokens)
            
            # ``self.tokenizer.decode(outputs[0][inputs["input_ids"].shape[-1]:])}`` holds the assistant text.
            content = self.tokenizer.decode(outputs[0][inputs["input_ids"].shape[-1]:]) or ""
            logger.debug("LLM raw response: %s", content)
            return content.strip()
        except Exception as exc:  # pragma: no cover – exercised via integration tests
            logger.error("LLM request failed: %s", exc, exc_info=True)
            raise

    # ------------------------------------------------------------------
    # Convenience wrapper for the one‑shot use‑case that the original script
    # demonstrated (system + user message only).
    # ------------------------------------------------------------------
    def simple_chat(
        self,
        user_content: str,
        **kwargs: Any,
    ) -> str:
        """
        Quick helper for a single user turn.

        Parameters
        ----------
        user_content: str
            The user's query.
        **kwargs: Any
            Forwarded to :meth:`generate`.

        Returns
        -------
        str
            Model answer.
        """
        messages = [
            {"role": "user", "content": user_content},
        ]
        return self.generate(messages, **kwargs)

# ----------------------------------------------------------------------
# Example usage (executed only when the module is run directly)
# ----------------------------------------------------------------------
if __name__ == "__main__":
    # The example mirrors the original script but now uses the
    # structured wrapper and proper logging.
    client = LLMClient()
    answer = client.simple_chat(
        "Write a short poem about coding.", temperature=0.7, max_tokens=64
    )
    print(answer)