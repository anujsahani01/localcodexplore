from openai import OpenAI


# base64 encoded trigram:applicationpassword
api_key = "YXNpODQ6ODRjMzE4MzktMGExNy00MzI1LTllMjYtNDVlOGMyMzkzN2Zm"

api_base = "https://dsext001-eu1-215dsi0708-devassistant.3dexperience.3ds.com/v1"

client = OpenAI(api_key=api_key, base_url=api_base)

response = client.chat.completions.create(
    model="mistralai/devstral-medium-2512",  # the model name that exists on the remote server
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Write a short poem about coding."},
    ],
)

print(response)