"""
----------------------------------------------------------------------------- LANGUAGE/EXTENSIONS MAP FOR AST CHUNKING -----------------------------------------------------------------------------
"""

MAP_LANG_EXTENSIONS = {
    "python": ["py", "pyw", "pyi"],
    "java": ["java"],
    "javascript": ["js", "jsx", "mjs", "cjs"],
    "json": ["json"],
    "jsdoc": ["jsdoc"],
    "typescript": ["ts", "mts", "cts"],
    "tsx": ["tsx"],
    # "jsp": ["jsp"],
    "vue": ["vue"],
    "cpp": ["cpp", "idl", "hpp", "hxx", "cxx", "ipp"],
    "c": ["c", "h"],
    "csharp": ["cs"],
    "php": [
        "php",
        "phtml",
        "php3",
        "php4",
        "php5",
        "php7",
        "phps",
        "php-s",
    ],
    "bash": ["sh", "bash"],
    "go": ["go"],
    "fortran": ["f", "f77", "f90", "f95"],
    "ruby": ["rb", "erb"],
    "rust": ["rs"],
    "lua": ["lua"],
    "matlab": ["m"],
    "ocaml": ["ml", "mli", "ocaml"],
    "cuda": ["cu"],
    "tcl": ["tcl"],
    "asm": ["asm"],
    "glsl": ["glsl"],
    "pascal": ["pas"],
    "sql": ["sql"],  # TODO: should we add "mql" extension?
    # "haskell": ["hs"],
    # "julia": ["jl"],
    # "swift": ["swift"],
    # "kotlin": ["kt"],
    # "scala": ["scala"],
    # "perl": ["pl"], # TODO: find a working perl tree-sitter parser
    # that has a parser.c file
    # "awk": ["awk"], # TODO: find an awk tree-sitter parser
    # "bat": ["bat"], # TODO: find a bat tree-sitter parser
    # "gradle": ["gradle"], # TODO: find a gradle tree-sitter parser
    # OR use java parser?
    # "sql": ["sql"], # TODO: find a working sql tree-sitter parser
    # that has a parser.c file
    "toml": ["toml"],
    "yaml": ["yaml", "yml"],
    "xml": ["xml", "sypintro"],
    "html": ["html", "htm", "jsp"],
    "css": ["css"],
    # "dockerfile": ["Dockerfile"], # TODO: the dockerfiles generally don't have an extension
}

"""
----------------------------------------------------------------------------- IMPORT NODES FOR AST CHUNKING -----------------------------------------------------------------------------
"""

IMPORT_NODE_TYPES = [
    "package_declaration",  # Java, Kotlin, Scala
    "import_statement",  # Python
    "import_from_statement",  # Python
    "import_declaration",  # Java, TypeScript, Swift, Kotlin, Scala
    "preproc_include",  # C, C++
    "import_clause",  # JavaScript, TypeScript
    "import_specifier",  # JavaScript, TypeScript
    "import_namespace_specifier",  # JavaScript, TypeScript
    "import_default_specifier",  # JavaScript, TypeScript
    "export_declaration",  # JavaScript, TypeScript
    "export_named_declaration",  # JavaScript, TypeScript
    "export_default_declaration",  # JavaScript, TypeScript
    "export_all_declaration",  # JavaScript, TypeScript
    "use_declaration",  # PHP, Rust
    "import_spec",  # Go
    "require",  # Ruby, Lua
    "load",  # Ruby
    "extern_crate_declaration",  # Rust
    "require_statement",  # Lua
    "import_directive",  # Kotlin
    "import_clause",  # Scala
    "source_command",  # Shell Script
    # "function_definition",  # General
    # "class_definition",  # General
]

"""
----------------------------------------------------------------------------- ClASSE NODES FOR AST CHUNKING -----------------------------------------------------------------------------
"""

CLASS_NODE_TYPES = [
    "class_declaration",
    "class_definition",
    "class_specifier"
]


"""
----------------------------------------------------------------------------- FUNCTION NODES FOR AST CHUNKING -----------------------------------------------------------------------------

"""

FUNCTION_NODE_TYPES = [
    "function_declaration",
    "function_definition",
    "function_item",
    "method_definition",
    "method_declaration"
] 


DECORATOR_NODE_TYPES = [
    # Python
    "decorator",
    "decorated_definition",

    # Java / Kotlin
    "annotation",
    "marker_annotation",
    "annotation_argument_list",

    # JavaScript / TypeScript (experimental decorators)
    "decorator",              # TS/JS
    "decorator_call",

    # C#
    "attribute",
    "attribute_list",

    # Rust
    "attribute_item",
    "inner_attribute_item",

    # Go (no real decorators, but tags behave similarly)
    "tag",

    # Swift
    "attribute",

    # Scala
    "annotation",

    # PHP (attributes in modern PHP)
    "attribute_group",
    "attribute",

    # C / C++ (compiler attributes, macros)
    "attribute_specifier",
    "attribute_declaration",

    # General / fallback (seen in some grammars)
    "metadata",
    "modifier_annotation"
]


IMPORT_PATH = [
    # Java
    "scoped_identifier",        # e.g., java.util.List
    "type_identifier",          # For unqualified single imports
    "package_or_type_name",     # Sometimes used for imports

    # C / C++
    "string_literal",           # #include "path/to/file.h"
    "system_lib_string",        # #include <iostream>

    # Python
    "dotted_name",              # e.g., os.path
    "aliased_import",           # `import os as something`
    "module_name",              # Direct module name
    "attribute",                # from os import path

    # JavaScript / TypeScript
    "string",                   # import x from "module"
    "import_specifier",         # Named imports
    "import_clause",            # Default + named

    # Go
    "interpreted_string_literal", # import "fmt"
    "import declartion",

    # Rust
    "scoped_identifier",        # std::io::Read
    "identifier",               # Single name

    # PHP
    "namespace_name",           # Namespaced import path

    # Kotlin
    "identifier",               # Last part of path
    "user_type",                 # Qualified type path

    # Swift
    "identifier",               # Last name in import
    "scoped_identifier",        # Qualified path

    # Scala
    "stable_identifier",        # java.util.List
    "identifier"                # Last part of path
]

IMPORT_NAME = [
    "identifier",               # Common final name
    "type_identifier",          # Java class names
    "alias",                    # Python/Rust alias name
    "symbol",                   # Zig symbols
    "constant_identifier",       # Ruby constants
    "import_spec"
]


FUNCTION_BODY = [
    # Java family
    "block",                    # Java, C#, Go, Swift
    "method_body",               # Java (sometimes used in older grammars)
    
    # JavaScript / TypeScript
    "statement_block",           # JS, TS (function, if, loops)
    "block",                     # Also appears in JS/TS

    # C / C++
    "compound_statement",        # Function bodies, blocks

    # Python
    "suite",                     # Indented block after def

    # Ruby
    "body_statement",            # Function/method/class body

    # PHP
    "compound_statement",        # Function/method body

    # Kotlin
    "function_body",              # Direct node for body
    "block",                      # Sometimes used instead

    # Swift
    "code_block",                 # Function/method body

    # Rust
    "block",                      # Function/impl body

    # Scala
    "block",                      # Function body in curly braces
    "expression",                 # Can be a single expression body

    # Lua
    "block",                      # Function body

    # Elixir
    "do_block",                   # do...end block

    # Zig
    "block",                      # Function body

    # Haskell
    "where",                      # Sometimes part of function definition
    "do_expression"               # In monadic code
]

# for class variables ( field declerations)
CLASS_VARIABLES_DECLARATIONS = [
    # Java family
    "field_declaration",            # Java, C#, Go
    "property_declaration",         # PHP
    "property_definition",          # JS/TS
    "public_field_definition",      # JS/TS
    "field_definition",             # JS/TS
    "readonly_field",               # TS
    "const_assertion",              # TS

    # C / C++
    "declaration",                  # Inside class/struct body

    # Kotlin
    "property_declaration",

    # Swift
    "variable_declaration",

    # Rust
    "field_declaration",

    # Scala
    "val_declaration",
    "var_declaration",

    # Python
    "assignment",                   # Need to check if parent is class_definition

    # Ruby
    "assignment",                   # Similar, check if inside class

    # Elixir
    "attribute",                    # @var style module attributes

    # Zig
    "declaration"                  # In struct/class-like types
]


CLASS_BODY = [
    "class_body",              # Java, JavaScript, TypeScript, C#
    "block",                   # Rust, Go, Swift (used inside structs/classes)
    "declaration_list",        # C, C++ (used inside struct/class)
    "template_body",           # Scala (inside class/object/trait)
    "suite",                   # Python (indented block after `class`)
    "do_block",                # Elixir
    "body",                    # Kotlin, Lua (can be function or class)
    "record_body",             # Kotlin data classes
    "object_body",             # Kotlin
    "record_declaration",      # Swift (used in newer grammar proposals)
    "struct_body",             # Zig (used in structs with fields/methods)
    "compound_statement",      # C/C++, Bash (sometimes used for class bodies)
    "class_definition_block",  # Ruby (not official, but can be used in forks)
    "class_content",           # PHP
    "block_body",              # Nim, Haskell (sometimes user-defined)
    "value_declaration",       # Haskell, sometimes used directly in class-like forms
    "where_clause",            # Haskell (type class body)
]


CLASS_VARIABLE_NAMES = [
    "variable_declarator",          # Java, JS, TS
    "init_declarator",              # C, C++
    "identifier",                   # Common in most languages
    "simple_identifier",            # Kotlin
    "name",                         # PHP
    "pattern",                      # Python/Rust destructuring
    "scoped_identifier",            # C++
    "constant_identifier",          # Ruby, sometimes for constants
    "variable",                     # Elixir
    "field_identifier",             # Rust struct fields
    "shorthand_property_identifier",# JS destructuring
    "property_identifier",          # JS class fields
    "val_identifier",               # Scala
    "var_identifier",               # Scala
    "symbol",                       # Zig
]
"""
----------------------------------------------------------------------------- GIT REPOSITORY TREE SITTER URLS -----------------------------------------------------------------------------
"""

GIT_REPOSITORY_TREE_SITTER_URLS = [
    "https://github.com/tree-sitter/tree-sitter-bash.git",
    "https://github.com/tree-sitter/tree-sitter-c.git",
    "https://github.com/tree-sitter/tree-sitter-c-sharp.git",
    "https://github.com/tree-sitter/tree-sitter-css.git",
    "https://github.com/tree-sitter/tree-sitter-go.git",
    "https://github.com/tree-sitter/tree-sitter-haskell.git",
    "https://github.com/tree-sitter/tree-sitter-html.git",
    "https://github.com/tree-sitter/tree-sitter-javascript.git",
    "https://github.com/tree-sitter/tree-sitter-jsdoc.git",
    "https://github.com/tree-sitter/tree-sitter-json.git",
    "https://github.com/tree-sitter/tree-sitter-julia.git",
    "https://github.com/tree-sitter/tree-sitter-ocaml.git",
    "https://github.com/tree-sitter/tree-sitter-php.git",
    "https://github.com/tree-sitter/tree-sitter-ql.git",
    "https://github.com/tree-sitter/tree-sitter-ruby.git",
    "https://github.com/tree-sitter/tree-sitter-rust.git",
    "https://github.com/tree-sitter/tree-sitter-scala.git",
    "https://github.com/tree-sitter/tree-sitter-swift.git",
    "https://github.com/tree-sitter/tree-sitter-toml.git",
    "https://github.com/tree-sitter/tree-sitter-typescript.git",
    "https://github.com/tree-sitter/tree-sitter-cpp",
    "https://github.com/tree-sitter/tree-sitter-java",
    "https://github.com/tree-sitter/tree-sitter-python",
    "https://github.com/r-lib/tree-sitter-r.git",
    "https://github.com/tree-sitter-grammars/tree-sitter-lua.git",
    "https://github.com/camdencheek/tree-sitter-dockerfile.git",
    "https://github.com/fwcd/tree-sitter-kotlin.git",
    "https://github.com/stadelmanma/tree-sitter-fortran.git",
    "https://github.com/tree-sitter-perl/tree-sitter-perl.git",
    "https://github.com/acristoffers/tree-sitter-matlab.git",
    "https://github.com/ikatyang/tree-sitter-yaml.git",
    "https://github.com/tree-sitter-grammars/tree-sitter-xml.git",
    "https://github.com/ikatyang/tree-sitter-vue.git",
    "https://github.com/merico-dev/tree-sitter-jsp.git",
    "https://github.com/tree-sitter-grammars/tree-sitter-cuda.git",
    "https://github.com/tree-sitter-grammars/tree-sitter-tcl.git",
    "https://github.com/RubixDev/tree-sitter-asm.git",
    "https://github.com/tree-sitter-grammars/tree-sitter-glsl.git",
    "https://github.com/Isopod/tree-sitter-pascal.git",
    "https://github.com/m-novikov/tree-sitter-sql.git",
]

GRAMMAR_PATH_ROOT = "ragdapi/transform/chunkers/cache/tree-sitter-"  # Path to store tree-sitter grammars

# what is inside of this build 
LIBRARY_PATH_ROOT = "ragdapi/transform/chunkers/cache/build/"
OFFICIAL_TREE_SITTER_GIT_URL = "https://github.com/tree-sitter/tree-sitter-"

"""
----------------------------------------------------------------------------- OTHER TREE SITTER GIT PARSERS -----------------------------------------------------------------------------
"""

OTHER_TREE_SITTER_GIT_PARSERS = {
    "sql": "https://github.com/m-novikov/tree-sitter-sql.git",
    "r": "https://github.com/r-lib/tree-sitter-r.git",
    "lua": "https://github.com/tree-sitter-grammars/tree-sitter-lua.git",
    "dockerfile": "https://github.com/camdencheek/tree-sitter-dockerfile.git",
    "kotlin": "https://github.com/fwcd/tree-sitter-kotlin.git",
    "fortran": "https://github.com/stadelmanma/tree-sitter-fortran.git",
    "perl": "https://github.com/tree-sitter-perl/tree-sitter-perl.git",
    "matlab": "https://github.com/acristoffers/tree-sitter-matlab.git",
    "yaml": "https://github.com/ikatyang/tree-sitter-yaml.git",
    "xml": "https://github.com/tree-sitter-grammars/tree-sitter-xml.git",
    "vue": "https://github.com/ikatyang/tree-sitter-vue.git",
    "jsp": "https://github.com/merico-dev/tree-sitter-jsp.git",
    "cuda": "https://github.com/tree-sitter-grammars/tree-sitter-cuda.git",
    "tcl": "https://github.com/tree-sitter-grammars/tree-sitter-tcl.git",
    "asm": "https://github.com/RubixDev/tree-sitter-asm.git",
    "glsl": "https://github.com/tree-sitter-grammars/tree-sitter-glsl.git",
    "pascal": "https://github.com/Isopod/tree-sitter-pascal.git",
 
}