# mcp_context_engineer/utils/llm.py
import os
import logging
from typing import List, Dict, Any, Optional
import base64
from openai import OpenAI
from openai.types.chat import ChatCompletion

# loading the env file - with fallback handling for packaged environments
from dotenv import load_dotenv
import sys
from pathlib import Path

def _load_environment():
    """
    Load environment variables from .env file placed alongside the wheel package.
    This function looks for .env files in strategic locations where users 
    typically place them when deploying wheel packages.
    """
    try:
        # Get current file location (this utils file)
        current_file = Path(__file__).absolute()
        
        # Potential .env file locations (in order of preference)
        env_locations = [
            # 1. Current working directory (where user runs the MCP)
            Path.cwd() / ".env",
            
            # 2. Same directory as the Python executable (common for packaged apps)
            Path(sys.executable).parent / ".env",
            
            # 3. Parent of site-packages (where pip installs packages)
            current_file.parent.parent.parent / ".env",  # ../../../.env from utils/
            
            # 4. Two levels up from this file (package root during development)
            current_file.parent.parent / ".env",  # ../../.env from utils/
            
            # 5. Same directory as this utils module
            current_file.parent / ".env",  # ../utils/.env
        ]
        
        loaded_from = None
        
        # Try each location in order
        for env_path in env_locations:
            if env_path.exists() and env_path.is_file():
                load_dotenv(env_path)
                loaded_from = env_path
                break
        
        if not loaded_from:
            # sys.stderr so it doesn't pollute the MCP stdio channel
            print("WARNING: No .env file found, relying on system environment variables", file=sys.stderr)
            
    except Exception as e:
        print(f"WARNING: Failed to load .env file: {e}", file=sys.stderr)

# Load environment on module import
_load_environment()

# ----------------------------------------------------------------------
# Logging configuration – the library should not configure root logging,
# it only creates a module‑level logger that the host application can
# control (e.g. via `uv run -q` or a custom logging config).
# ----------------------------------------------------------------------
logger = logging.getLogger(__name__)

# ----------------------------------------------------------------------
# Helper – read credentials from environment with better error messages
# ----------------------------------------------------------------------
def _get_required_env_var(var_name: str, description: str = "") -> str:
    """Get required environment variable with helpful error message"""
    value = os.getenv(var_name)
    if not value:
        available_vars = [k for k in os.environ.keys() if 'API' in k or 'KEY' in k]
        raise ValueError(
            f"Missing required environment variable: {var_name}\n"
            f"{description}\n"
            f"Available API-related environment variables: {available_vars}\n"
            f"Please set {var_name} in your system environment or .env file"
        )
    return value

_API_KEY: str = _get_required_env_var(
    "DEV_ASSISTANT_API_KEY", 
    "Your Dev Assistant API key for 3DExperience platform"
)

_API_BASE: str = os.getenv(
    "DEV_ASSISTANT_API_BASE",
    "https://dsext001-eu1-215dsi0708-devassistant.3dexperience.3ds.com/v1",
)
_MODEL: str = os.getenv("MODEL_NAME", "mistralai/devstral-medium-2512")

# ----------------------------------------------------------------------
# Core LLM client – thin, test‑able wrapper around the OpenAI SDK.
# ----------------------------------------------------------------------
class LLMClient:
    """
    Simple wrapper for the remote “Dev Assistant” endpoint.

    Parameters
    ----------
    api_key: str, optional
        API key for the service.  If omitted the value is read from the
        ``DEV_ASSISTANT_API_KEY`` environment variable.
    api_base: str, optional
        Base URL of the service.  Defaults to the value of
        ``DEV_ASSISTANT_API_BASE`` env-var.
    model: str, optional
        Default model to use for ``generate`` calls.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_base: Optional[str] = None,
        model: str = _MODEL
    ) -> None:
        self.api_key = api_key or _API_KEY
        self.api_base = api_base or _API_BASE
        self.model = model or _MODEL

        # Initialise the OpenAI client – this is cheap and can be reused.
        self._client = OpenAI(api_key=self.api_key, base_url=self.api_base)
        logger.debug(
            "LLMClient initialised - model=%s, base=%s", self.model, self.api_base
        )

    # ------------------------------------------------------------------
    # Public API – generate a completion from a list of messages.
    # ------------------------------------------------------------------
    def generate(
        self,
        messages: List[Dict[str, str]],
        *,
        temperature: float = 0.0,
        max_tokens: int = 256,
        stop: Optional[List[str]] = None,
        stream: bool = False, 
    ) -> str:
        """
        Send a chat completion request and return the assistant’s content.

        Parameters
        ----------
        messages: List[Dict[str, str]]
            Chat history in OpenAI format, e.g.
            ``[{"role": "system", "content": "..."}]``.
        temperature: float, default 0.0
            Controls randomness - keep low for deterministic answers.
        max_tokens: int, default 256
            Upper bound on generated tokens.
        stop: List[str] | None
            Optional stop sequences.

        Returns
        -------
        str
            The generated text (stripped of surrounding whitespace).
        """
        logger.info("Calling LLM - %d message(s)", len(messages))
        try:
            response: ChatCompletion = self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stop=stop,
                stream = stream
            )

            if not stream:
                content = response.choices[0].message.content or ""
                logger.debug("LLM raw response (non‑stream): %s", content)
                return content.strip()

            # ── Streaming path (fallback – same logic as Patch B) ────────
            # If a caller explicitly passes stream=True we fall back to the
            # chunk‑aggregation logic below.
            full_text = ""
            for chunk in response:   # type: ignore[iteration‑item]  (Chunk iterator)
                delta = chunk.choices[0].delta
                # The SDK may put the text in `content` or `reasoning_content`
                part = delta.content or getattr(delta, "reasoning_content", "")
                if part:
                    full_text += part
            logger.debug("LLM streamed response assembled: %s", full_text)
            return full_text.strip()

        except Exception as exc:  # pragma: no cover
            logger.error("LLM request failed: %s", exc, exc_info=True)
            raise

    # ------------------------------------------------------------------
    # Convenience wrapper for the one‑shot use‑case that the original script
    # demonstrated (system + user message only).
    # ------------------------------------------------------------------
    def simple_chat(
        self,
        user_content: str,
        system_prompt: str = "You are a helpful assistant.",
        **kwargs: Any,
    ) -> str:
        """
        Quick helper for a single user turn.

        Parameters
        ----------
        user_content: str
            The user’s query.
        system_prompt: str, optional
            System instruction for the model.
        **kwargs: Any
            Forwarded to :meth:`generate`.

        Returns
        -------
        str
            Model answer.
        """
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]
        return self.generate(messages, **kwargs)

# ----------------------------------------------------------------------
# Example usage (executed only when the module is run directly)
# ----------------------------------------------------------------------
if __name__ == "__main__":
    # The example mirrors the original script but now uses the
    # structured wrapper and proper logging.
    client = LLMClient()
    answer = client.simple_chat(
        user_content= "Write a short poem about coding.", system_prompt= "You are a helpful assistant.", temperature=0.7, max_tokens=256
    )
    print(answer)


