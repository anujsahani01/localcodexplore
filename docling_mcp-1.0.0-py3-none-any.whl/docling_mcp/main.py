# main.py

import logging
# this will imort the alreay populated mcp objects and we wil be having all the tools.
from docling_mcp.docling_tool import mcp  # import the SAME instance

# --------------------------------------------------
# Logging (optional but recommended)
# --------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

logger = logging.getLogger("MCP-Main")


# --------------------------------------------------
# Entry point
# --------------------------------------------------
def main():
    logger.info("Starting MCP Server: 3DS Docs Retriever")

    try:
        # Run MCP server over HTTP
        mcp.run(
            transport="http",
            port=9090
        )

    except Exception as e:
        logger.exception(" MCP Server crashed")
        raise e


if __name__ == "__main__":
    main()