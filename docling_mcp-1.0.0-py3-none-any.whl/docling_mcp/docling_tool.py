from fastmcp import FastMCP
import requests
import subprocess
from pydantic import BaseModel, Field
import time
from pathlib import Path
import faiss
import numpy as np
import logging
import sys
import time
import json
from sentence_transformers import SentenceTransformer 
mcp = FastMCP("3DS Docs Retriver")
from docling_mcp.doc_query_pipeline import query_endpoint, main

START_CMD = [sys.executable, "python", "-m", "docling_mcp.doc_query_pipeline.main"]

@mcp.tool(name="doc_query_pipeline", 
          description=(
        "Run or refresh the document retrieval pipeline. "
        "Use this tool to rebuild or update the document embeddings and indexes "
        "used by the 3DS Docs retriever. "
        "This may take several minutes and is typically triggered manually when "
        "new documents are added or existing ones are modified. "
        "Returns a success message or detailed pipeline execution logs.")
        )
def run_doc_query_pipeline():
    # Start the chunking and indexing process
    print("Starting the chunking and indexing pipeline...")
    try:
        # process = subprocess.Popen(START_CMD)
        # return_code = process.wait()   # this wil block until done
        return_code = main()

        if str(return_code) == '0':
            return "Pipeline completed successfully!"
        else:
            return f"Pipeline failed with error code: {return_code}"


    except Exception as e:
        logging.info(f"Unexpected error occured while chunking and indxing the docs is: {e}")
        return f"Unexpected error occured while chunking and indxing the docs is: {e}"

class QueryDocumentsArgs(BaseModel):
    fullInput: str = Field(..., description="User's query text")
    top_k: int = Field(5, description="Number of top documents to retrieve")

@mcp.tool(
    name="query_documents",
    description=(
        "Search the local FAISS-based documentation database for relevant content. "
        "Use this tool when the user asks questions about 3DS Docs or product guides. "
        "It takes a 'fullInput' (the user query) and an optional 'top_k' integer for how many results to return. "
        "Returns a JSON list of relevant document chunks with name, content, and metadata (source + score)."
    ),)
def query_documents(fullInput: str, top_k: int = 5) -> str:
    try:
        payload = {"fullInput": fullInput, "top_k": top_k}
         # Create the model instance so query_endpoint receives an object with `.fullInput`
        req_obj = QueryDocumentsArgs(**payload)
        logging.info(f"Querying the DB")
        context_items = query_endpoint(req_obj)
        print(type(context_items))
        return json.dumps(context_items)
  
    except Exception as e:
        logging.info(f"Failed to query the DB: {str(e)}")
        return f"Failed to query the DB: {str(e)}"



