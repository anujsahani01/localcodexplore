import os
import logging
from pathlib import Path
from tqdm import tqdm
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import hashlib
from pathlib import Path
import os
import platform
import json

# ✅ Updated import for latest Docling
try:
    from docling.document_converter import DocumentConverter  # Docling ≥ 2.0
except ImportError:
    from docling.pipeline import SimplePipeline                # Docling ≤ 1.x

from docling.datamodel.base_models import InputFormat

# PPTX support
from pptx import Presentation

# ─────────────────────────────
# CONFIG
# ─────────────────────────────


# ---------------------------
# Determine base directory for app data
# ---------------------------
if platform.system() == "Windows":
    base = Path(os.getenv("LOCALAPPDATA", Path.home()))
elif platform.system() == "Linux":
    base = Path(os.getenv("XDG_DATA_HOME", Path.home() / ".local/share"))
else:  # macOS
    base = Path.home() / "Library/Application Support"

BASE_DIR = base / "docncode_mcp"

# ---------------------------
# Project directories
# ---------------------------
DOC_DIR = Path("my_docs")          # keep local
MD_DIR = BASE_DIR / "converted_md"
DB_DIR = BASE_DIR / "db"

# ---------------------------
# Files
# ---------------------------
INDEX_FILE = DB_DIR / "faiss_index.bin"
CACHE_FILE = DB_DIR / "file_cache.json"

# ---------------------------
# Model / chunk config
# ---------------------------
MODEL_NAME = "all-MiniLM-L6-v2"  # Faster, lightweight, CPU-friendly
CHUNK_SIZE = 800
CHUNK_OVERLAP = 100

# ---------------------------
# Ensure directories exist
# ---------------------------
BASE_DIR.mkdir(parents=True, exist_ok=True)
DB_DIR.mkdir(parents=True, exist_ok=True)
MD_DIR.mkdir(parents=True, exist_ok=True)
DOC_DIR.mkdir(exist_ok=True)
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


# ─────────────────────────────
# HELPERS
# ─────────────────────────────
def file_hash(path: Path):
    """Compute a simple hash for file change detection."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(8192):
            h.update(chunk)
    return h.hexdigest()


def load_cache():
    if CACHE_FILE.exists():
        return json.loads(CACHE_FILE.read_text())
    return {}


def save_cache(cache):
    CACHE_FILE.write_text(json.dumps(cache, indent=2))


# ─────────────────────────────
# CHUNK TEXT
# ─────────────────────────────
def chunk_text(text: str, chunk_size=800, overlap=100):
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        start += chunk_size - overlap
    return chunks


# ─────────────────────────────
# FILE CONVERSION (DOCLING + PPTX)
# ─────────────────────────────
def convert_with_docling(doc_dir: Path, md_dir: Path, cache):
    try:
        converter = DocumentConverter()
        run_method = converter.convert
        logging.info("🧩 Using Docling DocumentConverter (v2.x+).")
    except NameError:
        converter = SimplePipeline()
        run_method = converter.run_file
        logging.info("🧩 Using Docling SimplePipeline (v1.x).")

    converted_files = []
    new_cache = dict(cache)

    all_files = [f for f in doc_dir.glob("*") if f.is_file()]
    new_files = [f for f in all_files if file_hash(f) != cache.get(str(f))]

    if not new_files:
        logging.info("✅ No new or updated files detected.")
        return [], cache

    logging.info(f"✅ Detected {len(new_files)} new/updated files.")

    for file_path in tqdm(new_files, desc="Converting files"):
        ext = file_path.suffix.lower().lstrip(".")
        try:
            # TXT, MD, CSV, LOG
            if ext in ["txt", "md", "log", "csv"]:
                md_output = md_dir / f"{file_path.stem}.md"
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                with open(md_output, "w", encoding="utf-8") as f:
                    f.write(content)
                logging.info(f"📝 Copied: {file_path.name} → {md_output.name}")
                converted_files.append(md_output)
                new_cache[str(file_path)] = file_hash(file_path)
                continue

            # PPTX
            if ext == "pptx":
                md_output = md_dir / f"{file_path.stem}.md"
                prs = Presentation(str(file_path))
                text = ""
                for slide in prs.slides:
                    for shape in slide.shapes:
                        if hasattr(shape, "text"):
                            text += shape.text + "\n"
                if text.strip():
                    with open(md_output, "w", encoding="utf-8") as f:
                        f.write(text)
                    logging.info(f"📊 Converted PPTX: {file_path.name} → {md_output.name}")
                    converted_files.append(md_output)
                    new_cache[str(file_path)] = file_hash(file_path)
                else:
                    logging.warning(f"⚠️ No text found in {file_path.name}")
                continue

            # Legacy PPT (skip with warning)
            if ext == "ppt":
                logging.warning(f"⚠️ Skipping legacy .ppt file (only .pptx supported): {file_path.name}")
                continue

            # Supported by Docling
            if ext not in [fmt.value for fmt in InputFormat]:
                logging.warning(f"⚠️ Unsupported file type: {file_path.name}")
                continue

            result = run_method(file_path)
            doc = getattr(result.document, "content", result.document)
            markdown_text = doc.export_to_markdown()

            md_output = md_dir / f"{file_path.stem}.md"
            with open(md_output, "w", encoding="utf-8") as f:
                f.write(markdown_text)
            logging.info(f"📝 Converted: {file_path.name} → {md_output.name}")
            converted_files.append(md_output)
            new_cache[str(file_path)] = file_hash(file_path)

        except Exception as e:
            logging.error(f"❌ Failed to convert {file_path.name}: {e}")

    save_cache(new_cache)
    return converted_files, new_cache


# ─────────────────────────────
# LOAD MARKDOWN CHUNKS
# ─────────────────────────────
def load_markdown_chunks(md_files):
    all_chunks, file_names = [], []
    for md_file in tqdm(md_files, desc="Chunking markdown"):
        text = md_file.read_text(encoding="utf-8", errors="ignore")
        chunks = chunk_text(text, CHUNK_SIZE, CHUNK_OVERLAP)
        all_chunks.extend(chunks)
        file_names.extend([md_file.name] * len(chunks))
        logging.info(f"✅ Chunked {md_file.name} into {len(chunks)} chunks.")
    return all_chunks, file_names


# ─────────────────────────────
# BUILD / UPDATE FAISS INDEX
# ─────────────────────────────
def build_or_update_faiss(chunks, file_names, append=False):
    model = SentenceTransformer(MODEL_NAME, trust_remote_code=True)
    embeddings = model.encode(chunks, show_progress_bar=True, convert_to_numpy=True)

    if append and INDEX_FILE.exists():
        index = faiss.read_index(str(INDEX_FILE))
        old_chunks = np.load(DB_DIR / "chunks.npy", allow_pickle=True)
        old_files = np.load(DB_DIR / "filenames.npy", allow_pickle=True)

        index.add(embeddings)
        all_chunks = np.concatenate([old_chunks, chunks])
        all_files = np.concatenate([old_files, file_names])
    else:
        dim = embeddings.shape[1]
        index = faiss.IndexFlatL2(dim)
        index.add(embeddings)
        all_chunks, all_files = np.array(chunks, dtype=object), np.array(file_names, dtype=object)

    faiss.write_index(index, str(INDEX_FILE))
    np.save(DB_DIR / "chunks.npy", all_chunks)
    np.save(DB_DIR / "filenames.npy", all_files)

    logging.info(f"✅ FAISS index updated with {len(chunks)} new chunks.")
    return index, model, all_chunks, all_files


# ─────────────────────────────
# LOAD EXISTING INDEX
# ─────────────────────────────
def load_faiss_index():
    if not INDEX_FILE.exists():
        return None
    index = faiss.read_index(str(INDEX_FILE))
    chunks = np.load(DB_DIR / "chunks.npy", allow_pickle=True)
    file_names = np.load(DB_DIR / "filenames.npy", allow_pickle=True)
    model = SentenceTransformer(MODEL_NAME, trust_remote_code=True)
    logging.info("✅ Loaded existing FAISS index.")
    return index, model, chunks, file_names


# ─────────────────────────────
# FASTAPI SERVER
# ─────────────────────────────

class QueryRequest(BaseModel):
    fullInput: str
    top_k: int = 5


def query_endpoint(req: QueryRequest):
    data = load_faiss_index()
    if data is None:
        return {"error": "Index not found."}

    index, model, chunks, file_names = data
    query_emb = model.encode([req.fullInput], convert_to_numpy=True)
    scores, indices = index.search(query_emb, req.top_k)

    context_items = []
    for rank, idx in enumerate(indices[0]):
        score = float(scores[0][rank])
        snippet = chunks[idx][:500].replace("\n", " ")
        context_items.append({
            "name": file_names[idx],
            "content": snippet,
            "metadata": {"score": score, "source": file_names[idx]},
            "uri": ""
        })
    return context_items

# ─────────────────────────────
# MAIN
# ─────────────────────────────
def main():
    logging.info("Starting Doc Query Pipeline...")
    try:
        cache = load_cache()
        converted_files, cache = convert_with_docling(DOC_DIR, MD_DIR, cache)

        if not INDEX_FILE.exists() and not converted_files:
            logging.error("No index and no files to process. Add files to 'my_docs/'.")
            return

        if converted_files:
            chunks, file_names = load_markdown_chunks(converted_files)
            _, model, all_chunks, all_files = build_or_update_faiss(chunks, file_names, append=True)
        else:
            _, model, all_chunks, all_files = load_faiss_index()

        return 0

    except Exception as e:
        return str(e)


if __name__ == "__main__":
    main()
