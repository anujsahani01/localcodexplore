from pydantic import BaseModel, field_validator, model_validator
from typing import Optional
from pathlib import Path


class Paths(BaseModel):
    root: Optional[Path] = None
    extract_output: Path
    transform_output: Path
    etl_config: Path
    extract_prefix_path: Optional[Path] = None
    workspace_path: Optional[Path] = None
    version: Optional[int] = 100

    @field_validator("root")
    @classmethod
    def check_root_is_directory(cls, value: Optional[Path]) -> Path:
        if value:
            if not value.is_dir():
                raise ValueError("root must be a valid directory")
        return value

    @field_validator("extract_prefix_path")
    @classmethod
    def check_extract_prefix_is_directory(cls, value: Optional[Path]) -> Optional[Path]:
        if value:
            if not value.is_dir():
                raise ValueError("extract_prefix_path must be a valid directory")
        return value

    @model_validator(mode="after")
    def validate_files_or_folders(self) -> "Paths":
        # Check if all are set and if they are folders or files
        all_paths = [self.extract_output, self.transform_output, self.etl_config]
        are_directories = all((self.root / path).is_dir() for path in all_paths)
        are_files = all(path.suffix for path in all_paths)

        if not (are_directories or are_files):
            raise ValueError(
                (
                    f"Either all paths (prefixed with root {self.root}) must be directories "
                    f"or all must be valid file paths with extensions among the following paths: {', '.join(str(path) for path in all_paths)}\n"
                )
            )

        if are_files:
            if self.extract_output.suffix != ".csv":
                raise ValueError(
                    "extract_output must be a CSV file (with .csv extension)"
                )
            elif self.transform_output.suffix != ".json":
                raise ValueError(
                    "transform_output must be a JSON file (with .json extension)"
                )
            elif self.etl_config.suffix != ".json":
                raise ValueError(
                    "etl_config must be a JSON file (with .json extension)"
                )

        return self
