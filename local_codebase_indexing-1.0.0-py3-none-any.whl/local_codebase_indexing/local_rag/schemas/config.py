from pydantic import BaseModel
from typing import Optional
from local_codebase_indexing.local_rag.schemas.paths import Paths

class Config(BaseModel):
    name: str
    paths: Optional[Paths] = None
