"""
Thsi script will be used to read the Patterns(filepaths, folders, exts) to be ignored by the user
"""
import pathspec
import os
import logging
logger = logging.getLogger(__name__)



class read_indexignore_file():

    def __init__(self, workspace_path):
        self.workspace_path = workspace_path

    # INDEXIGNORE MUST BE NOW IN THE WORKSPACE TO BE INDEXED
    def _read_indexignore(self) -> "pathspec":
        index_ignore_path = os.path.join(self.workspace_path, ".indexignore")
        logger.info(f"The indexignore file is present at: {index_ignore_path}")
        with open(index_ignore_path, 'r', encoding = "utf-8") as f:
            data = f.read()
            lines = data.splitlines()
            spec = pathspec.PathSpec.from_lines(pathspec.patterns.GitWildMatchPattern, lines)
        return spec
    

    def denormalize(path: str) -> str:
        # Make paths consistent for matching
        return os.path.normpath(path).replace("/", "\\")


    def _index_ignore_extraction(spec):
        folders= []
        extension = []
        patterns = []

        for pattern in spec.patterns:
            raw = pattern.pattern.strip()

            if raw.startswith("#"):
                pass
            # extrcating folders
            elif raw.endswith('/'):
                if raw not in folders:
                    folders.append(read_indexignore_file.denormalize(raw))
            elif raw.startswith("."):
                if raw not in extension:
                    extension.append(read_indexignore_file.denormalize(raw))
            else:
                if raw not in patterns:
                    patterns.append(read_indexignore_file.denormalize(raw))

            

        return folders, extension, patterns


# def main():
#     reader = read_indexignore_file()
#     #Laoding the patterns
#     spec = reader._read_indexignore()

#     # extracting requirements
#     folders, extension, patterns = reader._index_ignore_extraction(spec)

#     print(f"Folders to Ignore: \n{folders}")
#     print(f"Extensions to Ignore: \n{extension}")
#     print(f"Patterns to Ignore: \n{patterns}")


# if __name__ == "__main__":
#     main()
