from ragdapi.transform import main as transform_main
import sys
import logging
import os
from local_codebase_indexing.local_rag.utils.logger import setup_logging
from local_codebase_indexing.local_rag.utils.udf import parse_args
from local_codebase_indexing.local_rag.utils.config_utils import (
    list_config_files,
    load_config,
    get_config_selection,
    validate_config_selection
)
logger = logging.getLogger(__name__)

def main(argv = None):
    args = parse_args(argv)
    setup_logging(args.debug, args.redirect)
    logging.debug("Running in DEBUG mode")

    try:
        config_files = list_config_files()
    except FileNotFoundError as e:
        logger.error(e)
        sys.exit(1)

    config_name = args.config
    if config_name:
        try:
            validate_config_selection(config_name, config_files)
        except ValueError as e:
            logger.error(f"Invalid config selection: {e}")
            sys.exit(1)
    else:
        config_name = get_config_selection(config_files)

    config = load_config(config_name)
    # sys.argv = ["transform", "--config", str(config.paths.etl_config).split(".")[0], "--workspace", os.path.normpath(config.paths.workspace_path), "--version", str(config.paths.version)]
    # transform_main.main()
    workspace_path = args.workspacepath
    version = args.version
    if version is None and workspace_path is not None:
        version = config.paths.version
    elif version is None and workspace_path is None:
        raise Exception("Workspace path and version are not provided")

    if args.filepaths:
        transform_main.main([
            "--config", str(config.paths.etl_config).split(".")[0],
            "--workspace", os.path.normpath(workspace_path),
            "--filepaths", args.filepaths,
            "--version", str(version)
        ])
    else:
        # sys.argv = ["transform", "--config", str(config.paths.etl_config).split(".")[0], "--workspace", os.path.normpath(workspace_path), "--version", str(version)]
        transform_main.main([
            "--config", str(config.paths.etl_config).split(".")[0],
            "--workspace", os.path.normpath(workspace_path),
            "--version", str(version)
        ])



if __name__ == "__main__":
    try:
        main()

    except KeyboardInterrupt:
        print()
        logger.info("Program interrupted by user. Exiting gracefully. ✨")
