import sys
import json
import logging
from typing import List
from pathlib import Path
from pydantic import ValidationError
from local_codebase_indexing.local_rag.schemas.config import Config

logger = logging.getLogger(__name__)


def get_default_config_dir() -> Path:
    module_path = Path(__file__)
    module_directory = module_path.parent
    config_dir = module_directory / "../config"
    return config_dir.resolve()


def list_config_files(config_dir: Path = get_default_config_dir()) -> List[str]:
    if not config_dir.exists():
        raise FileNotFoundError(
            f"The config directory '{config_dir}' does not exist. Please create it and add at least one config file."
        )

    config_files = [f.stem for f in config_dir.glob("*.json")]
    if not config_files:
        raise FileNotFoundError(
            f"No config files found in the '{config_dir}' directory. Please add at least one config file."
        )

    return config_files


def load_config(
    config_name: str, config_dir: Path = get_default_config_dir()
) -> Config:
    config_file = config_dir / (config_name + ".json")
    if not config_file.exists():
        raise FileNotFoundError(f"The config file '{config_file}' does not exist.")

    with config_file.open("r") as f:
        config_data = json.load(f)

    try:
        config = Config(name=config_name, **config_data)
    except ValidationError as e:
        logging.error(e)
        sys.exit(1)

    return config


def validate_config_selection(config_name: str, config_files: List[str]):
    if config_name not in config_files:
        raise ValueError(
            f"Invalid config file selected: {config_name}. Available options are: {config_files}"
        )


def get_config_selection(config_files: List[str]) -> str:
    print("Available configuration files (without extensions):")
    for config_file in config_files:
        print(f"- {config_file}")
    
    config_name = "demo"

    config_name = config_name.strip()

    if config_name not in config_files:
        print(f"Invalid selection. Available options are: {config_files}")
        sys.exit(1)

    return config_name


