import csv
import logging
from typing import List, Dict
from pathlib import Path
import argparse

logger = logging.getLogger(__name__)


def load_csv_column(file_path: Path, column_name: str) -> List[str]:
    """Load a specific column from a CSV file."""
    try:
        with open(file_path, "r", encoding="utf-8") as csvfile:
            reader = csv.DictReader(csvfile)
            if column_name not in reader.fieldnames:
                raise ValueError(
                    f"Column '{column_name}' not found in {file_path} CSV file."
                )
            return [row[column_name] for row in reader]
    except (FileNotFoundError, ValueError, csv.Error) as e:
        logger.error(
            f"An error occurred when retrieving the '{column_name}' list from {file_path} CSV file: {e}"
        )
        raise


def parse_args(argv = None):
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Data Transformation Step")
    parser.add_argument("--config", help="Name of the config file (without extension)")
    parser.add_argument(
        "--debug", action="store_true", help="Enable debug level logging"
    )
    parser.add_argument(
        "--redirect", help="Path to the file where logs should be redirected"
    )
    parser.add_argument(
        "--workspacepath", help="Workspace path which is being indexed"
    )
    parser.add_argument(
        "--filepaths", help = "The only files which needs to be extracted"
    )
    parser.add_argument(
        "--version", help = "The version of the workspace which is being opened (if 2 same folders are opened in 2 diff workspace)"
    )
    return parser.parse_args(argv)


def versions_to_rank(versions: List) -> Dict[str, int]:
    """Convert a list of version into their chunk index for
    eg :
    versions = ["0.0.0", "1.0.0", "1.0.1", "2.0.0", "2.1.0", "3.0.0", "3.1.0", "3.2.0", "3.2.1"]
    version_to_index = {'0.0.0': 0,
                        '1.0.0': 0,
                        '1.0.1': 1,
                        '2.0.0': 0,
                        '2.1.0': 1,
                        '3.0.0': 0,
                        '3.1.0': 1,
                        '3.2.0': 2,
                        '3.2.1': 3
                    }

    :param vesion: List of version we we need to convert
    :return versions: Dict of version linked to its chunk index"""
    sorted_versions = sorted(versions, key=lambda x: tuple(map(int, x.split("."))))

    # Create a mapping for the ranks, resetting the index when the major version changes
    version_to_index = {}
    current_major = None
    index = 0

    for version in sorted_versions:
        major = version.split(".")[0]  # Extract the major version (first number)

        # Reset index if the major version changes
        if major != current_major:
            current_major = major
            index = 0
        else:
            index += 1

        # Map the version to the current index
        version_to_index[version] = index
    return version_to_index
