"""
Quit Watchdog:

This will command the watchdog to stop monitorting the directory.
"""
import sys
from pathlib import Path
from watchdog.observers import Observer    # watches the file systems and return events based on it  
from watchdog.events import FileSystemEventHandler, PatternMatchingEventHandler   # this responds to those events
import subprocess
import logging
from local_codebase_indexing.local_rag.utils.logger import setup_logging
from local_codebase_indexing.local_rag.utils.udf import parse_args
from local_codebase_indexing.local_rag.utils.config_utils import (
    list_config_files,
    load_config,
    get_config_selection,
    validate_config_selection,
)
import sqlite3
import os
from local_codebase_indexing.local_rag.extract import main as extract
from local_codebase_indexing.local_rag.transform import main as transform
import platform
import hashlib
from local_codebase_indexing.local_rag.read_index_ignore import read_indexignore_file
from datetime import datetime
import time
import json

logger = logging.getLogger(__name__)

"""
ONLY 3 EVENT TYPES ARE THERE :
"modified"  / "moved" / "deleted"
"""
class DS3Handler(PatternMatchingEventHandler):

    # TODO: just monitor the chnages done in the specified folders as .pyc/ .pyd file inide env gets updated every time
    def __init__(self, config_name, config,args, patterns, dirs, workspacename, workspacepath):
        super().__init__(
            ignore_patterns= patterns
        )
        self.config_name = config_name
        self.config = config
        self.args = args
        self.ignored_dirs = dirs
        self._last_event_time = {}
        self._wait_interval = 30
        self.workspacename = workspacename
        self.workspacepath = workspacepath
