"""
Watchdog:

Analyse the log activaticy and perform actions based on the different events based on the log activity
This works cross-platform
"""
import sys
from pathlib import Path
from watchdog.observers import Observer    # watches the file systems and return events based on it  
from watchdog.events import FileSystemEventHandler, PatternMatchingEventHandler   # this responds to those events
import subprocess
import logging
from local_codebase_indexing.local_rag.utils.logger import setup_logging
from local_codebase_indexing.local_rag.utils.udf import parse_args
from local_codebase_indexing.local_rag.utils.config_utils import (
    list_config_files,
    load_config,
    get_config_selection,
    validate_config_selection,
)
import sqlite3
import os
from local_codebase_indexing.local_rag.extract import main as extract
from local_codebase_indexing.local_rag.transform import main as transform
import platform
import hashlib
from local_codebase_indexing.local_rag.read_index_ignore import read_indexignore_file
from datetime import datetime
import time
import json

logger = logging.getLogger(__name__)

"""
ONLY 3 EVENT TYPES ARE THERE :
"modified"  / "moved" / "deleted"
"""
class DS3Handler(PatternMatchingEventHandler):

    # TODO: just monitor the chnages done in the specified folders as .pyc/ .pyd file inide env gets updated every time
    def __init__(self, config_name, config,args, patterns, dirs, workspacename, workspacepath):
        super().__init__(
            ignore_patterns= patterns
        )
        self.config_name = config_name
        self.config = config
        self.args = args
        self.ignored_dirs = dirs
        self._last_event_time = {}
        self._wait_interval = 30
        self.workspacename = workspacename
        self.workspacepath = workspacepath


    def _should_ignore_dir(self, path):
        path = os.path.normpath(path).replace("\\", "/")
        for ignored in self.ignored_dirs:
            ignored = os.path.normpath(ignored)
            ignored = os.path.join(os.path.normpath(self.workspacepath), ignored)
            # ignored = os.path.join(os.path.normpath(self.config.paths.workspace_path), ignored)
            if os.path.commonpath([path, ignored]) == ignored:
                return True
        
        return False
    
    def _create_monitor_table(self, filepath, event_type):
        table_name = f"{self.workspacename}_monitor_table"
        logger.info(f"Creating the monitor table: {table_name}")
        home_dir = Path.home()   # works on Windows, Linux, macOS
        my_lib_path = os.path.join(home_dir , ".LocalXplore")
        if not os.path.exists(my_lib_path):
            os.mkdir(my_lib_path)
        con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
        cur = con.cursor()
        """
        whenever an event occurs a monitor table will be created if now exists and the activity will be monitored
        """
        logger.info(f"Inserting the events to {table_name} table")
        self._insert_events(filepath, event_type, table_name, my_lib_path)
        con.commit()


    def _insert_events(self,filepath, event_type, table_name, my_lib_path):
        """
        So the monitor table will have 3 types of events and the filepaths in which the event took place
        """
        con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
        cur = con.cursor()
        logger.info(f"Inserting the event into the monitor table: {table_name}")
        cur.execute(f"""
        CREATE TABLE IF NOT EXISTS "{table_name}" (
            workspacename TEXT,
            modified TEXT UNIQUE,
            deleted TEXT UNIQUE,
            moved TEXT UNIQUE,
            FOREIGN KEY(workspacename) REFERENCES master_table(workspacename) ON DELETE CASCADE ON UPDATE CASCADE
        )""")
        if event_type == "moved":
            cur.execute(f"""
            INSERT OR IGNORE INTO "{table_name}"
            (workspacename, {event_type}) VALUES (?, ?)
            """, (str(self.workspacename), json.dumps(filepath)))
            logger.info(f"{event_type} was captured successfully")
        else: 
            cur.execute(f"""
            INSERT OR IGNORE INTO "{table_name}" 
            (workspacename, {event_type}) VALUES (?, ?)
            """, (str(self.workspacename),filepath))
            logger.info(f"{event_type} was captured successfully inside table: {table_name}")


        con.commit()

    
    """
    watchdog beaviour various on various os platform sometimes it takes a single event as 2 differnet events in milliseconds.
    """
    def _is_duplicate_event(self, event):
        now = datetime.now()
        last_time = self._last_event_time.get(event.src_path)
        if last_time:
            time_dff = now - last_time
            if int(time_dff.total_seconds()) < self._wait_interval:
                return True
            self._last_event_time[event.src_path] = now
        
        return False


    def on_modified(self, event):
        if not self._should_ignore_dir(event.src_path) and not self._is_duplicate_event(event):
            # TODO: update the etl_config and give the exact file paths to be extract again -- optimization
            """combine cwd + src_path"""
            try:
                self._last_event_time[event.src_path] = datetime.now()
                logger.info(f"File modified is: {event.src_path}")
                src_path = os.path.normpath(str(Path(event.src_path).resolve()))
                self._create_monitor_table(src_path, "modified")
                print("MODIFIED:",src_path)

                return super().on_modified(event)
            
            except Exception as e:
                logger.info(f"Unexpected error occured while the event was triggerd on file modification  🚀🚀 :{e}")
    
    def on_deleted(self, event):
        if not self._should_ignore_dir(event.src_path) and not self._is_duplicate_event(event):
            logger.info(f"File deleted is:{event.src_path}")
            """
            As the file is deleted or removed we just need to update the DB
            """
            # TODO: as of now we are keeping the DB in the current working directory
            self._last_event_time[event.src_path] = datetime.now()
            src_path = os.path.normpath(str(Path(event.src_path).resolve()))

            self._create_monitor_table(src_path, "deleted")
            print("DELETED:", src_path)

            return super().on_deleted(event)
    
    def on_moved(self, event):
        if not self._should_ignore_dir(event.src_path) and not self._is_duplicate_event(event):
            logger.info(f"The File path: {event.src_path} is moved to {event.dest_path}")
            """
            As the file has just been moved so we just need to update the path and hash value
            """

            # TODO: as of now we are keeping the DB in the current working directory
            self._last_event_time[event.src_path] = datetime.now()
            self._last_event_time[event.dest_path] = datetime.now()
            # duck typing in case of moved event

            src_path = os.path.normpath(str(Path(event.src_path).resolve()))
            dest_path = os.path.normpath(str(Path(event.dest_path).resolve()))

            self._create_monitor_table({"src_path": src_path,
                                        "dest_path": dest_path
                                        }, "moved")
            print("MOVED:", src_path, dest_path)

            return super().on_moved(event)




class WatchManager:
    def __init__(self):
        self.watchers = {}  # path -> observer

    def start_watch(self, workspace_path, version):
        if workspace_path in self.watchers:
            print(f"Already watching: {workspace_path}")
            return

        if not os.path.exists(workspace_path):
            print(f"Path does not exist: {workspace_path}")
            return

        args = parse_args()
        setup_logging(args.debug, args.redirect)

        try:
            config_files = list_config_files()
        except FileNotFoundError as e:
            logger.error(e)
            sys.exit(1)

        if args.config:
            config_name = args.config
            try:
                validate_config_selection(config_name, config_files)
            except ValueError as e:
                logger.error(e)
                sys.exit(1)
        else:
            config_name = get_config_selection(config_files)

        config = load_config(config_name)

        args = parse_args()
        read_indexignore_obj = read_indexignore_file(workspace_path)
        spec = read_indexignore_obj._read_indexignore()    # patterns = list(spec.patterns)
        dirs, exts, pattern = read_indexignore_file._index_ignore_extraction(spec)
        patterns = dirs + exts + pattern

        """
        As soon as a new workspace is created, create a new workspacename_monitor table
        """

        observer = Observer()
        # workspace_path = args.workspacepath
        workspace_path = os.path.normpath(Path(workspace_path))
        # version = config.paths.version
        # version = args.version
        if version is None and workspace_path is not None:
            version = config.paths.version
        elif version is None and workspace_path is None:
            raise Exception("Workspace path and version are not provided")

        # workspace_path = os.path.normpath(Path(config.paths.workspace_path))
        # version = config.paths.version
        workspacename = f"{str(workspace_path).split('\\')[-1]}_{version}"
        logger.info(f"The workspace freshly being monitored: {workspacename} and the version is: {version}")
        handler = DS3Handler(config_name, config, args, patterns, dirs, workspacename, workspace_path)

        observer.schedule(handler, workspace_path, recursive=True)
        observer.start()

        self.watchers[workspace_path] = observer
        print(f"Started watching the path: {workspace_path}")

    def stop_watch(self, workspace_path):
        observer = self.watchers.get(workspace_path)
        if not observer:
            print(f"Not watching: {workspace_path}")
            return

        observer.stop()
        observer.join()
        del self.watchers[workspace_path]
        print(f"Stopped watchingthe path: {workspace_path}")

    def stop_all(self):
        for path, observer in list(self.watchers.items()):
            observer.stop()
            observer.join()
            print(f"Stopped watching the path: {path}")
        self.watchers.clear()



def make_dotfiles():
    # Get user's home directory
    home_dir = Path.home()   # works on Windows, Linux, macOS
    my_lib_path = os.path.join(home_dir , ".LocalXplore")
    # my_lib_path.mkdir(exist_ok=True)
    if not os.path.exists(my_lib_path):
        os.mkdir(my_lib_path)
    return my_lib_path



# def getOberserver():
#     args = parse_args()
#     setup_logging(args.debug, args.redirect)

#     try:
#         config_files = list_config_files()
#     except FileNotFoundError as e:
#         logger.error(e)
#         sys.exit(1)

#     if args.config:
#         config_name = args.config
#         try:
#             validate_config_selection(config_name, config_files)
#         except ValueError as e:
#             logger.error(e)
#             sys.exit(1)
#     else:
#         config_name = get_config_selection(config_files)

#     config = load_config(config_name)

#     args = parse_args()
#     read_indexignore_obj = read_indexignore_file(workspace_path)
#     spec = read_indexignore_obj._read_indexignore()    # patterns = list(spec.patterns)
#     dirs, exts, pattern = read_indexignore_file._index_ignore_extraction(spec)
#     patterns = dirs + exts + pattern

#     """
#     As soon as a new workspace is created, create a new workspacename_monitor table
#     """

#     observer = Observer()
#     workspace_path = args.workspacepath
#     workspace_path = os.path.normpath(Path(workspace_path))
#     # version = config.paths.version
#     version = args.version
#     if version is None and workspace_path is not None:
#         version = config.paths.version
#     elif version is None and workspace_path is None:
#         raise Exception("Workspace path and version are not provided")

#     # workspace_path = os.path.normpath(Path(config.paths.workspace_path))
#     # version = config.paths.version
#     workspacename = f"{str(workspace_path).split('\\')[-1]}_{version}"

#     handler = DS3Handler(config_name, config, args, patterns, dirs, workspacename, workspace_path)

#     observer.schedule(handler, global_path, recursive=True)

#     return observer


# def main():
    # args = parse_args()
    # setup_logging(args.debug, args.redirect)

    # try:
    #     config_files = list_config_files()
    # except FileNotFoundError as e:
    #     logger.error(e)
    #     sys.exit(1)

    # if args.config:
    #     config_name = args.config
    #     try:
    #         validate_config_selection(config_name, config_files)
    #     except ValueError as e:
    #         logger.error(e)
    #         sys.exit(1)
    # else:
    #     config_name = get_config_selection(config_files)

    # config = load_config(config_name)
    # spec = read_indexignore_file._read_indexignore()
    # # patterns = list(spec.patterns)
    # dirs, exts, pattern = read_indexignore_file._index_ignore_extraction(spec)
    # patterns = dirs + exts + pattern
    # """
    # As soon as a new workspace is created, create a new workspacename_monitor table
    # """

    # logger.info('-'*60)
    # logger.info('watchdog started')
    # logger.info('-'*60)

    # logger.info(f"Starting pipeline with configuration: {config_name}")
    # path = Path(config.paths.root)

    # observer = Observer()
    # # TODO: here the workspace name must come in
    # workspace_path = os.path.normpath(Path(config.paths.workspace_path))
    # version = config.paths.version
    # workspacename = f"{str(workspace_path).split('\\')[-1]}_{version}"
    # handler = DS3Handler(config_name, config,args, patterns, dirs, workspacename)
    # observer.schedule(handler, path, recursive = True)
    
    # observer.start()


    # try:
    #     # while True:
    #     pid = os.getpid()
    #     # with open("watchdog.pid", "w") as f:
    #     #     f.write(str(pid))
    #     my_lib_path = make_dotfiles()
    #     con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
    #     cur = con.cursor()
    #     table_name = "master_table"
    #     cur.execute("""
    #         UPDATE master_table
    #         SET pid = ?
    #         WHERE workspacename = ?;
    #     """, (pid, workspacename))
    #     con.commit()
    #     # observer.join()

    #     cmd = input("> ") # to be removed while chaning on-startup server
    #     # if cmd == "q":
    #     #     break

    #     if not observer.is_alive():
    #         print("⚠️ Watchdog observer thread stopped unexpectedly!")
    #         # break
    #     time.sleep(2)
            
    # except KeyboardInterrupt:
    #     observer.stop()
    #     observer.join()




def addPIDtoMasterTable():

    logger.info("===== Inside PID =====")

    # workspace_path = os.path.normpath(Path(global_config.paths.workspace_path))
    # version = global_config.paths.version
    workspace_path = global_args.workspacepath
    if version is None and workspace_path is not None:
        version = global_config.paths.version
    elif version is None and workspace_path is None:
        raise Exception("Workspace path and version are not provided")

    workspacename = f"{str(workspace_path).split('\\')[-1]}_{version}"

    pid = os.getpid()

    my_lib_path = make_dotfiles()
    con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
    cur = con.cursor()
    table_name = "master_table"
    cur.execute("""
        UPDATE master_table
        SET pid = ?
        WHERE workspacename = ?;
    """, (pid, workspacename))
    con.commit()


def main():

    config = loadConfig()
    addPIDtoMasterTable()



if __name__ == "__main__":
    main()