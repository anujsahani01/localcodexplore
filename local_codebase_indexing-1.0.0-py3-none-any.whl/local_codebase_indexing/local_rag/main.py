"""
Watchdog:

Analyse the log activaticy and perform actions based on the different events based on the log activity
This works cross-platform
"""
import sys
import json
from pathlib import Path
from watchdog.observers import Observer    # watches the file systems and return events based on it  
from watchdog.events import FileSystemEventHandler, PatternMatchingEventHandler   # this responds to those events
import subprocess
import logging
from local_codebase_indexing.local_rag.utils.logger import setup_logging
from local_codebase_indexing.local_rag.utils.udf import parse_args
from local_codebase_indexing.local_rag.utils.config_utils import (
    list_config_files,
    load_config,
    get_config_selection,
    validate_config_selection,
)
import sqlite3
import os
import pandas as pd
from local_codebase_indexing.local_rag.extract import main as extract
from local_codebase_indexing.local_rag.transform import main as transform
from local_codebase_indexing.local_rag.events import event_handler
import platform
import hashlib
from local_codebase_indexing.local_rag.read_index_ignore import read_indexignore_file
from local_codebase_indexing.local_rag.events import event_handler
from datetime import datetime
from subprocess import PIPE, Popen
import subprocess



logger = logging.getLogger(__name__)

class ds3_content_provider():
    def __init__(self,workspacename, workspacepath, version, config, config_name, dirs):
        self.workspacename = workspacename
        self.workspacepath = workspacepath
        self.version = version
        self.config = config
        self.config_name = config_name
        self.ignored_dirs = dirs


    def _make_dotfiles(self):
        # Get user's home directory
        home_dir = Path.home()   # works on Windows, Linux, macOS
        my_lib_path = os.path.join(home_dir , ".LocalXplore")
        # my_lib_path.mkdir(exist_ok=True)
        if not os.path.exists(my_lib_path):
            os.mkdir(my_lib_path)
        return my_lib_path

    def _new_workspace(self):
        """
        workspacepath: This gives the full path of the workspace opened
        version: If two same workspace are opened then give it a different version
        last_indexed: The timestamp when start indexing button was clicked for a given workspace.
        """
        my_lib_path = self._make_dotfiles()
        con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
        cur = con.cursor()
        table_name = "master_table"
        cur.execute("SELECT name from sqlite_master WHERE type = 'table' AND name =?;", (table_name,))
        tables = cur.fetchall()
        if platform.system().lower() == "linux":
            path_key = 'unixfullpath'
        elif platform.system().lower() == "windows":
            path_key = 'windowsfullpath'        
        if not tables:
            cur.execute(f"""
                CREATE TABLE master_table (
                    workspacename TEXT PRIMARY KEY,
                    windowsfullpath TEXT NOT NULL DEFAULT "",
                    unixfullpath TEXT NOT NULL DEFAULT "",
                    version INTEGER NOT NULL,
                    last_indexed TEXT, 
                    pid TEXT NOT NULL DEFAULT "",
                    is_indexed INTEGER NOT NULL DEFAULT 0
                );
            """)
        
        workspacename = self.workspacename
        cur.execute(f"""
            INSERT OR REPLACE INTO "{table_name}"
            (workspacename, {path_key}, version, last_indexed)
            VALUES (?, ?, ?, ?)
        """,  (workspacename, self.workspacepath, self.version, str(datetime.now())))

        con.commit()

        # first executinng the extraction and transformtion pipeline for the very first time
        logger.info(f"Starting extraction pipleine for first time")
        # sys.argv = ["extract", "--config", str(self.config_name), "--workspace", str(self.workspacepath),"--version", str(self.config.paths.version)]
        extract.main([
            "--config", str(self.config_name),
            "--workspace", str(self.workspacepath),
            "--version", str(self.version)
        ])
        logger.info(f"Extration is done successfully")

        logger.info(f"Running the transformation/ chunking pipeline for first time")
        # sys.argv = ["transform", "--config", str(self.config_name), "--workspace", str(self.workspacepath), "--version", str(self.config.paths.version)]
        transform.main([
            "--config", str(self.config_name),
            "--workspace", str(self.workspacepath),
            "--version", str(self.version)
        ])
        logger.info(f"The transformation/extraction pipleline completed successfully")


        logger.info(f"Setting is_indexed to 1 for {workspacename}")
        my_lib_path = self._make_dotfiles()
        con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
        cur = con.cursor()
        table_name = "master_table"
        cur.execute("""
            UPDATE master_table
            SET is_indexed = ?
            WHERE workspacename = ?;
        """, (1, workspacename))
        con.commit()
        # as soon a a new workspace is made a new events table will be made for that workspace
        # sys.argv = ["events", "--config", str(self.config_name)]
        # event_handler.main()

    def on_modified(self, src_path):
        if self._filter_ignore_dir(src_path) is not None:
            src_path = self._filter_ignore_dir(src_path)
            # TODO: update the etl_config and give the exact file paths to be extract again -- optimization
            """combine cwd + src_path"""
            try:
                logger.info(f"File modified are:{src_path} and the type is {type(src_path)}")
                logger.info(f"Deleting the old files")
                self.on_deleted(src_path)
                logger.info(f"Starting extraction pipleine getting executed")
                # sys.argv = ["extract", "--config", str(self.config_name), "--workspace", self.workspacepath, "--filepaths", str(src_path)]
                extract.main([
                    "--config", str(self.config_name),
                    "--workspace", str(self.workspacepath),
                    "--filepaths", src_path,
                    "--version", str(self.version)
                ])
                logger.info(f"Extration is done successfully")

                logger.info(f"Running the transformation/ chunking pipeline")
                # sys.argv = ["transform", "--config", str(self.config_name), "--workspace", self.workspacepath, "--filepaths", str(src_path)]
                transform.main([
                    "--config", str(self.config_name),
                    "--workspace", str(self.workspacepath),
                    "--filepaths", src_path,
                    "--version", str(self.version) 
                ])
                logger.info(f"The transformation/extraction pipleline completed successfully")
                return
            
            except Exception as e:
                logger.info(f"Unexpected error occured while the event was triggerd on file modification is :{e}")


    def _filter_ignore_dir(self, paths):
        relevant_paths = []
        for ignored in self.ignored_dirs:
            for path in paths:
                norm_path = str(os.path.normpath(path)).replace("\\", "/")
                ignored = os.path.normpath(ignored)
                ignored = os.path.join(os.path.normpath(self.workspacepath), ignored)
                if os.path.commonpath([norm_path, ignored]) == ignored:
                    pass
                else:
                    relevant_paths.append(path)
        return list(set(relevant_paths))
    
    def on_deleted(self, src_path):
        if self._filter_ignore_dir(src_path) is not None:
            src_path = self._filter_ignore_dir(src_path)
            logger.info(f"File deleted are 🚀:{src_path}")
            """
            As the file is deleted or removed we just need to update the DB
            """
            my_lib_path = self._make_dotfiles()
            con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
            cur = con.cursor()

            """
            The extracted table for a given workspace will look like: workspacename_extract
            """
            logger.info(f"Accessing the table: {self.workspacename}_extract for deleting the respective files")
            cur.execute("SELECT name from sqlite_master WHERE type = 'table' AND name =?", (f"{self.workspacename}_extract",))
            tables = cur.fetchall()
            logger.info(f"The tables accessed are: {tables}")
            if platform.system().lower() == "linux":
                path_key = 'unixfullpath'
            elif platform.system().lower() == "windows":
                path_key = 'windowsfullpath'

            # Deleting that extracted file along with all its associated chunks
            if tables:
                logger.info(f"The workspacepath looks like: {self.workspacepath}")
                paths_list = [os.path.normpath(str(p)) for p in src_path]

                logger.info(f"The files to be deleted are: {paths_list}")
                placeholders = ",".join("?" * len(paths_list))
                paths_list_norm = [os.path.normpath(str(Path(p).resolve())) for p in paths_list]
                logger.info(f"The normalized paths for the deleted files are: {paths_list_norm}")
                query = f"""
                    DELETE FROM '{self.workspacename}_extract'
                    WHERE {path_key} IN ({placeholders})
                """
                cur.execute(query, paths_list_norm)
                query = f"""
                    DELETE FROM '{self.workspacename}_transform'
                    WHERE {path_key} IN ({placeholders})
                """
                cur.execute(query, paths_list_norm)

                query_dummy = f"""
                    SELECT {path_key} from '{self.workspacename}_extract'
                """
                cur.execute(query_dummy)
                rows = cur.fetchall()
                print(paths_list_norm)
                for row in rows:
                    if row in paths_list_norm:
                        pass
                    else:
                        print(row)
                # cur.execute(f"DELETE from {str(self.config.paths.extract_output).split('.')[0]} WHERE {path_key} = ?", (os.path.join(self.workspacepath, src_path),))
                con.commit()
            else:
                con.commit()
                raise Exception(f"{self.workspacename}_extract table does not exists")

            return
    

    def on_moved(self, src_path, dest_path):
        if self._filter_ignore_dir(src_path) is not None:
            logger.info(f"The File path: {src_path} is moved to {dest_path}")
            """
            As the file has just been moved so we just need to update the path and hash value
            """
            my_lib_path = self._make_dotfiles()
            con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
            cur = con.cursor()

            cur.execute("SELECT name from sqlite_master WHERE type = 'table' AND name = ?", (f"{self.workspacename}_extract",))
            tables = cur.fetchall()

            if platform.system().lower() == "linux":
                path_key = 'unixfullpath'
            elif platform.system().lower() == "windows":
                path_key = 'windowsfullpath'

            # update that extracted file along with all its associated chunks
            if tables:
                """
                when a file is moved:
                1) "file_hash" must be updated
                2) "windowsfullpath" / "unixfullpath" must be updated
                3) "file_path" must be updated
                """
                previous_full_path = os.path.join(self.workspacepath, src_path[0])
                new_full_path = os.path.join(self.workspacepath, dest_path[0])
                cur.execute(f"SELECT content, file_hash from '{self.workspacename}_extract' WHERE {os.path.normpath(str(path_key))} = ?", (os.path.normpath(str(previous_full_path)),))
                print(cur.fetchone())
                row = cur.fetchone()
                # content, old_file_hash
                con.commit()
                if row:
                    content, old_file_hash = row
                    data = (str(new_full_path) + str(content)).encode('utf-8')
                    new_file_hash = hashlib.sha256(data).hexdigest()

                    # as we are usin update cascade this will automatically update the values in side of transform table.
                    # cur.execute(f"UPDATE {str(self.config.paths.extract_output).split('.')[0]} SET file_hash = {new_file_hash}, {path_key} = {new_full_path}, file_path = {event.dest_path} WHERE file_hash = {old_file_hash}")
                    cur.execute(f"""
                        UPDATE "{str(self.config.paths.extract_output).split('.')[0]}"
                        SET file_hash = ?, {path_key} = ?, file_path = ? 
                        WHERE file_hash = ?
                    """, (new_file_hash, new_full_path, dest_path, old_file_hash))
                    logger.info(f"Successfully updated the file hash and file path")
                con.commit()
            else:
                con.commit()
                raise Exception(f"{self.workspacename}_{str(self.config.paths.extract_output).split('.')[0]} table does not exists")

            return

    def _re_index_workspace(self):
        """
        Once re-indexing starts:
        Will refer the: f"{self.workspacename}_monitor_table" 
        Then take required actions on the :
        modifled / deleted / moved files.
        """
        logger.info(f"Re-indexing started")
        my_lib_path = self._make_dotfiles()
        con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
        cur = con.cursor()
        table_name = "master_table"
        cur.execute("""
            SELECT pid FROM master_table
            WHERE workspacename = ?;
        """, (self.workspacename,))
        row = cur.fetchone()
        con.commit()
        pid_value = row[0]


        if platform.system() == "Windows":
            # Use the Windows-native 'tasklist' command with a filter
            command = ["tasklist", "/FI", f"PID eq {pid_value}"]
        else:
            # Use the standard Unix 'ps' command
            command = ["ps", "-p", str(pid_value)]

        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )

        out, err = process.communicate()
        if str(pid_value) in out.decode():
            logger.info(f"Process {pid_value} is running 🟢🟢🟢")
        else:
            logger.info(f"Process {pid_value} is not running 🔴🔴🔴")

        table_name = f"{self.workspacename}_monitor_table"
        home_dir = Path.home()   # works on Windows, Linux, macOS
        my_lib_path = os.path.join(home_dir , ".LocalXplore")
        # my_lib_path.mkdir(exist_ok=True)
        if not os.path.exists(my_lib_path):
            os.mkdir(my_lib_path)
        con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
        cur = con.cursor()
        """
        sqlite_master: is SQLite's internal catalog of tables, indexes, triggers, etc.
        """
        logger.info(f"Fetching for monitor table: {table_name}")

        # TODO: Delete
        cur.execute(
            "SELECT name from sqlite_master WHERE type = 'table'"
        )
        tables = cur.fetchall()
        logger.info(f"The list of all tables are : {tables}")

        cur.execute(
            "SELECT name from sqlite_master WHERE type = 'table'AND name =?;",
            (table_name,),
        )
        tables = cur.fetchall()
        logger.info(f"The monitor table is : {tables}")
        if tables:
            dataframe = pd.read_sql_query(
                f"SELECT * FROM '{table_name}'", con
            )
            modified_paths = dataframe['modified'].tolist()
            deleted_paths = dataframe['deleted'].tolist()
            moved_paths = dataframe['moved'].tolist()
            modified_paths = list(filter(None, modified_paths))
            deleted_paths = list(filter(None, deleted_paths))
            moved_paths = list(filter(None, moved_paths))
            modified_paths = [x for x in modified_paths if x.strip()]
            deleted_paths = [x for x in deleted_paths if x.strip()]

            modified_paths = [str(Path(p).resolve()) for p in modified_paths]
            deleted_paths =  [str(Path(p).resolve()) for p in deleted_paths]

            logger.info(f"The modified file paths are: {modified_paths}")
            logger.info(f"The deleted file paths are :{deleted_paths}")
            logger.info(f"The moved file pats are: {moved_paths}")


            if modified_paths is not None:
                self.on_modified(modified_paths)
            if deleted_paths is not None:
                self.on_deleted(deleted_paths)

            # converting the sting back to json
            if moved_paths is not None:
                for path_dict in moved_paths:
                    if path_dict != "":
                        path_dict = json.loads(path_dict)
                        src_path = path_dict.get("src_path")
                        dest_path = path_dict.get("dest_path")
                        if src_path[0].strip() and dest_path[0].strip():
                            self.on_moved([Path(src_path).resolve()], [Path(dest_path).resolve()])
                        else:
                            continue
            con.commit()

        else:
            con.commit()
            logger.info(f"No changes to be re-indexed")
            return



def main(argv = None):
    args = parse_args(argv)
    setup_logging(args.debug, args.redirect)

    try:
        config_files = list_config_files()
    except FileNotFoundError as e:
        logger.error(e)
        # sys.exit(1)

    if str(args.config) == "demo":
        config_name = args.config
        try:
            validate_config_selection(config_name, config_files)
        except ValueError as e:
            logger.error(e)
            # sys.exit(1)
    else:
        config_name = get_config_selection(config_files)

    config = load_config(config_name)  

    # instead of reading the path from config we will be reading path from system args
    # workspace_path = os.path.normpath(Path(config.paths.workspace_path))
    # changed
    # not reading it again it will override th epassed args
    # args = parse_args()
    workspace_path = os.path.normpath(Path(args.workspacepath))
    version = args.version
    if version is None and workspace_path is not None:
        version = config.paths.version
    elif version is None and workspace_path is None:
        raise Exception("Workspace path and version are not provided")
    
    print(f"Workspacepath: {workspace_path} \n Version: {version}")


    # older
    # workspace_path = os.path.normpath(Path(config.paths.workspace_path))
    # version = config.paths.version
    workspace_name = f"{str(workspace_path).split('\\')[-1]}_{version}"

    # reading the inxedignore from workspacepath
    read_indexignore_obj = read_indexignore_file(workspace_path)
    spec = read_indexignore_obj._read_indexignore()
    # patterns = list(spec.patterns)

    dirs, exts, pattern = read_indexignore_file._index_ignore_extraction(spec)
    home_dir = Path.home()   # works on Windows, Linux, macOS
    my_lib_path = os.path.join(home_dir , ".LocalXplore")
    # my_lib_path.mkdir(exist_ok=True)
    if not os.path.exists(my_lib_path):
        os.mkdir(my_lib_path)

    context_provider = ds3_content_provider(workspace_name, workspace_path, version, config, config_name, dirs)

    # checking if the workspace already exists
    con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
    cur = con.cursor()
    table_name = "master_table"
    cur.execute("SELECT name from sqlite_master WHERE type = 'table' AND name =?;", (table_name,))
    row = cur.fetchone()

    if row:
        cur.execute(
            "SELECT last_indexed FROM master_table WHERE workspacename = ?;",
            (workspace_name,)
        )
        row = cur.fetchone()
        if row:
            last_indexed = row[0]
            logger.info(f"Workspace found as we last indexed at {last_indexed}")
            logger.info(f"Starting the re-indexing....")
            context_provider._re_index_workspace()
        else:
            logger.info("Workspace not found, Creating a new workspace")
            context_provider._new_workspace()

    else:
        logger.info("Workspace not found, Creating a new master table and workspace")
        context_provider._new_workspace()
    


# if __name__ == "__main__":
#     main(([
#             "--workspacepath", "D:/work_dsi/ASI84/tempp",
#             "--version", "102"
#         ]))
