"""
Watchdog:

Analyse the log activaticy and perform actions based on the different events based on the log activity
This works cross-platform
"""
import sys
from pathlib import Path
from watchdog.observers import Observer    # watches the file systems and return events based on it  
from watchdog.events import FileSystemEventHandler, PatternMatchingEventHandler   # this responds to those events
import subprocess
import logging
from local_rag.utils.logger import setup_logging
from local_rag.utils.udf import parse_args
from local_rag.utils.config_utils import (
    list_config_files,
    load_config,
    get_config_selection,
    validate_config_selection,
)
import sqlite3
import os
from local_rag.extract import main as extract
from local_rag.transform import main as transform
import platform
import hashlib
from local_rag.read_index_ignore import read_indexignore_file
from datetime import datetime

logger = logging.getLogger(__name__)

# def run_step(script, config_name, debug, redirect):
#     command = ["python", script, "--config", config_name]
#     if debug:
#         command.append("--debug")
#     if redirect:
#         command.extend(["--redirect", redirect])
#     try:
#         result = subprocess.run(command, capture_output=True, text=True, check=True)
#         logger.info(f"stderr: {result.stderr}")
#     except subprocess.CalledProcessError as e:
#         # If the subprocess fails, log the error and raise an exception
#         logger.error(f"Subprocess failed with exit code {e.returncode}")
#         logger.error(f"stderr: {e.stderr}")
#         raise RuntimeError(f"Subprocess failed: {e}") from e


class DS3Handler(PatternMatchingEventHandler):

    # TODO: just monitor the chnages done in the specified folders as .pyc/ .pyd file inide env gets updated every time
    def __init__(self, config_name, config,args, patterns, dirs):
        super().__init__(
            ignore_patterns= patterns
        )
        self.config_name = config_name
        self.config = config
        self.args = args
        self.ignored_dirs = dirs
        self._last_event_time = {}
        self._wait_interval = 30

    def _should_ignore_dir(self, path):
        path = os.path.normpath(path).replace("\\", "/")
        for ignored in self.ignored_dirs:
            ignored = os.path.normpath(ignored)
            if os.path.commonpath([path, ignored]) == ignored:
                return True
        
        return False
    
    """
    watchdog beaviour various on various os platform sometimes it takes a single event as 2 differnet events in milliseconds.
    """
    def _is_duplicate_event(self, event):
        now = datetime.now()
        last_time = self._last_event_time.get(event.src_path)
        if last_time:
            time_dff = now - last_time
            if int(time_dff.total_seconds()) < self._wait_interval:
                return True
            self._last_event_time[event.src_path] = now
        
        return False


    def on_modified(self, event):
        if not self._should_ignore_dir(event.src_path) and not self._is_duplicate_event(event):
            # TODO: update the etl_config and give the exact file paths to be extract again -- optimization
            """combine cwd + src_path"""
            try:
                self._last_event_time[event.src_path] = datetime.now()
                logger.info(f"File modified is:{event.src_path}")
                logger.info(f"Starting extraction pipleine getting executed")
                sys.argv = ["extract", "--config", str(self.config_name)]
                extract.main()
                logger.info(f"Extration is done successfully")

                logger.info(f"Running the transformation/ chunking pipeline")
                sys.argv = ["transform", "--config", str(self.config_name)]
                transform.main()
                logger.info(f"The transformation/extraction pipleline completed successfully")
                return super().on_modified(event)
            
            except Exception as e:
                logger.info(f"Unexpected error occured while the event was triggerd on file modification is :{e}")
    
    def on_deleted(self, event):
        if not self._should_ignore_dir(event.src_path) and not self._is_duplicate_event(event):
            logger.info(f"File deleted is:{event.src_path}")
            """
            As the file is deleted or removed we just need to update the DB
            """
            # TODO: as of now we are keeping the DB in the current working directory
            self._last_event_time[event.src_path] = datetime.now()
            con = sqlite3.connect(os.path.join(self.config.paths.root, "DS3.db"))
            cur = con.cursor()

            cur.execute("SELECT name from sqlite_master WHERE type = 'table' AND name =?", (str(self.config.paths.extract_output).split(".")[0],))
            tables = cur.fetchall()

            if platform.system().lower() == "linux":
                path_key = 'unixfullpath'
            elif platform.system().lower() == "windows":
                path_key = 'windowsfullpath'

            # Deleting that extracted file along with all its associated chunks
            if tables:
                cur.execute(f"DELETE from '{str(self.config.paths.extract_output).split('.')[0]}' WHERE {path_key} = ?", (os.path.join(os.getcwd(), event.src_path),))
                con.commit()
            else:
                raise Exception(f"{str(self.config.paths.extract_output).split(".")[0]} table does not exists")

            return super().on_deleted(event)
    
    def on_moved(self, event):
        if not self._should_ignore_dir(event.src_path) and not self._is_duplicate_event(event):
            logger.info(f"The File path: {event.src_path} is moved to {event.dest_path}")
            """
            As the file has just been moved so we just need to update the path and hash value
            """

            # TODO: as of now we are keeping the DB in the current working directory
            self._last_event_time[event.src_path] = datetime.now()
            self._last_event_time[event.dest_path] = datetime.now()

            con = sqlite3.connect(os.path.join(self.config.paths.root, "DS3.db"))
            cur = con.cursor()

            cur.execute("SELECT name from sqlite_master WHERE type = 'table' AND name = ?", (str(self.config.paths.extract_output).split(".")[0],))
            tables = cur.fetchall()

            if platform.system().lower() == "linux":
                path_key = 'unixfullpath'
            elif platform.system().lower() == "windows":
                path_key = 'windowsfullpath'

            # update that extracted file along with all its associated chunks
            if tables:
                """
                when a file is moved:
                1) "file_hash" must be updated
                2) "windowsfullpath" / "unixfullpath" must be updated
                3) "file_path" must be updated
                """
                previous_full_path = os.path.join(os.getcwd(), event.src_path)
                new_full_path = os.path.join(os.getcwd(), event.dest_path)
                
                cur.execute(f"SELECT content, file_hash from '{str(self.config.paths.extract_output).split('.')[0]}' WHERE {path_key} = ?", (previous_full_path,))
                content, old_file_hash = cur.fetchone()
                con.commit()
                data = (str(new_full_path) + str(content)).encode('utf-8')
                new_file_hash = hashlib.sha256(data).hexdigest()

                # as we are usin update cascade this will automatically update the values in side of transform table.
                # cur.execute(f"UPDATE {str(self.config.paths.extract_output).split(".")[0]} SET file_hash = {new_file_hash}, {path_key} = {new_full_path}, file_path = {event.dest_path} WHERE file_hash = {old_file_hash}")
                cur.execute(f"""
                    UPDATE '{str(self.config.paths.extract_output).split(".")[0]}' 
                    SET file_hash = ?, {path_key} = ?, file_path = ? 
                    WHERE file_hash = ?
                """, (new_file_hash, new_full_path, event.dest_path, old_file_hash))
            else:
                raise Exception(f"{str(self.config.paths.extract_output).split(".")[0]} table does not exists")

            return super().on_moved(event)


def main():
    args = parse_args()
    setup_logging(args.debug, args.redirect)

    try:
        config_files = list_config_files()
    except FileNotFoundError as e:
        logger.error(e)
        sys.exit(1)

    if args.config:
        config_name = args.config
        try:
            validate_config_selection(config_name, config_files)
        except ValueError as e:
            logger.error(e)
            sys.exit(1)
    else:
        config_name = get_config_selection(config_files)

    config = load_config(config_name)
    spec = read_indexignore_file._read_indexignore()
    # patterns = list(spec.patterns)
    dirs, exts, pattern = read_indexignore_file._index_ignore_extraction(spec)
    patterns = dirs + exts + pattern
    #TODO: check if there is not extract and transform table in DB
    # first executinng the extraction and transformtion pipeline for the very first time
    logger.info(f"Starting extraction pipleine for first time")
    sys.argv = ["extract", "--config", str(config_name)]
    extract.main()
    logger.info(f"Extration is done successfully")

    logger.info(f"Running the transformation/ chunking pipeline for first time")
    sys.argv = ["transform", "--config", str(config_name)]
    transform.main()
    logger.info(f"The transformation/extraction pipleline completed successfully")


    logger.info(f"Starting pipeline with configuration: {config_name}")
    path = Path(config.paths.root)
    observer = Observer()
    handler = DS3Handler(config_name, config, args, patterns, dirs)
    observer.schedule(handler, path, recursive = True)
    observer.start()

    while True:
        cmd = input("> ")
        if cmd == "q":
            break

    observer.stop()
    observer.join()


if __name__ == "__main__":
    main()