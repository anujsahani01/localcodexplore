
import os
from pathlib import Path

from local_codebase_indexing.local_rag.utils.config_utils import (
    get_config_selection, list_config_files, load_config)
from local_codebase_indexing.local_rag.utils.udf import parse_args


def getWorkSpaceName():

    args = parse_args()

    config_files = list_config_files()
    
    config_name = get_config_selection(config_files)

    config = load_config(config_name)
    workspace_path = os.path.normpath(Path(args.workspacepath))
    version = args.version
    if version is None and workspace_path is not None:
        version = config.paths.version
    elif version is None and workspace_path is None:
        raise Exception("Workspace path and version are not provided")


    # workspace_path = os.path.normpath(Path(config.paths.workspace_path))
    # version = config.paths.version
    workspace_name = f"{str(workspace_path).split('\\')[-1]}_{version}"

    return workspace_name 



if __name__ == "__main__":

    workspacename = getWorkSpaceName()

