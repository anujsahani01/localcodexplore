
import uvicorn

from codebase_context_provider.app.app import fastapi_app


def main(argv = None):
    uvicorn.run(fastapi_app,host="localhost",port=8000)


if __name__ == "__main__":
    main()

    