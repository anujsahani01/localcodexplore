
import asyncio
from datetime import datetime, timezone
import json
import os
import time

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import RedirectResponse
from sse_starlette.sse import EventSourceResponse
from codebase_context_provider.service.indexing_controller import get_controller, get_global_indexing_status
from codebase_context_provider.service.loadvectordatabase import \
    LoadVectorDatabase
from codebase_context_provider.service.recordmanager import RecordManager
from codebase_context_provider.service.retrival_status import GlobalRetrievalEvent, RetrievalStatus
from codebase_context_provider.utils.events import EventStore, IndexingStatus
from codebase_context_provider.utils.helper import INDEX_PATH, trim_path
from codebase_context_provider.utils.localcontextprovider import \
    LocalContextProvider
from codebase_context_provider.utils.serverstatus import ServerStatus
from codebase_context_provider.utils.localcontextprovider import contextlogger
from local_codebase_indexing.local_rag import main as etl
from starlette.concurrency import run_in_threadpool

local_vector_db = LoadVectorDatabase()
local_lsh_vectorstore = None


router = APIRouter()


@router.get("/",include_in_schema=False)
def redirect_to_docs():
    return RedirectResponse(url="/docs")



@router.get("/indexingstatus")
async def getIndexingStatus(req: Request, workspacepath: str | None = Query(None),version: str | None = Query(None)):
    
    async def stream():
        # status when workspace/version not provided
        if not workspacepath or not version:
            while not await req.is_disconnected():
                status = get_global_indexing_status()
                yield f": ping - {datetime.now(timezone.utc).isoformat()} | {status}"
                await asyncio.sleep(2)
            return
        
        # Send latest immediately (if already exists)
        latest_event = EventStore.getLatestEvent(workspacepath, version)
        if latest_event:
            yield f"{latest_event.model_dump()}"

        q = EventStore.getQueue(workspacepath, version)

        while not await req.is_disconnected():
            try:
                event = await asyncio.wait_for(q.get(), timeout=10)
                if event:
                    yield f"{event.model_dump()}"
            except asyncio.TimeoutError:
                controller = get_controller(workspacepath, version)

                if controller.task is None or controller.task.done():
                    status = "indexing not running"
                else:
                    status = "indexing running" if controller.pause_event.is_set() else "indexing paused"

                yield f": ping - {datetime.now(timezone.utc).isoformat()} | {status}"
           
    
    return EventSourceResponse(stream(),ping=None)



@router.get("/serverstatus")
def getServerStatus():

    server_status = ServerStatus()

    response = server_status.getServerDetails(8000)

    contextlogger.info(f"===== Server Response ===== {response}")

    try:
        
        response_list = json.loads(response)

        if response_list and isinstance(response_list,list) and len(response_list) > 0:
            
            ide_info = response_list[0].get("ide")

            if ide_info:

                logical_name = ide_info.get("logical_name")

                if logical_name:
                    return {"app_status":"Running","IDE":logical_name}
                else:
                    contextlogger.info("===== No known IDE found in the process =====")
                    return {"appstatus":"Running","IDE": "No known IDE found"}
            else:
                contextlogger.info("===== No process details found =====")
                return {"appstatus":"Not Running","IDE": "No process details found"}
    
    except json.JSONDecodeError:
        contextlogger.error("===== Failed to decode JSON response =====")
        return {"error": "Failed to decode JSON response"}



@router.post("/indexing")
async def startIndexing(workspacepath:str = Query(None,description="The name of workspacepath"), version:str = Query(None, description = "Give me the version of the workspacepath")):

    contextlogger.info("===== Extraction & Transformation Pipeline Started =====")
    """
    SQL is causing issues if the name contains "-" instead of "_" 
    """
    
    if version is None and workspacepath is not None:
        version = 100
    elif version is None and workspacepath is None:
        raise Exception("Workspace path and version are not provided")
    
    controller = get_controller(workspacepath, version)
    contextlogger.info(f"The workspacepath to be indexed is {workspacepath} and the version of the workspace is {version}")
    # check for already running
    if controller.task and not controller.task.done():
        return {"response": "Indexing already running"}

    controller.pause_event.set()
    
    async def runner():
        try:
            await run_in_threadpool(
                etl.main,
                [
                    "--workspacepath", str(workspacepath),
                    "--version", str(version)
                ]
            )

            contextlogger.info("===== Extraction & Transformation Pipeline Completed =====")
            
            await EventStore.addEvent(workspacepath, version,
                    IndexingStatus(completed=0, state="running", message="ETL completed"))


            indexworkspacename = f"{str(workspacepath).split('\\')[-1]}_{version}"
            indexworkspacename = str(indexworkspacename)
            # indexworkspacename = f"{str(workspacepath).split('\\')[-1].replace('-', '_')}_{version}"
            recordManagerInstance = RecordManager(workspacepath,indexworkspacename,version)
            await recordManagerInstance.createRecordManager()
            await EventStore.addEvent(workspacepath, version,
                IndexingStatus(completed=0, state="running", message="SQL Record manager ready"))
            
            contextlogger.info("===== Indexing Pipeline Started =====")
            await  recordManagerInstance.addData(controller)
            
        except Exception as e:
            contextlogger.info("===== Issue with runner =====")
            contextlogger.warning(f"Unexpected Error occured while adding the event and getting the status is: {e}")
            await EventStore.addEvent(workspacepath, version,
                IndexingStatus(completed=0, state="failed", message=str(e)))
            
            contextlogger.info("===== Indexing Pipeline Completed =====")

    controller.task = asyncio.create_task(runner())
    
    return {"response":"Indexing Started"}

@router.post("/indexing/pauseorresume")
async def pauseorresume_indexing(
    workspacepath: str = Query(...),
    version: str = Query(...),
    action: int = Query(..., description="0 = pause, 1 = resume")
        ):
    controller = get_controller(workspacepath, version)

    if not controller.task or controller.task.done():
        return {"status": f" indexing for {workspacepath}: not_running"}

    if action == 0:
        controller.pause_event.clear()
        return {"status": f" indexing for {workspacepath}: paused"}

    elif action == 1:
        controller.pause_event.set()
        return {"status": f" indexing for {workspacepath}: resumed"}

    else:
        return {"status": "invalid_action", "message": "Use action=0 (pause) or action=1 (resume)"}


brandNameList = ['CATIA Design And Engineering', 'nan', '3DEXCITE', 'Operations', 'CATIA Cyber System', 'NETVIBES', 'SOLIDWORKS', 'DELMIA', 'GEOVIA', 'Medidata', 'CATIA CCT', '3DSOUTSCALE', 'Misc', '3DExp_Platform', 'Technologies', 'SIMULIA', 'Undef', 'ENOVIA', 'RnD Customer Strategic Partnerships']

def checkBrandName(brandName):
    if brandName in brandNameList:
        return brandName
    else:
        return None
    


# adding the ability to filter based on filepaths as well
def built_filter_condition(includeAllFilters, **kwargs):
    filter_list = []

    for key, value in kwargs.items():
        if value is not None:
            # ── Support list values (e.g. multiple filepaths) ──
            if isinstance(value, list) and len(value) > 0:
                filter_list.append({key: {"$in": value}})
            else:
                filter_list.append({key: {"$eq": value}})

    if len(filter_list) == 0:
        return None

    return {"$and": filter_list} if includeAllFilters == True else {"$or": filter_list}


def run_async_search(full_input, num_of_docs, file_extension, owner, brandName, includeAllFilters, source = None):
    
    filter_condition = built_filter_condition(
        includeAllFilters, 
        file_extension=file_extension, 
        owner=owner, brandName=brandName,
        source = source)
    contextlogger.info(f"Filter condition: {filter_condition}")

    async def async_search():
        return await local_lsh_vectorstore.asimilarity_search(
            full_input,
            k=num_of_docs,
            filter=filter_condition
        )

    return async_search()

@router.get("/retrievalstatus")
async def getRetrievalStatus(req: Request):

    async def stream():
        latest = GlobalRetrievalEvent.getLatest()

        if not latest:
            latest = RetrievalStatus(
                status="NOT_RUNNING",
                active_count=0,
                message="No retrieval running"
            )

        yield f"{json.dumps(latest.model_dump())}"

        while not await req.is_disconnected():
            event = await GlobalRetrievalEvent._queue.get()
            yield f"{json.dumps(event.model_dump())}"
            await asyncio.sleep(0.1)

    return EventSourceResponse(stream())

@router.post("/retrieve")
async def retrieveData(input_text: LocalContextProvider,workspacepath:str = Query(None,description="The name of workspacepath"), version:str = Query(None, description = "Give me the version of the workspacepath")):
   
    workspacename = f"{str(workspacepath).split('\\')[-1]}_{version}"

    # RUNNING (global)
    await GlobalRetrievalEvent.start(workspacepath, version, workspacename)
    try:
        global local_lsh_vectorstore
        indexworkspacepath = os.path.join(INDEX_PATH,trim_path(workspacepath),workspacename)
        
        # if workspacename is None:
        #     local_lsh_vectorstore = local_vector_db.load_vectorstore_dynamically(input_text.options.get("workspacename"))
        # else:
        #     local_lsh_vectorstore = local_vector_db.load_vectorstore_dynamically(workspacename)
        
        local_lsh_vectorstore=local_vector_db.load_vectorstore_dynamically(indexworkspacepath)
        
        file_extension = input_text.options.get("fileExtension") if input_text.options else None
        if file_extension:
            file_extension = file_extension.lower()


        # adding filepath filter
        source = input_text.options.get("filePaths") if input_text.options else None
        # Accepts: single string OR list of paths
        # e.g. "src/main.py" or ["src/main.py", "src/routes.py"]

        num_of_docs = input_text.options.get("retrievalDocCount") if input_text.options else 10
        owner = input_text.options.get("owner") if input_text.options else None
        if owner:
            owner = owner.lower()

        includeAllFilters = input_text.options.get("includeAllFilters") if input_text.options else False
        if includeAllFilters is None:
            includeAllFilters = False

        brandName = input_text.options.get("brandName") if input_text.options else None
        brandName = checkBrandName(brandName)

        start_time = time.time()
        contextlogger.info("===== Retrieval Started =====")

        try:
            results = await run_async_search(
                input_text.fullInput,
                num_of_docs,
                file_extension,
                owner,
                brandName,
                includeAllFilters,
                source = source,
            )
        except Exception as e:
            contextlogger.exception("===== Retrieval failed =====")
            raise HTTPException(status_code=500, detail=f"Error during similarity search: {str(e)}")

        end_time = time.time()
        contextlogger.info(f"===== Retrieval completed in {end_time - start_time:.2f} seconds =====")

        context_items = [
            {
                "name":  result.metadata.get("source","null"),  
                "content": result.page_content,
                "uri":""
            }
            for result in results
        ]

        # COMPLETED (global)
        await GlobalRetrievalEvent.complete(workspacepath, version, workspacename, found_count=len(results))
        
        return context_items

    except Exception as e:
        # ✅ Publish FAILED (global)
        await GlobalRetrievalEvent.fail(workspacepath, version, workspacename, error=str(e))

        contextlogger.exception("===== Retrieval failed =====")
        raise HTTPException(status_code=500, detail=f"Error during similarity search: {str(e)}")




