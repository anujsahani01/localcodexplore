
import os
from pathlib import Path

import faiss
from langchain_community.docstore import InMemoryDocstore
from langchain_community.vectorstores import FAISS

from codebase_context_provider.model.embeddingmodel import CustomEmbeddingModel
from codebase_context_provider.utils.logger import LoggingClass

loggerClass = LoggingClass(name="IndexCreation", log_file_path="IndexCreation.log")
logger = loggerClass.get_logger()

HOME_PATH = Path.home()
DATABASE_PATH = os.path.join(HOME_PATH,".LocalXplore//Index")


class IndexCreation:

    def __init__(self,path = None):
        
        if path:
            # normalize into DATABASE_PATH
            path = os.path.join(DATABASE_PATH, path)


        self.fullPath = path

        if path and os.path.exists(path):
            logger.info(f"===== Index found at {path} =====")
            self.vectorstore = self.loadIndex(path)
        else:
            self.vectorstore = self.createIndex()
            self.saveIndex(self.vectorstore,path)


    def loadEmbeddingModel(self):    
        
        embeddingModel = CustomEmbeddingModel(
            model_name="nomic-ai/CodeRankEmbed",
            model_kwargs={"trust_remote_code": True, "device": "cpu"}
        )

        return embeddingModel


    def createIndex(self):

        embeddingModel = self.loadEmbeddingModel()
        logger.info("===== Embedding Model Loaded =====")

        sentence_transformer_model = embeddingModel._client
        embedding_dimension = sentence_transformer_model[1].word_embedding_dimension
        logger.info(f"====== Embedding Dimension: {embedding_dimension} ======")

        nbits = embedding_dimension
        lsh_index = faiss.IndexLSH(embedding_dimension, nbits)
        logger.info("====== LSH FAISS Index Created ======")

        lsh_vectorestore = FAISS(
            embedding_function = embeddingModel,
            index = lsh_index,
            docstore = InMemoryDocstore({}),
            index_to_docstore_id={}
        )

        logger.info("====== LangChain FAISS Vector Store Initialized =====")

        return lsh_vectorestore
    

    def saveIndex(self, vectorstore, folder_name):
        full_path = os.path.join(DATABASE_PATH, folder_name)
        self.fullPath = full_path
        os.makedirs(folder_name, exist_ok=True)

        vectorstore.save_local(folder_name)
        logger.info(f"====== Index Saved at {folder_name} ======")

    
    def loadIndex(self,path):
        
        vectorstore = FAISS.load_local(
            path,
            embeddings=self.loadEmbeddingModel(),
            allow_dangerous_deserialization=True
        )

        logger.info(f"===== Loading the Vector Store from {path} =====")

        return vectorstore


if __name__ == "__main__":

    workspace_name = "Workspace3"
    fullWorkSpacePath = os.path.join(DATABASE_PATH, workspace_name)

    index_creator = IndexCreation(fullWorkSpacePath)
    vectorstore = index_creator.createIndex()

    index_creator.saveIndex(vectorstore, workspace_name)

    vectordb = index_creator.loadIndex(fullWorkSpacePath)

    