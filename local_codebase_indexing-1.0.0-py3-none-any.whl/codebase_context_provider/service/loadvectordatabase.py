
import os
import sqlite3
import time
from pathlib import Path

from langchain_community.vectorstores import FAISS

from codebase_context_provider.model.embeddingmodel import CustomEmbeddingModel
from codebase_context_provider.utils.logger import LoggingClass

loggerClass = LoggingClass(name="LoadVectorDatabase", log_file_path='LoadVectorDatabase.log')
logger = loggerClass.get_logger()

# HOME_PATH = Path.home()
# INDEX_PATH = os.path.join(HOME_PATH,".LocalXplore\\Index")

class LoadVectorDatabase:
    
    def __init__(self, model_path: str = "nomic-ai/CodeRankEmbed", sqlite_path: str = None):
        self.model_path = model_path
        self.home_path = Path.home()

        if sqlite_path is None:
            self.sqlite_path = os.path.join(self.home_path, ".DS3Xplore//DS3.db")

        self.vector_db_path = None
        self.vectorstore = None
        self.sqlite_db = None
        #self.path =  os.path.join(INDEX_PATH,trim_path(wspath)

        self.initialize_embedding_model()


    def initialize_embedding_model(self):
        logger.info("-" * 60)
        logger.info("===== Initializing Custom Embedding model =====")

        try:
            self.embedding_model = CustomEmbeddingModel(
                model_name=self.model_path,
                model_kwargs={"trust_remote_code": True, "device": "cpu"}
            )
            logger.info("===== Custom Embedding model Loaded =====")
        except Exception as e:
            logger.exception("===== Failed to initialize embedding model =====")
            raise


    def load_faiss_vectorstore(self, indexworkspacepath: str):

        self.vector_db_path = indexworkspacepath

        logger.info(f"===== Loading FAISS vectorstore from: {self.vector_db_path} =====")

        try:
            start_time = time.time()
            self.vectorstore = FAISS.load_local(
                self.vector_db_path,
                self.embedding_model,
                allow_dangerous_deserialization=True
            )
            end_time = time.time()

            logger.info(f"===== Loaded FAISS vectorstore =====")
            logger.info(f"===== Total entries in vector store: {self.vectorstore.index.ntotal} =====")
            logger.info(f"===== Load time: {end_time - start_time:.2f} seconds =====")
        except Exception as e:
            logger.exception("===== Failed to load FAISS vectorstore =====")
            raise


    def load_sqlite_database(self, workspacename):
        logger.info(f"===== Loading SQLite database from: {self.sqlite_path} =====")

        try:
            self.sqlite_db = sqlite3.connect(self.sqlite_path)
            logger.info(f"===== SQLite database loaded from {self.sqlite_path} =====")

            cursor = self.sqlite_db.cursor()

            workspacename = os.path.join(self.path, workspacename)
            workspacename_to_retrieve = workspacename

            query = "SELECT workspacename FROM master_table WHERE workspacename = ?"
            cursor.execute(query, (workspacename_to_retrieve,))
            data = cursor.fetchone()

            if data is None:
                logger.error(f"===== No entry found for workspacename: {workspacename_to_retrieve} =====")
                raise ValueError(f"No entry found for workspacename: {workspacename_to_retrieve}")

            return data[0]
        
        except sqlite3.Error as e:
            logger.exception(f"===== An error occurred while loading the SQLite database {e} =====")
            raise


    def load_vectorstore_dynamically(self, indexworkspacepath: str):
        self.load_faiss_vectorstore(indexworkspacepath)
        return self.vectorstore

    def get_vectorstore(self):
        return self.vectorstore

    def get_sqlite_db(self):
        return self.sqlite_db




if __name__ == "__main__":

    local_context_provider = LoadVectorDatabase()
    local_context_provider.load_faiss_vectorstore("Testing_1")
    vectorstore = local_context_provider.get_vectorstore()
    print(vectorstore)


