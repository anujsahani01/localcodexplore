# retrieval_status.py
from pydantic import BaseModel
from typing import Literal, Optional
import asyncio

class RetrievalStatus(BaseModel):
    status: Literal["NOT_RUNNING", "RUNNING", "COMPLETED", "FAILED"]
    active_count: int = 0
    message: Optional[str] = None


class GlobalRetrievalEvent:
    _queue: asyncio.Queue[RetrievalStatus] = asyncio.Queue()
    _latest: Optional[RetrievalStatus] = None

    _active_count: int = 0
    _lock = asyncio.Lock()

    _last_workspacepath: Optional[str] = None
    _last_version: Optional[str] = None
    _last_workspacename: Optional[str] = None

    @staticmethod
    def _make_ws_text(workspacepath: str = None, version: str = None, workspacename: str = None) -> str:
        parts = []
        if workspacename:
            parts.append(f"workspace={workspacename}")
        if workspacepath:
            parts.append(f"path={workspacepath}")
        if version:
            parts.append(f"version={version}")
        return " | ".join(parts)

    @staticmethod
    async def _publish(status: str, message: str = None):
        event = RetrievalStatus(
            status=status,
            active_count=GlobalRetrievalEvent._active_count,
            message=message
        )
        GlobalRetrievalEvent._latest = event
        await GlobalRetrievalEvent._queue.put(event)

    @staticmethod
    async def start(workspacepath: str, version: str, workspacename: str):
        async with GlobalRetrievalEvent._lock:
            GlobalRetrievalEvent._active_count += 1

            GlobalRetrievalEvent._last_workspacepath = workspacepath
            GlobalRetrievalEvent._last_version = str(version)
            GlobalRetrievalEvent._last_workspacename = workspacename

            ws_text = GlobalRetrievalEvent._make_ws_text(workspacepath, str(version), workspacename)

            await GlobalRetrievalEvent._publish(
                "RUNNING",
                f"Retrieval RUNNING ({ws_text}) | active={GlobalRetrievalEvent._active_count}"
            )

    @staticmethod
    async def complete(workspacepath: str, version: str, workspacename: str, found_count: int):
        async with GlobalRetrievalEvent._lock:
            ws_text = GlobalRetrievalEvent._make_ws_text(workspacepath, str(version), workspacename)

            await GlobalRetrievalEvent._publish(
                "COMPLETED",
                f"Retrieval COMPLETED ({ws_text}) | found={found_count} | active={GlobalRetrievalEvent._active_count}"
            )

            GlobalRetrievalEvent._active_count = max(0, GlobalRetrievalEvent._active_count - 1)

            if GlobalRetrievalEvent._active_count == 0:
                await GlobalRetrievalEvent._publish("NOT_RUNNING", "No retrieval running")
            else:
                await GlobalRetrievalEvent._publish("RUNNING", f"Retrieval still RUNNING | active={GlobalRetrievalEvent._active_count}")

    @staticmethod
    async def fail(workspacepath: str, version: str, workspacename: str, error: str):
        async with GlobalRetrievalEvent._lock:
            ws_text = GlobalRetrievalEvent._make_ws_text(workspacepath, str(version), workspacename)

            await GlobalRetrievalEvent._publish(
                "FAILED",
                f"Retrieval FAILED ({ws_text}) | error={error} | active={GlobalRetrievalEvent._active_count}"
            )

            GlobalRetrievalEvent._active_count = max(0, GlobalRetrievalEvent._active_count - 1)

            if GlobalRetrievalEvent._active_count == 0:
                await GlobalRetrievalEvent._publish("NOT_RUNNING", "No retrieval running")
            else:
                await GlobalRetrievalEvent._publish("RUNNING", f"Retrieval still RUNNING | active={GlobalRetrievalEvent._active_count}")

    @staticmethod
    def getLatest() -> Optional[RetrievalStatus]:
        return GlobalRetrievalEvent._latest
