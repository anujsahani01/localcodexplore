
import asyncio
import math
import os
import sqlite3
from pathlib import Path
from typing import AsyncIterable

from langchain.indexes import SQLRecordManager, aindex,index
# from langchain_community.indexes import SQLRecordManager
from langchain_core.documents import Document
from sqlalchemy.ext.asyncio import create_async_engine

#from codebase_context_provider.config.configdetails import getWorkSpaceName
from codebase_context_provider.model.embeddingmodel import CustomEmbeddingModel
from codebase_context_provider.service.indexcreation import IndexCreation
from codebase_context_provider.utils.events import EventStore, IndexingStatus
from codebase_context_provider.utils.helper import INDEX_PATH, MASTER_DB_PATH, trim_path
from codebase_context_provider.utils.logger import LoggingClass

loggerClass = LoggingClass(name="RecordManager",log_file_path="RecordManager.log")
logger = loggerClass.get_logger()


class RecordManager:

    def __init__(self,wspath,wsname,wsversion):
        
        self.userwspath=wspath
        self.indexwsname = wsname
        self.wsversion=wsversion
        self.indexworkspacepath = os.path.join(INDEX_PATH,trim_path(wspath),wsname)
        self.indexcreator = IndexCreation(self.indexworkspacepath)
        self.vectorstore = self.indexcreator.loadIndex(self.indexworkspacepath)
        self.recordManager = None
        self.totalDocuments = 0


    def loadEmbeddingModel():

        embeddingModel = CustomEmbeddingModel(
            model_name="nomic-ai/CodeRankEmbed",
            model_kwargs={"trust_remote_code": True, "device": "cpu"}
        )

        return embeddingModel


    async def createRecordManager(self):

        self.indexcreator.saveIndex(self.vectorstore,self.indexworkspacepath)

        collectionName = "CodeCollection"
        namespace = f"{collectionName}"
        db_url = f"sqlite+aiosqlite:///{self.indexworkspacepath}/{self.indexwsname}.db"
        engine = create_async_engine(db_url,echo=False)

        recordManager = SQLRecordManager(
            namespace,
            engine=engine,
            async_mode=True
        )

        await self.__createSchemaAsync(recordManager)

        self.recordManager = recordManager

        logger.info(f"===== Record Manager Initialized at {db_url} =====")



    async def __createSchemaAsync(self,recordManager):
        await recordManager.acreate_schema()
    

    def getRecordManager(self):
        return self.recordManager

    
    def getDataFromTransformTable(self,table_name):

        with sqlite3.connect(MASTER_DB_PATH) as conn:
            cursor = conn.cursor()
            query = f"SELECT * FROM '{table_name}'"
            cursor.execute(query)
            rows = cursor.fetchall()
            return rows


    async def addData(self, controller):

        table_name = self.indexwsname +"_transform"
        
        data = self.getDataFromTransformTable(table_name)

        listOfDocuments = [
            Document(
                page_content=doc[13],   # doc[13] = doc['page_content'],
                metadata={'source': '\\'.join(doc[3].split('\\')[:-1])} # doc[3] = doc['windowsfullpath']
            )
            for doc in data 
        ]

        self.totalDocuments = len(listOfDocuments)

        logger.info(f"====== {len(listOfDocuments)} Documents Created ======")

        #fullworkspacepath = os.path.join(INDEX_PATH,self.indexwsname)
        file_path = Path(self.indexworkspacepath)

        if file_path.exists():
            self.vectorstore = self.indexcreator.loadIndex(self.indexworkspacepath)
        else:
            self.vectorstore = self.indexcreator.createIndex()
        
        #Index Batch Size
        batch_size = max(1, math.ceil(len(listOfDocuments) / 20))


        await self.indexData(listOfDocuments, self.recordManager, self.vectorstore, self.indexworkspacepath,self.userwspath, self.wsversion, self.indexcreator,batch_size,controller)


    async def indexData(self, listOfDocuments, recordManager, vectorstore, indexworkspacepath,userwspath, wsversion, indexCreator,batch_size,controller):
        
        async def document_stream() -> AsyncIterable[Document]:
            
            for idx , doc in enumerate(listOfDocuments):
                
                await controller.pause_event.wait()
                
                yield doc

                if (idx+1) % batch_size == 0 or (idx+1) == self.totalDocuments:
                    progress = ((idx+1)/self.totalDocuments)*100
                    logger.info(f"===== Indexing Progress {progress} for {userwspath}=====")
                    await EventStore.addEvent(
                            workspacepath=userwspath,    
                            version=wsversion,     
                            event=IndexingStatus(completed=int(progress),state="running")
                                        )
        result = None  
        timeout_seconds = 12 * 60 * 60  # 43200 seconds (12 hours)
        logger.error("===== Indexing time out is 12 hours =====")
        
        try:

            result = await asyncio.wait_for( 
                aindex(
                docs_source = document_stream(),
                record_manager = recordManager,
                vector_store = vectorstore,
                cleanup = "scoped_full",
                source_id_key = "source",
                key_encoder = "blake2b",
                batch_size = batch_size,
                force_update = False,
                cleanup_batch_size = batch_size
            ), timeout=timeout_seconds)
                    
            await EventStore.addEvent(
                workspacepath=userwspath,
                version=wsversion,
                event=IndexingStatus(completed=100, state="completed")
            )
        except asyncio.TimeoutError:
            logger.error("===== Indexing Timeout =====")
            await EventStore.addEvent(
                workspacepath=userwspath,
                version=wsversion,
                event=IndexingStatus(completed=0, state="timeout", message="Indexing timed out")
            )
        
        except asyncio.CancelledError:   
            logger.error("===== Indexing CancelledError =====")
            await EventStore.addEvent(
                workspacepath=userwspath,
                version=wsversion,
                event=IndexingStatus(completed=0, state="stopped", message="Cancelled")
            )
            raise
        
        except Exception as e:
            logger.error(f"===== Failed to Index {e} =====")
                    
            await EventStore.addEvent(
                workspacepath=userwspath,
                version=wsversion,
                event=IndexingStatus(completed=0, state="failed", message=str(e))
            )
                

        logger.info(f"===== Final Indexing Result {result} =====")

        indexCreator.saveIndex(vectorstore,indexworkspacepath)

        logger.info(f"===== Total Documents Indexed: {vectorstore.index.ntotal} =====")




###################

"""
New LangChain Version
"""


