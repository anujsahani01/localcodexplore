import asyncio
from typing import Dict, Tuple

class IndexingController:
    def __init__(self):
        self.pause_event = asyncio.Event()
        self.pause_event.set()   # running by default
        self.task: asyncio.Task | None = None

controllers: Dict[Tuple[str, str], IndexingController] = {}

def get_controller(workspacepath: str, version: str) -> IndexingController:
    k = (workspacepath, str(version))
    if k not in controllers:
        controllers[k] = IndexingController()
    return controllers[k]

def get_global_indexing_status() -> str:
    if not controllers:
        return "indexing not running"

    any_running = False
    any_paused = False

    for c in controllers.values():
        if c.task and not c.task.done():
            any_running = True
            if not c.pause_event.is_set():
                any_paused = True

    if not any_running:
        return "indexing not running"

    # if at least one running task is paused → show paused
    if any_paused:
        return "indexing paused"

    return "indexing running"