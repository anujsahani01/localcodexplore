
import torch
from langchain_huggingface.embeddings import HuggingFaceEmbeddings


class CustomEmbeddingModel(HuggingFaceEmbeddings):
    
    
    def __init__(self,model_name,cache_folder=None,model_kwargs=None,encode_kwargs=None,query_encode_kwargs=None,multi_process=False,show_progress=False):

        super(CustomEmbeddingModel,self).__init__(
            model_name = model_name, 
            cache_folder = cache_folder, 
            model_kwargs = model_kwargs or {}, 
            encode_kwargs = encode_kwargs or {}, 
            query_encode_kwargs = query_encode_kwargs or {}, 
            multi_process = multi_process, 
            show_progress = show_progress, 
        )


if __name__ == "__main__":

    embeddingmodel = CustomEmbeddingModel(
        model_name = "nomic-ai/CodeRankEmbed",
        model_kwargs = {"trust_remote_code": True, "device": "cpu"}
    )

    query = "Hello World"
    embedding = embeddingmodel.embed_query(query)
    print("===== Embedding ===== \n",embedding)
    print("===== Embedding Dimension ===== \n",len(embedding))


