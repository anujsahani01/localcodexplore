
from typing import Optional

from fastapi import HTTPException
from pydantic import BaseModel, field_validator

from codebase_context_provider.utils.logger import LoggingClass

loggerClass = LoggingClass(name="LocalContextProvider", log_file_path='LocalContextProvider.log')
contextlogger = loggerClass.get_logger()


class LocalContextProvider(BaseModel):
    fullInput: str
    options: Optional[dict] = None

    @field_validator('fullInput')
    def check_full_input_not_empty(cls, v):
        if not v.strip():
            contextlogger.error("===== fullInput is empty =====")
            raise ValueError('fullInput should not be empty')
        return v

    @field_validator('options')
    def validate_options(cls, v):

        if v is None:
            return {}

        file_extension = v.get('fileExtension', None)
        if isinstance(file_extension, list):
            contextlogger.error(f"===== File Extension should not be list =====")
            raise HTTPException(status_code=400, detail='fileExtension should not be a list')
        v['fileExtension'] = file_extension

        retrieval_doc_count = v.get('retrievalDocCount')
        if retrieval_doc_count is None:
            retrieval_doc_count = 10
            v['retrievalDocCount'] = retrieval_doc_count

        if isinstance(retrieval_doc_count, str):
            try:
                retrieval_doc_count = int(retrieval_doc_count)
                v['retrievalDocCount'] = retrieval_doc_count
            except ValueError:
                contextlogger.error(f"===== Invalid retrievalDocCount value: {retrieval_doc_count} =====")
                raise HTTPException(status_code=400, detail='retrievalDocCount should be a valid integer')

        if retrieval_doc_count < 1 or retrieval_doc_count > 20:
            contextlogger.error(f"===== Invalid retrievalDocCount: {retrieval_doc_count} =====")
            raise HTTPException(status_code=400, detail="retrievalDocCount must be between 1 and 20")

        owner = v.get('owner', None)
        v['owner'] = owner

        includeAllFilters = v.get('includeAllFilters', None)
        v['includeAllFilters'] = includeAllFilters

        brand_name = v.get('brandName', None)
        v['brandName'] = brand_name

        workspacename = v.get('workspacename')
        v['workspacename'] = workspacename

        return v
    
