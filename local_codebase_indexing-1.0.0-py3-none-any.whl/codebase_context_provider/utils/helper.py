

import os
from pathlib import Path


HOME_PATH = Path.home()

INDEX_PATH = os.path.join(HOME_PATH,".LocalXplore\\Index")
MASTER_DB_PATH = os.path.join(HOME_PATH,".LocalXplore\\DS3.db")

def trim_path(p: str) -> str:
    p = p.strip().replace("\\", "/")   

    # remove drive like "D:/"
    if len(p) >= 3 and p[1] == ":" and p[2] == "/":
        p = p[3:]

    # remove linux root "/"
    elif p.startswith("/"):
        p = p[1:]

    # remove last folder/file
    if "/" in p:
        p = p.rsplit("/", 1)[0]
    else:
        p = ""

    return p.replace("/", "\\")