
import json

import psutil

from codebase_context_provider.utils.logger import LoggingClass

loggerClass = LoggingClass(name="Server Status", log_file_path='ServerStatus.log')
logger = loggerClass.get_logger()


class ServerStatus:

    def __init__(self):
        self.__SERVER_PORT = 8000

        self.__IDE_SIGNATURES = {
            "vscode": ["Code.exe", "code", "code.exe"],
            "visual_studio": ["devenv.exe"],
            "eclipse": ["eclipse.exe", "eclipse"]
        }


    def __getIDEfromProcess(self, proc: psutil.Process):
        for ancestor in proc.parents():
            name = ancestor.name()
            for ide_key, names in self.__IDE_SIGNATURES.items():
                if name in names:
                    return ide_key, ancestor
        return None, None


    def __getServerProcessByPort(self, port: int):
        pids = set()

        for conn in psutil.net_connections(kind="inet"):
            try:
                if (
                    conn.laddr
                    and conn.laddr.port == port
                    and conn.status == psutil.CONN_LISTEN
                    and conn.pid is not None
                ):
                    pids.add(conn.pid)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return [psutil.Process(pid) for pid in pids]


    def getServerDetails(self, port: int):
        procs = self.__getServerProcessByPort(port)
        
        if not procs:
            logger.info(f"===== No Process Found Listening on port {port} =====")
            return json.dumps([])  

        server_details = []

        for proc in procs:
            try:
                logger.info(f"===== Found Server Listening on Port {port} =====")
                logger.info(f"===== PID: {proc.pid} \n Name: {proc.name} \n CMDLine: {proc.cmdline} =====")
                logger.info(f"===== Ancestor Chain (Closest Parent First) =====")

                process_info = {
                    "pid": proc.pid,
                    "name": proc.name(),
                    "cmdline": proc.cmdline(),
                    "ancestors": []
                }

                for ancestor in proc.parents():
                    logger.info(f"===== PID={ancestor.pid}, name={ancestor.name()}, cmdline={ancestor.cmdline()} =====")
                    process_info["ancestors"].append({
                        "pid": ancestor.pid,
                        "name": ancestor.name(),
                        "cmdline": ancestor.cmdline()
                    })

                ide_key, ide_proc = self.__getIDEfromProcess(proc)

                if ide_key:
                    logger.info(f"===== Detected IDE in Ancestor Chain =====")
                    logger.info(f"===== IDE Logical name {ide_key} =====")
                    logger.info(f"===== IDE process: PID={ide_proc.pid}, name={ide_proc.name()} =====")
                    logger.info(f"===== Cmdline: {ide_proc.cmdline()} =====")
                    process_info["ide"] = {
                        "logical_name": ide_key,
                        "pid": ide_proc.pid,
                        "name": ide_proc.name(),
                        "cmdline": ide_proc.cmdline()
                    }
                else:
                    logger.info("===== No Known IDE (VSCode / Visual Studio / Eclipse) found in Ancestor Chain =====")
                    process_info["ide"] = None

                server_details.append(process_info)

            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                logger.info(f"===== Process {proc.pid} disappeared or is not accessible while inspecting =====")

        return json.dumps(server_details) 



if __name__ == "__main__":

    serverStatus = ServerStatus()
    response = serverStatus.getServerDetails(8000)
    logger.info(f"===== Server Status Response: {response} =====")
