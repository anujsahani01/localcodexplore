import asyncio
from typing import Dict, Tuple, Optional
from pydantic import BaseModel

class IndexingStatus(BaseModel):
    completed: float
    state: str = "running"   # running | paused | completed | failed | timeout | stopped
    message: str | None = None


class EventStore:
    _queues: Dict[Tuple[str, str], asyncio.Queue[IndexingStatus]] = {}
    _latest: Dict[Tuple[str, str], IndexingStatus] = {}

    @staticmethod
    def _key(workspacepath: str, version: str) -> Tuple[str, str]:
        return (workspacepath, version)

    @staticmethod
    def getQueue(workspacepath: str, version: str) -> asyncio.Queue[IndexingStatus]:
        key = EventStore._key(workspacepath, version)
        if key not in EventStore._queues:
            EventStore._queues[key] = asyncio.Queue()
        return EventStore._queues[key]

    @staticmethod
    async def addEvent(workspacepath: str, version: str, event: IndexingStatus):
        key = EventStore._key(workspacepath, version)
        EventStore._latest[key] = event
        q = EventStore.getQueue(workspacepath, version)
        await q.put(event)

    @staticmethod
    def getLatestEvent(workspacepath: str, version: str) -> Optional[IndexingStatus]:
        key = EventStore._key(workspacepath, version)
        return EventStore._latest.get(key)

    @staticmethod
    def eventCount(workspacepath: str, version: str) -> int:
        q = EventStore.getQueue(workspacepath, version)
        return q.qsize()
