
import logging
import os
from pathlib import Path


class LoggingClass:

    def __init__(self,name: str = None,log_file_path:str = "Logging.log"):
        self.name = name
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        self.home_path = Path.home()
        self.log_path = os.path.join(self.home_path,r".LocalXplore/Logs")
        self.log_file_path = os.path.join(self.log_path,log_file_path)

        self.setup_handlers()

    def setup_handlers(self):
        if not self.logger.handlers:
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

            # Console handler
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            self.logger.addHandler(console_handler)

            # File handler
            if self.log_file_path:
                log_dir = os.path.dirname(self.log_file_path)
                if not os.path.exists(log_dir):
                    os.makedirs(log_dir)
                file_handler = logging.FileHandler(self.log_file_path)
                file_handler.setFormatter(formatter)
                self.logger.addHandler(file_handler)

    def get_logger(self) -> logging.Logger:
        return self.logger


if __name__ == "__main__":
    
    logging_class = LoggingClass(name="Demo")
    logger = logging_class.get_logger()
    
    logger.info("This is an info message")
    logger.error("This is an error message")


