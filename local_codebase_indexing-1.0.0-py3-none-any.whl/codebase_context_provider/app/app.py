
from contextlib import asynccontextmanager

from fastapi import FastAPI

from codebase_context_provider.middleware.custommiddleware import \
    CustomMiddleware
from codebase_context_provider.routes.routes import router
from codebase_context_provider.utils.localcontextprovider import contextlogger
from local_codebase_indexing.local_rag.events.event_handler import \
    WatchManager
from threading import Thread
import sqlite3
import os
from pathlib import Path
import platform
import time
import logging



watch_manager = WatchManager()
logger = logging.getLogger(__name__)


def make_dotfiles():
    # Get user's home directory
    home_dir = Path.home()   # works on Windows, Linux, macOS
    my_lib_path = os.path.join(home_dir , ".LocalXplore")
    # my_lib_path.mkdir(exist_ok=True)
    if not os.path.exists(my_lib_path):
        os.mkdir(my_lib_path)
    return my_lib_path

# def reconcile():
#     while True:
#         args = parse_args(argv)
#         setup_logging(args.debug, args.redirect)

#         try:
#             config_files = list_config_files()
#         except FileNotFoundError as e:
#             logger.error(e)
#             # sys.exit(1)

#         if str(args.config) == "demo":
#             config_name = args.config
#             try:
#                 validate_config_selection(config_name, config_files)
#             except ValueError as e:
#                 logger.error(e)
#                 # sys.exit(1)
#         else:
#             config_name = get_config_selection(config_files)

#         config = load_config(config_name)  

#         # instead of reading the path from config we will be reading path from system args
#         # workspace_path = os.path.normpath(Path(config.paths.workspace_path))
#         # changed
#         args = parse_args()
#         workspace_path = os.path.normpath(Path(args.workspacepath))
#         version = args.version
#         if version is None and workspace_path is not None:
#             version = config.paths.version
#         elif version is None and workspace_path is None:
#             raise Exception("Workspace path and version are not provided")
        
#         print(f"Workspacepath: {workspace_path} \n Version: {version}")
#         workspace_name = f"{str(workspace_path).split('\\')[-1]}_{version}"

#         # getting all workspaces from the master table DB
#         home_dir = Path.home()   # works on Windows, Linux, macOS
#         my_lib_path = os.path.join(home_dir , ".LocalXplore")
#         # my_lib_path.mkdir(exist_ok=True)
#         if not os.path.exists(my_lib_path):
#             os.mkdir(my_lib_path)
        
#         con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
#         cur = con.cursor()
#         table_name = "master_table"
#         cur.execute("SELECT name from sqlite_master WHERE type = 'table' AND name =?;", (table_name,))
#         tables = cur.fetchall()
#         if platform.system().lower() == "linux":
#             path_key = 'unixfullpath'
#         elif platform.system().lower() == "windows":
#             path_key = 'windowsfullpath'        

#         if tables:
#             # cur.execute(f"SELECT {path_key}, pid FROM {table_name} WHERE indexed = 1")
#             # workspaces = cur.fetchall()

#             cur.execute("""
#                 SELECT is_indexed FROM master_table
#                 WHERE workspacename = ?;
#             """, (workspacename,))
#             row = cur.fetchone()
#             con.commit()
#             is_indexed = row[0]

#             if is_indexed == 1:
#                 pid = os.getpid()
#                 my_lib_path = make_dotfiles()
#                 con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
#                 cur = con.cursor()
#                 table_name = "master_table"
#                 cur.execute("""
#                     UPDATE master_table
#                     SET pid = ?
#                     WHERE workspacename = ?;
#                 """, (pid, workspacename))
#                 con.commit()

                
#                 desired_paths = {
#                     str(workspace_path)
#                 }

#                 active_paths = set(watch_manager.watchers.keys())

#                 # start missing watchers
#                 for path in desired_paths - active_paths:
#                     watch_manager.start_watch(path)

#                 time.sleep(2)
#                 logger.info(f"Watchdog started for {workspace_path}")


#TODO: MAJOR INEFFICIENCY
def reconcile():
    contextlogger.info("Watchdog reconciler started")

    while True:
        # getting all workspaces from the master table DB
        home_dir = Path.home()   # works on Windows, Linux, macOS
        my_lib_path = os.path.join(home_dir , ".LocalXplore")
        # my_lib_path.mkdir(exist_ok=True)
        if not os.path.exists(my_lib_path):
            os.mkdir(my_lib_path)
        
        con = sqlite3.connect(os.path.join(my_lib_path, "DS3.db"))
        cur = con.cursor()
        table_name = "master_table"
        cur.execute("SELECT name from sqlite_master WHERE type = 'table' AND name =?;", (table_name,))
        tables = cur.fetchall()
        if platform.system().lower() == "linux":
            path_key = 'unixfullpath'
        elif platform.system().lower() == "windows":
            path_key = 'windowsfullpath'        

        if tables:
            con = sqlite3.connect(os.path.join(make_dotfiles(), "DS3.db"))
            cur = con.cursor()

            cur.execute("""
                SELECT workspacename, windowsfullpath, unixfullpath
                FROM master_table
                WHERE is_indexed = 1
            """)

            rows = cur.fetchall()
            con.close()

            desired_paths = set()
            workspacenames_dict = {}

            for ws_name, win_path, unix_path in rows:
                path = win_path if platform.system().lower() == "windows" else unix_path
                desired_paths.add(path)
                workspacenames_dict[path] = ws_name

            active_paths = set(watch_manager.watchers.keys())
            # logger.info(f"Paths in activate watchdog pipeline: {active_paths}")
            for path in desired_paths - active_paths:
                # TODO: Handling only 1 version as of now
                logger.info(f"Paths being monitored: {path}")
                version = str(workspacenames_dict[path]).split("_")[-1]
                watch_manager.start_watch(path, version = version)

            time.sleep(2)





@asynccontextmanager
async def lifespan(app: FastAPI):

    contextlogger.info("===== FastAPI Application Starting =====")
    contextlogger.info("===== Watchdog Manger Starting =====")
    thread = Thread(target=reconcile, daemon=True)
    thread.start()

    yield

    contextlogger.info("===== FastAPI Application is ShutDown =====")
    # contextlogger.info("===== Observer ShutDown =====")
    # observer.stop()
    # observer.join()



fastapi_app = FastAPI(
    title = "Local Context Provider",
    version = "1.0",
    lifespan = lifespan
)


fastapi_app.add_middleware(CustomMiddleware)

fastapi_app.include_router(router)

