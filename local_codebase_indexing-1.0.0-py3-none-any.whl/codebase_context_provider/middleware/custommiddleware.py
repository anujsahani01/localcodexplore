
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

from codebase_context_provider.utils.logger import LoggingClass

loggerClass = LoggingClass(name = "Middleware",log_file_path = 'middleware.log')
logger = loggerClass.get_logger()

class CustomMiddleware(BaseHTTPMiddleware):

    async def dispatch(self, request: Request, call_next):
        
        logger.info(f"Request Method: {request.method}")
        logger.info(f"Request URL: {request.url}")
        
        body = await request.body()
        logger.info(f"Request Body: {body.decode('utf-8')}")

        logger.info("-"*60)

        response = await call_next(request)

        logger.info(f"Response Status code: {response.status_code}")

        logger.info("="*60)
        logger.info("\n")

        return response


if __name__ == "__main__":
    
    middleware = CustomMiddleware()

